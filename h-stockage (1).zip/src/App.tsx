import React, { useState, useEffect } from 'react';
import {
  ActiveTab,
  SneakerModel,
  Brand,
  SelectionItem,
  InquiryRequest,
  ClientProfile,
  WatermarkSettings,
} from './types';
import {
  getStoredProducts,
  saveProducts,
  getStoredBrands,
  saveBrands,
  getStoredSelection,
  saveSelection,
  getStoredRequests,
  saveRequests,
  getStoredClients,
  saveClients,
  getStoredWatermark,
  saveWatermark,
  resetAllDataToDefaults,
  fetchProductsFromFirestore,
  fetchBrandsFromFirestore,
} from './services/storageService';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeSection } from './components/HomeSection';
import { CollectionSection } from './components/CollectionSection';
import { BrandSection } from './components/BrandSection';
import { SelectionDrawer } from './components/SelectionDrawer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { RequestModal } from './components/RequestModal';
import { AdminPortal } from './components/admin/AdminPortal';
import { OrderModal } from './components/orders/OrderModal';
import { OrderTrackingView } from './components/pallets/OrderTrackingView';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { logEvent } from './services/eventService';
import { CheckCircle2, ArrowUp, Lock } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [products, setProducts] = useState<SneakerModel[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [selectionItems, setSelectionItems] = useState<SelectionItem[]>([]);
  const [requests, setRequests] = useState<InquiryRequest[]>([]);
  const [clients, setClients] = useState<ClientProfile[]>([]);
  const [watermarkSettings, setWatermarkSettings] = useState<WatermarkSettings>({
    text: 'H DESTOCKAGE',
    opacity: 0.25,
    enabled: true,
  });

  // Toast notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals state
  const [activeModalProduct, setActiveModalProduct] = useState<SneakerModel | null>(null);
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [orderModalItems, setOrderModalItems] = useState<SelectionItem[]>([]);
  const [initialBrandFilter, setInitialBrandFilter] = useState('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => {
      setToastMessage(null);
    }, 2800);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  // Load initial stored state
  useEffect(() => {
    setProducts(getStoredProducts());
    setBrands(getStoredBrands());
    setSelectionItems(getStoredSelection());
    setRequests(getStoredRequests());
    setClients(getStoredClients());
    setWatermarkSettings(getStoredWatermark());
    logEvent('VISIT', 'Ouverture de la plateforme H DESTOCKAGE');
  }, []);

  // Save changes to localStorage
  const handleSaveProducts = (newProducts: SneakerModel[]) => {
    setProducts(newProducts);
    saveProducts(newProducts);
  };

  const handleSaveBrands = (newBrands: Brand[]) => {
    setBrands(newBrands);
    saveBrands(newBrands);
  };

  const handleSaveSelection = (newSelection: SelectionItem[]) => {
    setSelectionItems(newSelection);
    saveSelection(newSelection);
  };

  const handleSaveRequests = (newRequests: InquiryRequest[]) => {
    setRequests(newRequests);
    saveRequests(newRequests);
  };

  const handleSaveClients = (newClients: ClientProfile[]) => {
    setClients(newClients);
    saveClients(newClients);
  };

  const handleSaveWatermark = (newSettings: WatermarkSettings) => {
    setWatermarkSettings(newSettings);
    saveWatermark(newSettings);
  };

  const handleResetDefaults = () => {
    resetAllDataToDefaults();
    setProducts(getStoredProducts());
    setBrands(getStoredBrands());
    setSelectionItems([]);
    setRequests(getStoredRequests());
    setClients(getStoredClients());
    setWatermarkSettings(getStoredWatermark());
    showToast('Plateforme réinitialisée avec succès');
  };

  // --- SELECTION ACTIONS ---
  const handleToggleProductSelection = (product: SneakerModel) => {
    const exists = selectionItems.some((item) => item.productId === product.id);
    if (exists) {
      const updated = selectionItems.filter((item) => item.productId !== product.id);
      handleSaveSelection(updated);
      showToast(`Retiré : ${product.brand} ${product.name}`);
    } else {
      const newItem: SelectionItem = {
        productId: product.id,
        product: product,
        selectedSizes: [...product.availableSizes], // Default to all available sizes
      };
      handleSaveSelection([...selectionItems, newItem]);
      showToast(`Ajouté à la sélection : ${product.brand} ${product.name}`);
    }
  };

  const handleToggleSizeInSelection = (product: SneakerModel, size: number) => {
    const existingIndex = selectionItems.findIndex((item) => item.productId === product.id);
    if (existingIndex >= 0) {
      const currentSizes = selectionItems[existingIndex].selectedSizes;
      let newSizes: number[];
      if (currentSizes.includes(size)) {
        newSizes = currentSizes.filter((s) => s !== size);
      } else {
        newSizes = [...currentSizes, size];
      }

      if (newSizes.length === 0) {
        // Remove product if no sizes left
        const updated = selectionItems.filter((item) => item.productId !== product.id);
        handleSaveSelection(updated);
        showToast(`Retiré : ${product.brand} ${product.name}`);
      } else {
        const updated = [...selectionItems];
        updated[existingIndex] = {
          ...updated[existingIndex],
          selectedSizes: newSizes,
        };
        handleSaveSelection(updated);
        showToast(`Pointure ${size} sélectionnée (${product.brand})`);
      }
    } else {
      // Add product with specific size
      const newItem: SelectionItem = {
        productId: product.id,
        product: product,
        selectedSizes: [size],
      };
      handleSaveSelection([...selectionItems, newItem]);
      showToast(`Ajouté en pointure ${size} : ${product.brand} ${product.name}`);
    }
  };

  const handleSelectAllSizesForProduct = (product: SneakerModel) => {
    const existingIndex = selectionItems.findIndex((item) => item.productId === product.id);
    if (existingIndex >= 0) {
      const updated = [...selectionItems];
      updated[existingIndex] = {
        ...updated[existingIndex],
        selectedSizes: [...product.availableSizes],
      };
      handleSaveSelection(updated);
    } else {
      const newItem: SelectionItem = {
        productId: product.id,
        product: product,
        selectedSizes: [...product.availableSizes],
      };
      handleSaveSelection([...selectionItems, newItem]);
    }
    showToast(`Toutes les pointures sélectionnées pour ${product.brand}`);
  };

  const handleRemoveFromSelection = (productId: string) => {
    const item = selectionItems.find((i) => i.productId === productId);
    const updated = selectionItems.filter((it) => it.productId !== productId);
    handleSaveSelection(updated);
    if (item) {
      showToast(`Retiré : ${item.product.brand} ${item.product.name}`);
    }
  };

  const handleUpdatePalletCountInSelection = (productId: string, delta: number) => {
    const updated = selectionItems.map((item) => {
      if (item.productId === productId) {
        const next = Math.max(1, (item.palletCount || 1) + delta);
        return { ...item, palletCount: next };
      }
      return item;
    });
    handleSaveSelection(updated);
  };

  const handleClearSelection = () => {
    handleSaveSelection([]);
    showToast('Sélection réinitialisée');
  };

  // Filter by brand handler
  const handleSelectBrandFilter = (brandName: string) => {
    setInitialBrandFilter(brandName);
    setActiveTab('collection');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const selectedProductIds = selectionItems.map((item) => item.productId);

  const selectedSizesMap: Record<string, number[]> = {};
  selectionItems.forEach((item) => {
    selectedSizesMap[item.productId] = item.selectedSizes;
  });

  const getActiveModalProductSizes = (): number[] => {
    if (!activeModalProduct) return [];
    const item = selectionItems.find((i) => i.productId === activeModalProduct.id);
    return item ? item.selectedSizes : [];
  };

  return (
    <div className="min-h-screen bg-[#fafafa] text-zinc-900 font-sans selection:bg-zinc-950 selection:text-white flex flex-col justify-between pb-24 md:pb-0">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-fade-in pointer-events-none w-[90%] max-w-md">
          <div className="bg-zinc-950/95 border border-zinc-800 text-white px-4 py-2.5 rounded-2xl shadow-2xl backdrop-blur-xl flex items-center gap-3 text-xs sm:text-sm font-bold">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <span className="truncate">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectionCount={selectionItems.length}
        onSelectBrandFilter={handleSelectBrandFilter}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <HomeSection
            products={products}
            brands={brands}
            watermarkSettings={watermarkSettings}
            selectedProductIds={selectedProductIds}
            selectedSizesMap={selectedSizesMap}
            setActiveTab={setActiveTab}
            onSelectBrandFilter={handleSelectBrandFilter}
            onSelectProduct={(p) => setActiveModalProduct(p)}
            onQuickAdd={handleToggleProductSelection}
            onToggleSize={handleToggleSizeInSelection}
          />
        )}

        {activeTab === 'collection' && (
          <CollectionSection
            products={products}
            brands={brands}
            watermarkSettings={watermarkSettings}
            selectedProductIds={selectedProductIds}
            selectedSizesMap={selectedSizesMap}
            initialBrandFilter={initialBrandFilter}
            onSelectProduct={(p) => setActiveModalProduct(p)}
            onQuickAdd={handleToggleProductSelection}
            onToggleSize={handleToggleSizeInSelection}
          />
        )}

        {activeTab === 'brands' && (
          <BrandSection
            brands={brands}
            products={products}
            onSelectBrandFilter={handleSelectBrandFilter}
          />
        )}

        {activeTab === 'selection' && (
          <SelectionDrawer
            items={selectionItems}
            watermarkSettings={watermarkSettings}
            onRemoveItem={handleRemoveFromSelection}
            onToggleSizeSelection={handleToggleSizeInSelection}
            onUpdatePalletCount={handleUpdatePalletCountInSelection}
            onClearSelection={handleClearSelection}
            onOpenRequestModal={() => setIsRequestModalOpen(true)}
            onNavigateToCollection={() => setActiveTab('collection')}
            onStartOrder={() => {
              setOrderModalItems(selectionItems);
              setIsOrderModalOpen(true);
            }}
          />
        )}

        {activeTab === 'tracking' && (
          <OrderTrackingView
            onNavigateToOrder={() => setActiveTab('collection')}
          />
        )}

        {activeTab === 'admin' && (
          <AdminPortal
            products={products}
            brands={brands}
            clients={clients}
            requests={requests}
            watermarkSettings={watermarkSettings}
            onSaveProducts={handleSaveProducts}
            onSaveBrands={handleSaveBrands}
            onSaveClients={handleSaveClients}
            onSaveRequests={handleSaveRequests}
            onSaveWatermark={handleSaveWatermark}
            onResetDefaults={handleResetDefaults}
            onNavigateTab={(tab) => setActiveTab(tab as any)}
          />
        )}
      </main>

      {/* Global Modals */}
      <ProductDetailModal
        product={activeModalProduct}
        watermarkSettings={watermarkSettings}
        isSelected={activeModalProduct ? selectedProductIds.includes(activeModalProduct.id) : false}
        selectedSizesForProduct={getActiveModalProductSizes()}
        onClose={() => setActiveModalProduct(null)}
        onToggleSizeSelection={handleToggleSizeInSelection}
        onSelectAllSizes={handleSelectAllSizesForProduct}
        onOpenSelection={() => {
          setActiveModalProduct(null);
          setActiveTab('selection');
        }}
        onOrderProduct={(prod, sizes) => {
          const existing = selectionItems.find((it) => it.productId === prod.id);
          let itemsToOrder: SelectionItem[];
          if (existing) {
            itemsToOrder = selectionItems;
          } else {
            const newItem: SelectionItem = {
              productId: prod.id,
              product: prod,
              selectedSizes: sizes,
              palletCount: 1,
            };
            itemsToOrder = [...selectionItems, newItem];
            handleSaveSelection(itemsToOrder);
          }
          setActiveModalProduct(null);
          setOrderModalItems(
            itemsToOrder.length > 0
              ? itemsToOrder
              : [
                  {
                    productId: prod.id,
                    product: prod,
                    selectedSizes: sizes,
                    palletCount: 1,
                  },
                ]
          );
          setIsOrderModalOpen(true);
        }}
      />

      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        initialItems={orderModalItems.length > 0 ? orderModalItems : selectionItems}
        watermarkSettings={watermarkSettings}
        onOrderCompleted={(order) => {
          showToast(`Commande ${order.id} enregistrée !`);
        }}
        onNavigateToTracking={() => {
          setActiveTab('tracking');
        }}
      />

      <RequestModal
        isOpen={isRequestModalOpen}
        selectionItems={selectionItems}
        onClose={() => setIsRequestModalOpen(false)}
        onRequestSubmitted={(newReq) => {
          handleSaveRequests([newReq, ...requests]);
          handleClearSelection();
          showToast('Demande de cotation transmise avec succès');
        }}
      />

      {/* Unique bouton flottant du site : Contact WhatsApp Commercial Officiel */}
      {activeTab !== 'admin' && <WhatsAppFloatingButton />}

      {/* Mobile Bottom Bar */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectionCount={selectionItems.length}
      />

      {/* Footer */}
      <footer className="bg-white border-t border-zinc-200 text-zinc-600 py-12 px-4 sm:px-6 mt-16 text-xs">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 mb-8">
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-2">
              <span className="font-black text-zinc-950 text-lg tracking-tight">
                H <span className="font-light text-zinc-500">DESTOCKAGE</span>
              </span>
              <span className="bg-zinc-100 text-zinc-700 text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-zinc-200">
                PRO B2B
              </span>
            </div>
            <p className="text-zinc-500 leading-relaxed font-normal text-xs max-w-sm">
              Plateforme grossiste B2B officielle spécialisée dans la vente en gros de sneakers neuves et le déstockage de palettes pour professionnels et revendeurs.
            </p>

            <div className="flex items-center gap-2 pt-1 text-zinc-900 text-[11px] font-mono font-bold">
              <Lock className="w-3.5 h-3.5 text-zinc-700" />
              <span>WHOLESALE ONLY • VENTE PAR PALETTES DE 100 PAIRES</span>
            </div>
          </div>

          <div className="md:col-span-3 space-y-2">
            <h4 className="text-zinc-900 font-bold uppercase tracking-wider text-xs">Avis de Protection</h4>
            <p className="text-[11px] leading-relaxed text-zinc-500">
              Les visuels, références et catalogues présentés sur cette plateforme font l'objet d'un filigrane de sécurité et sont réservés aux partenaires agréés H DESTOCKAGE.
            </p>
          </div>

          <div className="md:col-span-4 space-y-2">
            <h4 className="text-zinc-900 font-bold uppercase tracking-wider text-xs">Contact & Service Commercial</h4>
            <p className="text-zinc-500 text-xs">
              Pour toute demande de lot ou commande de palettes :
            </p>
            <p className="font-mono text-zinc-950 font-bold">WhatsApp Officiel : +33 7 58 52 11 91</p>
            <p className="font-mono text-zinc-600">contact@h-destockage.fr</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-6 border-t border-zinc-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-zinc-500">
          <p>© {new Date().getFullYear()} H DESTOCKAGE — Grossiste Sneakers & Déstockage Palettes (Wholesale Only).</p>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-1 text-zinc-600 hover:text-zinc-950 transition-colors font-medium"
          >
            Haut de page
            <ArrowUp className="w-3 h-3" />
          </button>
        </div>
      </footer>
    </div>
  );
}
