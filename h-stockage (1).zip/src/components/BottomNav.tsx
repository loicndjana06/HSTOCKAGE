import React from 'react';
import { Home, Layers, Grid, ShoppingBag, Shield, Package, Truck } from 'lucide-react';
import { ActiveTab } from '../types';

interface BottomNavProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  selectionCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  selectionCount,
}) => {
  return (
    <nav
      aria-label="Navigation principale mobile"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-2xl border-t border-zinc-200 px-1 py-1 pb-safe shadow-[0_-5px_20px_rgba(0,0,0,0.05)]"
    >
      <div className="grid grid-cols-6 gap-0.5 max-w-md mx-auto">
        <button
          type="button"
          onClick={() => setActiveTab('home')}
          className={`min-h-[48px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 active:scale-95 ${
            activeTab === 'home'
              ? 'text-zinc-950 bg-zinc-100 font-bold'
              : 'text-zinc-400 hover:text-zinc-700 active:bg-zinc-50'
          }`}
        >
          <Home className={`w-4 h-4 mb-0.5 transition-transform ${activeTab === 'home' ? 'scale-110' : ''}`} />
          <span className="text-[9px] tracking-tight font-medium">Accueil</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('collection')}
          className={`min-h-[48px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 active:scale-95 ${
            activeTab === 'collection'
              ? 'text-zinc-950 bg-zinc-100 font-bold'
              : 'text-zinc-400 hover:text-zinc-700 active:bg-zinc-50'
          }`}
        >
          <Grid className={`w-4 h-4 mb-0.5 transition-transform ${activeTab === 'collection' ? 'scale-110' : ''}`} />
          <span className="text-[9px] tracking-tight font-medium">Collection</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('brands')}
          className={`min-h-[48px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 active:scale-95 ${
            activeTab === 'brands'
              ? 'text-zinc-950 bg-zinc-100 font-bold'
              : 'text-zinc-400 hover:text-zinc-700 active:bg-zinc-50'
          }`}
        >
          <Layers className={`w-4 h-4 mb-0.5 transition-transform ${activeTab === 'brands' ? 'scale-110' : ''}`} />
          <span className="text-[9px] tracking-tight font-medium">Marques</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('tracking')}
          className={`min-h-[48px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 active:scale-95 ${
            activeTab === 'tracking'
              ? 'text-zinc-950 bg-zinc-100 font-bold'
              : 'text-zinc-400 hover:text-zinc-700 active:bg-zinc-50'
          }`}
        >
          <Truck className={`w-4 h-4 mb-0.5 transition-transform ${activeTab === 'tracking' ? 'scale-110' : ''}`} />
          <span className="text-[9px] tracking-tight font-medium">Suivi</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('selection')}
          className={`relative min-h-[48px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 active:scale-95 ${
            activeTab === 'selection'
              ? 'text-zinc-950 bg-zinc-100 font-bold'
              : 'text-zinc-400 hover:text-zinc-700 active:bg-zinc-50'
          }`}
        >
          <div className="relative">
            <ShoppingBag className={`w-4 h-4 mb-0.5 transition-transform ${activeTab === 'selection' ? 'scale-110' : ''}`} />
            {selectionCount > 0 && (
              <span className="absolute -top-1.5 -right-2.5 bg-zinc-950 text-white font-bold text-[8px] min-w-[16px] h-[16px] px-0.5 rounded-full flex items-center justify-center shadow-xs">
                {selectionCount}
              </span>
            )}
          </div>
          <span className="text-[9px] tracking-tight font-medium">Sélection</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('admin')}
          className={`min-h-[48px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 active:scale-95 ${
            activeTab === 'admin'
              ? 'text-zinc-950 bg-zinc-100 font-bold'
              : 'text-zinc-400 hover:text-zinc-700 active:bg-zinc-50'
          }`}
        >
          <Shield className={`w-4 h-4 mb-0.5 transition-transform ${activeTab === 'admin' ? 'scale-110' : ''}`} />
          <span className="text-[9px] tracking-tight font-medium">Admin</span>
        </button>
      </div>
    </nav>
  );
};

