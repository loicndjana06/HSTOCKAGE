import React, { useState } from 'react';
import { Layers, ArrowRight, ShieldCheck } from 'lucide-react';
import { Brand, SneakerModel } from '../types';

interface BrandSectionProps {
  brands: Brand[];
  products: SneakerModel[];
  onSelectBrandFilter: (brandName: string) => void;
}

export const BrandSection: React.FC<BrandSectionProps> = ({
  brands,
  products,
  onSelectBrandFilter,
}) => {
  const activeBrands = brands.filter(
    (b) => b.status !== 'Inactive' && b.id !== 'shox' && b.name.toLowerCase() !== 'shox'
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fade-in text-zinc-900">
      <div>
        <div className="inline-flex items-center gap-2 bg-[#0C1022] text-white text-xs font-mono font-medium px-3.5 py-1.5 rounded-full mb-3 tracking-wider">
          <Layers className="w-3.5 h-3.5 text-blue-400 stroke-[1.5]" />
          <span>MARQUES EN GROS B2B</span>
        </div>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-zinc-950 tracking-tight uppercase">
          Marques & Sélections
        </h1>
        <p className="text-xs sm:text-sm text-zinc-500 mt-1.5 max-w-xl leading-relaxed">
          Sélectionnez un fabricant pour filtrer instantanément les modèles actuellement disponibles dans notre entrepôt logistique.
        </p>
      </div>

      <div className="brand-list-container grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {activeBrands.map((brand) => {
          const brandItemCount = products.filter(
            (p) => p.brand.toLowerCase() === brand.name.toLowerCase() && p.status !== 'MASQUÉ'
          ).length;

          const coverImg = brand.coverImage || brand.image;
          const logoImg = brand.image;

          return (
            <div
              key={brand.id}
              onClick={() => onSelectBrandFilter(brand.name)}
              className="group cursor-pointer bg-white rounded-xl border border-zinc-200/90 hover:border-zinc-400 overflow-hidden transition-all duration-200 shadow-2xs hover:shadow-sm flex flex-col justify-between"
            >
              <div className="relative aspect-16/9 w-full bg-[#f4f5f7] overflow-hidden flex items-center justify-center">
                {coverImg ? (
                  <img
                    src={coverImg}
                    alt={`${brand.name} bannière`}
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500 select-none opacity-90 group-hover:opacity-100"
                    draggable={false}
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <div className="w-full h-full bg-[#f4f5f7] p-6 flex flex-col items-center justify-center text-center relative">
                    {!logoImg && (
                      <div className="w-12 h-12 rounded-lg bg-white border border-zinc-200 flex items-center justify-center mb-2 shadow-2xs">
                        <span className="font-bold text-zinc-900 text-lg uppercase tracking-wider">
                          {brand.name.substring(0, 2)}
                        </span>
                      </div>
                    )}
                    <span className="text-xl font-bold text-zinc-950 uppercase tracking-widest">
                      {brand.name}
                    </span>
                    <span className="text-[10px] font-mono text-zinc-400 mt-1 uppercase">
                      Catalogue Spécifique
                    </span>
                  </div>
                )}

                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/30 to-transparent pointer-events-none"></div>

                <div className="absolute top-3.5 right-3.5 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-md text-[11px] font-mono font-semibold text-zinc-900 border border-white/20 shadow-2xs">
                  {brandItemCount} {brandItemCount > 1 ? 'modèles' : 'modèle'}
                </div>

                <div className="absolute bottom-3.5 left-3.5 right-3.5 flex items-center gap-3">
                  {logoImg ? (
                    <div className="w-11 h-11 rounded-lg bg-white border border-zinc-200 overflow-hidden flex items-center justify-center shadow-md shrink-0 p-1">
                      <img
                        src={logoImg}
                        alt={`${brand.name} logo`}
                        className="w-full h-full object-contain"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    </div>
                  ) : null}
                  <div>
                    <h3 className="text-xl font-bold text-white uppercase tracking-tight drop-shadow-xs">
                      {brand.name}
                    </h3>
                  </div>
                </div>
              </div>

              <div className="p-4 sm:p-5 flex flex-col flex-1 justify-between gap-4">
                <p className="text-xs text-zinc-500 leading-relaxed font-normal">
                  {brand.description}
                </p>

                <div className="pt-3 border-t border-zinc-100 flex items-center justify-between">
                  <span className="text-xs font-semibold text-zinc-900 group-hover:text-blue-600 flex items-center gap-1.5 transition-colors">
                    <span>Voir les modèles {brand.name}</span>
                    <ArrowRight className="w-3.5 h-3.5 stroke-[1.75]" />
                  </span>
                  <span className="text-[10px] font-mono uppercase text-zinc-400">
                    WHOLESALE
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

