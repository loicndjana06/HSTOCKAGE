import React, { useState, useMemo, useEffect } from 'react';
import { Search, Filter, X, RefreshCw, Grid, ArrowUpDown, ChevronDown } from 'lucide-react';
import { SneakerModel, Brand, WatermarkSettings, AvailabilityStatus, ProductSortOption } from '../types';
import { ProductCard } from './ProductCard';

interface CollectionSectionProps {
  products: SneakerModel[];
  brands: Brand[];
  watermarkSettings: WatermarkSettings;
  selectedProductIds: string[];
  selectedSizesMap?: Record<string, number[]>;
  initialBrandFilter?: string;
  onSelectProduct: (product: SneakerModel) => void;
  onQuickAdd?: (product: SneakerModel) => void;
  onToggleSize?: (product: SneakerModel, size: number) => void;
}

const ITEMS_PER_PAGE = 8;

export const CollectionSection: React.FC<CollectionSectionProps> = ({
  products,
  brands,
  watermarkSettings,
  selectedProductIds,
  selectedSizesMap = {},
  initialBrandFilter = '',
  onSelectProduct,
  onQuickAdd,
  onToggleSize,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState(initialBrandFilter);
  const [selectedModel, setSelectedModel] = useState('');
  const [statusFilter, setStatusFilter] = useState<AvailabilityStatus | 'Tous'>('Tous');
  const [sortBy, setSortBy] = useState<ProductSortOption>('newest');
  const [visibleCount, setVisibleCount] = useState(ITEMS_PER_PAGE);
  const [showMobileFilterModal, setShowMobileFilterModal] = useState(false);

  // Sync initial brand filter if updated
  useEffect(() => {
    if (initialBrandFilter) {
      setSelectedBrand(initialBrandFilter);
    }
  }, [initialBrandFilter]);

  // Reset page count when filters change
  useEffect(() => {
    setVisibleCount(ITEMS_PER_PAGE);
  }, [searchQuery, selectedBrand, selectedModel, statusFilter, sortBy]);

  // Reset selected model if it does not belong to newly selected brand
  useEffect(() => {
    if (selectedBrand && selectedModel) {
      const modelExistsInBrand = products.some(
        (p) =>
          p.brand.toLowerCase() === selectedBrand.toLowerCase() &&
          p.name.toLowerCase() === selectedModel.toLowerCase()
      );
      if (!modelExistsInBrand) {
        setSelectedModel('');
      }
    }
  }, [selectedBrand, selectedModel, products]);

  // Available brands with at least 1 real non-masked product
  const availableBrands = useMemo(() => {
    return brands.filter((b) => {
      if (b.id === 'shox' || b.name.toLowerCase() === 'shox') return false;
      return products.some(
        (p) => p.brand.toLowerCase() === b.name.toLowerCase() && p.status !== 'MASQUÉ'
      );
    });
  }, [brands, products]);

  // Available model names for the model filter
  const availableModelNames = useMemo(() => {
    const list = products.filter((p) => {
      if (p.status === 'MASQUÉ') return false;
      if (selectedBrand && selectedBrand !== 'Toutes') {
        return p.brand.toLowerCase() === selectedBrand.toLowerCase();
      }
      return true;
    });
    const names = Array.from(new Set(list.map((p) => p.name))).sort();
    return names;
  }, [products, selectedBrand]);

  const filteredProducts = useMemo(() => {
    const list = products.filter((p) => {
      // Exclude hidden/masked products from client view
      if (p.status === 'MASQUÉ') return false;

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(q);
        const matchesBrand = p.brand.toLowerCase().includes(q);
        const matchesDesc = p.description.toLowerCase().includes(q);
        if (!matchesName && !matchesBrand && !matchesDesc) return false;
      }

      // Brand
      if (selectedBrand && selectedBrand !== 'Toutes') {
        if (p.brand.toLowerCase() !== selectedBrand.toLowerCase()) return false;
      }

      // Model
      if (selectedModel) {
        if (p.name.toLowerCase() !== selectedModel.toLowerCase()) return false;
      }

      // Status
      if (statusFilter !== 'Tous') {
        if (p.status !== statusFilter) return false;
      }

      return true;
    });

    // Apply sorting
    return list.sort((a, b) => {
      switch (sortBy) {
        case 'newest': {
          const dateA = new Date(a.dateAdded).getTime() || 0;
          const dateB = new Date(b.dateAdded).getTime() || 0;
          if (dateB !== dateA) return dateB - dateA;
          if (a.status === 'Nouveau' && b.status !== 'Nouveau') return -1;
          if (b.status === 'Nouveau' && a.status !== 'Nouveau') return 1;
          return a.name.localeCompare(b.name, 'fr');
        }
        case 'price-asc': {
          const priceA = a.price ?? Number.MAX_SAFE_INTEGER;
          const priceB = b.price ?? Number.MAX_SAFE_INTEGER;
          if (priceA !== priceB) return priceA - priceB;
          return a.name.localeCompare(b.name, 'fr');
        }
        case 'price-desc': {
          const priceA = a.price ?? -1;
          const priceB = b.price ?? -1;
          if (priceB !== priceA) return priceB - priceA;
          return a.name.localeCompare(b.name, 'fr');
        }
        case 'brand-asc': {
          const brandComp = a.brand.localeCompare(b.brand, 'fr', { sensitivity: 'base' });
          if (brandComp !== 0) return brandComp;
          return a.name.localeCompare(b.name, 'fr');
        }
        case 'brand-desc': {
          const brandComp = b.brand.localeCompare(a.brand, 'fr', { sensitivity: 'base' });
          if (brandComp !== 0) return brandComp;
          return a.name.localeCompare(b.name, 'fr');
        }
        case 'name-asc': {
          return a.name.localeCompare(b.name, 'fr');
        }
        default:
          return 0;
      }
    });
  }, [products, searchQuery, selectedBrand, selectedModel, statusFilter, sortBy]);

  const paginatedProducts = useMemo(() => {
    return filteredProducts.slice(0, visibleCount);
  }, [filteredProducts, visibleCount]);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedBrand('');
    setSelectedModel('');
    setStatusFilter('Tous');
    setSortBy('newest');
    setVisibleCount(ITEMS_PER_PAGE);
  };

  const hasActiveFilters =
    searchQuery !== '' ||
    selectedBrand !== '' ||
    selectedModel !== '' ||
    statusFilter !== 'Tous' ||
    sortBy !== 'newest';

  const handleShowMore = () => {
    setVisibleCount((prev) => prev + ITEMS_PER_PAGE);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8 animate-fade-in text-zinc-900">
      {/* Title & Stats */}
      <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-4 border-b border-zinc-200 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-[#0C1022] text-white text-xs font-mono font-medium px-3.5 py-1.5 rounded-full mb-3 tracking-wider">
            <Grid className="w-3.5 h-3.5 text-blue-400 stroke-[1.5]" />
            <span>H DESTOCKAGE • CATALOGUE B2B</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-zinc-950 tracking-tight uppercase">
            Catalogue Modèles
          </h1>
          <p className="text-xs sm:text-sm text-zinc-500 mt-1 max-w-xl leading-relaxed">
            Toutes nos références disponibles en stock immédiat. Tarification fixe : 350 € HT la palette de 100 paires.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-zinc-700 bg-[#f4f5f7] border border-zinc-200/80 px-3 py-1.5 rounded-lg font-semibold">
            {filteredProducts.length} {filteredProducts.length > 1 ? 'modèles trouvés' : 'modèle trouvé'}
          </span>

          {/* BOUTON MOBILE 'Filtrer les modèles' */}
          <button
            type="button"
            onClick={() => setShowMobileFilterModal(true)}
            className="md:hidden flex items-center gap-2 bg-[#0C1022] text-white px-4 py-2.5 rounded-lg text-xs font-semibold shadow-2xs cursor-pointer"
          >
            <Filter className="w-4 h-4 text-blue-400 stroke-[1.75]" />
            <span>Filtrer les modèles</span>
            {hasActiveFilters && (
              <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            )}
          </button>
        </div>
      </div>

      {/* RECHERCHE ET FILTRES COMPACTS (DESKTOP) */}
      <div className="hidden md:block bg-white rounded-xl border border-zinc-200/90 p-4 shadow-2xs">
        <div className="grid grid-cols-12 gap-3 items-center">
          {/* 1. Barre de recherche */}
          <div className="col-span-4 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-3 text-zinc-400 stroke-[1.75]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher par modèle ou marque..."
              className="w-full bg-[#f4f5f7] border border-zinc-200/80 rounded-lg pl-10 pr-8 py-2 text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-zinc-950 focus:bg-white transition-colors font-medium"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-zinc-400 hover:text-zinc-900 cursor-pointer"
              >
                <X className="w-4 h-4 stroke-[1.75]" />
              </button>
            )}
          </div>

          {/* 2. Filtre compact par marque */}
          <div className="col-span-3">
            <select
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="w-full bg-[#f4f5f7] border border-zinc-200/80 rounded-lg px-3 py-2 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950 focus:bg-white cursor-pointer font-semibold"
            >
              <option value="">Toutes les marques</option>
              {availableBrands.map((b) => (
                <option key={b.id} value={b.name}>
                  {b.name}
                </option>
              ))}
            </select>
          </div>

          {/* 3. Filtre par modèle */}
          <div className="col-span-3">
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="w-full bg-[#f4f5f7] border border-zinc-200/80 rounded-lg px-3 py-2 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950 focus:bg-white cursor-pointer font-semibold"
            >
              <option value="">Tous les modèles</option>
              {availableModelNames.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          {/* 4. Filtre par disponibilité */}
          <div className="col-span-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full bg-[#f4f5f7] border border-zinc-200/80 rounded-lg px-3 py-2 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950 focus:bg-white cursor-pointer font-semibold"
            >
              <option value="Tous">Toutes disponibilités</option>
              <option value="Disponible">Disponible</option>
              <option value="Nouveau">Nouveau stock</option>
              <option value="Indisponible">Épuisé</option>
            </select>
          </div>
        </div>

        {/* Ligne secondaire si filtres actifs : réinitialisation rapide */}
        {hasActiveFilters && (
          <div className="pt-3 mt-3 border-t border-zinc-100 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-zinc-500">
              <span className="font-medium">Filtres actifs :</span>
              {selectedBrand && (
                <span className="bg-[#0C1022] text-white px-2 py-0.5 rounded text-[11px] font-mono font-medium">
                  {selectedBrand}
                </span>
              )}
              {selectedModel && (
                <span className="bg-[#0C1022] text-white px-2 py-0.5 rounded text-[11px] font-mono font-medium">
                  {selectedModel}
                </span>
              )}
              {statusFilter !== 'Tous' && (
                <span className="bg-[#f4f5f7] text-zinc-900 border border-zinc-200 px-2 py-0.5 rounded text-[11px] font-mono font-semibold">
                  {statusFilter}
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={resetFilters}
              className="text-zinc-600 hover:text-zinc-950 font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 stroke-[1.75]" />
              <span>Réinitialiser les filtres</span>
            </button>
          </div>
        )}
      </div>

      {/* BARRE MOBILE RAPIDE (RECHERCHE SEULE + BOUTON FILTRES) */}
      <div className="md:hidden flex gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-3 text-zinc-400 stroke-[1.75]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher..."
            className="w-full bg-[#f4f5f7] border border-zinc-200/80 rounded-lg pl-9 pr-3 py-2 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950 shadow-2xs"
          />
        </div>
        <button
          type="button"
          onClick={() => setShowMobileFilterModal(true)}
          className={`px-3.5 py-2 rounded-lg text-xs font-semibold border flex items-center gap-1.5 shadow-2xs cursor-pointer ${
            hasActiveFilters
              ? 'bg-[#0C1022] text-white border-[#0C1022]'
              : 'bg-white text-zinc-800 border-zinc-200'
          }`}
        >
          <Filter className="w-3.5 h-3.5 stroke-[1.75]" />
          <span>Filtres</span>
          {hasActiveFilters && <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />}
        </button>
      </div>

      {/* GRILLE DE PRODUITS AÉRÉE */}
      {filteredProducts.length === 0 ? (
        <div className="py-20 text-center space-y-4 bg-white rounded-xl border border-zinc-200/90 p-6 shadow-2xs">
          <div className="w-16 h-16 rounded-full bg-[#f4f5f7] border border-zinc-200 flex items-center justify-center mx-auto text-zinc-400">
            <Search className="w-8 h-8 stroke-[1.5]" />
          </div>
          <h3 className="text-xl font-bold text-zinc-950">Aucun modèle ne correspond à vos filtres</h3>
          <p className="text-xs text-zinc-500 max-w-sm mx-auto leading-relaxed">
            Essayez de réinitialiser la marque ou le modèle sélectionné pour afficher d'autres références en stock direct.
          </p>
          <button
            type="button"
            onClick={resetFilters}
            className="px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-2xs cursor-pointer"
          >
            Afficher tout le catalogue
          </button>
        </div>
      ) : (
        <div className="space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
            {paginatedProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                watermarkSettings={watermarkSettings}
                isSelected={selectedProductIds.includes(product.id)}
                selectedSizes={selectedSizesMap[product.id] || []}
                onSelectProduct={onSelectProduct}
                onQuickAdd={onQuickAdd}
                onToggleSize={onToggleSize}
              />
            ))}
          </div>

          {/* BOUTON « AFFICHER PLUS » */}
          {visibleCount < filteredProducts.length && (
            <div className="pt-6 text-center">
              <button
                type="button"
                onClick={handleShowMore}
                className="px-8 py-3 rounded-lg bg-white hover:bg-zinc-50 border border-zinc-200/90 text-zinc-950 font-semibold text-xs sm:text-sm tracking-wider uppercase inline-flex items-center gap-2 shadow-2xs transition-colors cursor-pointer"
              >
                <span>Afficher plus de modèles</span>
                <span className="font-mono text-xs font-normal text-zinc-500">
                  ({filteredProducts.length - visibleCount} restants)
                </span>
                <ChevronDown className="w-4 h-4 text-zinc-500 stroke-[1.75]" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* BOUTON MODAL « FILTRER LES MODÈLES » (MOBILE) */}
      {showMobileFilterModal && (
        <div className="fixed inset-0 z-50 bg-[#0C1022]/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in pb-safe">
          <div className="w-full max-w-md bg-white border-t sm:border border-zinc-200 rounded-t-2xl sm:rounded-2xl p-5 sm:p-6 space-y-5 text-zinc-900 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-zinc-200 pb-3">
              <h3 className="text-base font-bold uppercase tracking-tight flex items-center gap-2 text-zinc-950">
                <Filter className="w-4 h-4 text-blue-600 stroke-[1.75]" />
                Filtrer les modèles
              </h3>
              <button
                type="button"
                onClick={() => setShowMobileFilterModal(false)}
                aria-label="Fermer les filtres"
                className="w-8 h-8 rounded-lg bg-[#f4f5f7] border border-zinc-200 flex items-center justify-center text-zinc-500 hover:text-zinc-950 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4 stroke-[1.75]" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Filtre Marque */}
              <div>
                <label className="block text-xs font-mono font-medium uppercase text-zinc-500 mb-1.5">
                  Marque
                </label>
                <select
                  value={selectedBrand}
                  onChange={(e) => setSelectedBrand(e.target.value)}
                  className="w-full bg-[#f4f5f7] border border-zinc-200/80 rounded-lg p-2.5 text-xs font-semibold text-zinc-900 focus:outline-none focus:border-zinc-950"
                >
                  <option value="">Toutes les marques</option>
                  {availableBrands.map((b) => (
                    <option key={b.id} value={b.name}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Filtre Modèle */}
              <div>
                <label className="block text-xs font-mono font-medium uppercase text-zinc-500 mb-1.5">
                  Modèle
                </label>
                <select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="w-full bg-[#f4f5f7] border border-zinc-200/80 rounded-lg p-2.5 text-xs font-semibold text-zinc-900 focus:outline-none focus:border-zinc-950"
                >
                  <option value="">Tous les modèles</option>
                  {availableModelNames.map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Filtre Disponibilité */}
              <div>
                <label className="block text-xs font-mono font-medium uppercase text-zinc-500 mb-1.5">
                  Disponibilité
                </label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="w-full bg-[#f4f5f7] border border-zinc-200/80 rounded-lg p-2.5 text-xs font-semibold text-zinc-900 focus:outline-none focus:border-zinc-950"
                >
                  <option value="Tous">Toutes disponibilités</option>
                  <option value="Disponible">Disponible</option>
                  <option value="Nouveau">Nouveau stock</option>
                  <option value="Indisponible">Épuisé</option>
                </select>
              </div>
            </div>

            <div className="pt-3 border-t border-zinc-200 flex gap-3">
              <button
                type="button"
                onClick={resetFilters}
                className="w-1/3 py-2.5 rounded-lg bg-[#f4f5f7] text-zinc-700 hover:text-zinc-950 text-xs font-semibold border border-zinc-200 transition-colors cursor-pointer"
              >
                Effacer
              </button>
              <button
                type="button"
                onClick={() => setShowMobileFilterModal(false)}
                className="w-2/3 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold uppercase tracking-wider transition-colors shadow-2xs cursor-pointer"
              >
                Appliquer ({filteredProducts.length})
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
