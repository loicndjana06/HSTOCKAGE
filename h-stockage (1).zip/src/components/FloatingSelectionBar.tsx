import React from 'react';
import { ShoppingBag, MessageCircle, ArrowRight, X, FileDown } from 'lucide-react';
import { SelectionItem } from '../types';
import { getStoredSettings, logEvent } from '../services/eventService';
import { generateSelectionSummaryPdf } from '../services/pdfService';

interface FloatingSelectionBarProps {
  items: SelectionItem[];
  onOpenSelection: () => void;
  onClearSelection: () => void;
}

export const FloatingSelectionBar: React.FC<FloatingSelectionBarProps> = ({
  items,
  onOpenSelection,
  onClearSelection,
}) => {
  if (items.length === 0) return null;

  const handleQuickPdfDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    generateSelectionSummaryPdf(items);
    logEvent('SELECTION_PDF_DOWNLOADED', `Export PDF direct depuis la barre flottante (${items.length} modèles)`);
  };

  const handleDirectWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    const settings = getStoredSettings();
    const whatsappNum = settings.whatsappNumber.replace(/[^0-9]/g, '') || '33758521191';

    let formattedItemsList = '';
    let totalPallets = 0;
    items.forEach((it) => {
      const palCount = Math.max(1, it.palletCount || 1);
      totalPallets += palCount;
      const sizesStr =
        it.selectedSizes.length > 0
          ? `pointures : ${it.selectedSizes.sort((a, b) => a - b).join(', ')}`
          : 'mix assorti standard';
      formattedItemsList += `\n• ${it.product.brand} ${it.product.name} : ${palCount} palette(s) (${palCount * 100} paires) — ${palCount * 350} € [${sizesStr}]`;
    });

    const totalPairs = totalPallets * 100;
    const subtotal = totalPallets * 350;

    const text = `Bonjour H DESTOCKAGE,

Je souhaite commander les lots de sneakers suivants :
📦 DÉTAIL DE MA SÉLECTION :${formattedItemsList}

- Nombre total de palettes : ${totalPallets} palette(s)
- Total de paires neuves : ${totalPairs} paires
- Sous-total marchandises : ${subtotal.toLocaleString('fr-FR')} € HT

Règle respectée : 1 palette = 100 paires = 350 €.
Merci de me transmettre les disponibilités et les frais de livraison.`;

    logEvent('WHATSAPP_CLICK', `Cotation WhatsApp depuis la barre flottante (${items.length} modèles)`);

    window.open(`https://wa.me/${whatsappNum}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <aside
      aria-label="Barre de sélection active"
      className="fixed bottom-[calc(4.5rem+env(safe-area-inset-bottom,0px))] md:bottom-6 left-1/2 -translate-x-1/2 z-40 w-[95%] sm:w-[92%] max-w-xl transition-all"
    >
      <div className="bg-white/95 backdrop-blur-2xl border border-zinc-200 rounded-2xl p-2.5 sm:p-3 shadow-[0_15px_35px_rgba(0,0,0,0.12)] flex items-center justify-between gap-2.5 sm:gap-3 text-zinc-900">
        {/* Left: Avatar Stack & Count */}
        <div
          onClick={onOpenSelection}
          className="flex items-center gap-2.5 sm:gap-3 cursor-pointer group flex-1 min-w-0 active:opacity-90"
        >
          {/* Stack of thumbnails */}
          <div className="flex -space-x-2 sm:-space-x-2.5 overflow-hidden flex-shrink-0">
            {items.slice(0, 3).map((item) => (
              <img
                key={item.productId}
                src={item.product.images[0]}
                alt={item.product.name}
                className="inline-block h-8 w-8 sm:h-10 sm:w-10 rounded-xl object-cover ring-2 ring-white bg-zinc-100"
              />
            ))}
            {items.length > 3 && (
              <div className="flex h-8 w-8 sm:h-10 sm:w-10 items-center justify-center rounded-xl bg-zinc-100 ring-2 ring-white text-[10px] sm:text-[11px] font-black text-zinc-700">
                +{items.length - 3}
              </div>
            )}
          </div>

          {/* Text summary */}
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-xs sm:text-sm font-black text-zinc-950 group-hover:text-zinc-600 transition-colors truncate">
                {items.length} {items.length > 1 ? 'modèles' : 'modèle'}
              </span>
              <span className="bg-zinc-100 text-zinc-800 border border-zinc-200 text-[9px] sm:text-[10px] font-bold px-1.5 py-0.2 rounded font-mono">
                PRO
              </span>
            </div>
            <p className="text-[10px] sm:text-[11px] text-zinc-500 truncate hidden xs:block sm:block">
              Ajuster pointures ou devis
            </p>
          </div>
        </div>

        {/* Right: Quick Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
          {/* Quick PDF Export for B2B Archiving & Sharing */}
          <button
            onClick={handleQuickPdfDownload}
            title="Télécharger le récapitulatif PDF B2B (archivage / partage interne)"
            className="hidden sm:flex items-center gap-1 sm:gap-1.5 bg-amber-50 hover:bg-amber-100/90 active:scale-95 text-amber-900 border border-amber-300/80 font-bold text-xs px-2.5 sm:px-3 py-2 sm:py-2.5 min-h-[38px] rounded-xl transition-all shadow-xs group cursor-pointer"
          >
            <FileDown className="w-3.5 h-3.5 text-amber-700 group-hover:translate-y-0.5 transition-transform" />
            <span className="hidden md:inline">PDF B2B</span>
          </button>

          {/* WhatsApp Direct Action */}
          <button
            onClick={handleDirectWhatsApp}
            title="Envoyer la sélection sur WhatsApp"
            className="flex items-center gap-1 sm:gap-1.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs px-2.5 sm:px-3.5 py-2 sm:py-2.5 min-h-[38px] rounded-xl transition-all shadow-xs cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-emerald-900 text-white" />
            <span className="hidden sm:inline">Devis WhatsApp</span>
            <span className="sm:hidden">WhatsApp</span>
          </button>

          {/* View Drawer Button */}
          <button
            onClick={onOpenSelection}
            className="flex items-center gap-1 bg-zinc-950 hover:bg-zinc-800 active:scale-95 text-white font-extrabold text-xs px-2.5 sm:px-3.5 py-2 sm:py-2.5 min-h-[38px] rounded-xl transition-all shadow-xs"
          >
            <ShoppingBag className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">Ma Sélection</span>
            <ArrowRight className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
};
