import React, { useState, useEffect } from 'react';
import { ShoppingBag, ShieldCheck, Truck, Menu, X, ChevronDown, Layers, Grid, Home } from 'lucide-react';
import { ActiveTab } from '../types';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  selectionCount: number;
  onSelectBrandFilter?: (brandName: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  selectionCount,
  onSelectBrandFilter,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCollectionSubmenuOpen, setIsCollectionSubmenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Monitor scroll for compact header shadow/border
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 12);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Lock background scroll when drawer is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMenuOpen]);

  // Handle Escape key to close navigation drawer
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMenuOpen) {
        setIsMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMenuOpen]);

  const handleNavigate = (tab: ActiveTab) => {
    setActiveTab(tab);
    setIsMenuOpen(false);
    setIsCollectionSubmenuOpen(false);
  };

  const handleBrandClick = (brandName: string) => {
    if (onSelectBrandFilter) {
      onSelectBrandFilter(brandName);
    } else {
      setActiveTab('collection');
    }
    setIsMenuOpen(false);
    setIsCollectionSubmenuOpen(false);
  };

  const quickBrands = ['Nike', 'Jordan', 'Adidas', 'New Balance', 'ASICS', 'Saucony'];

  return (
    <>
      <header
        className={`sticky top-0 z-50 bg-[#0C1022] text-white transition-all duration-250 ${
          isScrolled ? 'border-b border-white/10 shadow-lg shadow-black/20' : 'border-b border-white/5'
        }`}
      >
        {/* Subtle Top Info Strip */}
        <div className="bg-[#080B17] border-b border-white/5 py-1.5 px-4 text-center text-[10px] font-mono tracking-widest uppercase text-zinc-400 flex items-center justify-center gap-2">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
          <span>GROSSISTE SNEAKERS & DÉSTOCKAGE PRO • ARRIVAGES PERMANENTS • PRIX B2B</span>
        </div>

        {/* Slim Main Header Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between">
          {/* Real H DESTOCKAGE Logo */}
          <button
            type="button"
            onClick={() => handleNavigate('home')}
            className="flex items-center gap-2.5 text-left group focus:outline-none focus:ring-1 focus:ring-blue-500 rounded-md py-1"
            aria-label="Retour à l'accueil H DESTOCKAGE"
          >
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg sm:text-xl tracking-tight text-white group-hover:text-zinc-200 transition-colors">
                H <span className="font-light text-zinc-400">DESTOCKAGE</span>
              </span>
              <span className="bg-white/10 text-zinc-200 text-[10px] font-mono font-medium px-1.5 py-0.5 rounded border border-white/10 tracking-wider">
                PRO B2B
              </span>
            </div>
          </button>

          {/* Navigation Desktop */}
          <nav className="hidden md:flex items-center gap-1 text-xs font-medium text-zinc-300">
            <button
              type="button"
              onClick={() => handleNavigate('home')}
              className={`px-3.5 py-1.5 rounded-md transition-all ${
                activeTab === 'home'
                  ? 'bg-white/12 text-white font-semibold shadow-xs'
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              Accueil
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('collection')}
              className={`px-3.5 py-1.5 rounded-md transition-all ${
                activeTab === 'collection'
                  ? 'bg-white/12 text-white font-semibold shadow-xs'
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              Collection
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('brands')}
              className={`px-3.5 py-1.5 rounded-md transition-all ${
                activeTab === 'brands'
                  ? 'bg-white/12 text-white font-semibold shadow-xs'
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              Marques
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('tracking')}
              className={`px-3.5 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${
                activeTab === 'tracking'
                  ? 'bg-white/12 text-white font-semibold shadow-xs'
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              <Truck className="w-3.5 h-3.5 stroke-[1.5]" />
              <span>Suivi</span>
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('admin')}
              className={`px-3.5 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${
                activeTab === 'admin'
                  ? 'bg-white/12 text-white font-semibold shadow-xs'
                  : 'text-zinc-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 stroke-[1.5]" />
              <span>Espace Admin</span>
            </button>
          </nav>

          {/* Right Actions: Shopping Bag + Hamburger Menu */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Outline Shopping Bag Trigger */}
            <button
              type="button"
              onClick={() => handleNavigate('selection')}
              className="relative min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-zinc-200 hover:text-white hover:bg-white/10 transition-colors focus:outline-none focus:ring-1 focus:ring-blue-500"
              aria-label={`Ma Sélection (${selectionCount} articles)`}
            >
              <ShoppingBag className="w-5 h-5 stroke-[1.5]" />
              {selectionCount > 0 && (
                <span className="absolute top-1.5 right-1.5 bg-blue-600 text-white font-mono text-[9px] font-bold min-w-[16px] h-[16px] px-1 rounded-full flex items-center justify-center">
                  {selectionCount}
                </span>
              )}
            </button>

            {/* Three-line Hamburger Menu Trigger */}
            <button
              type="button"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-zinc-200 hover:text-white hover:bg-white/10 transition-colors focus:outline-none focus:ring-1 focus:ring-blue-500"
              aria-expanded={isMenuOpen}
              aria-label={isMenuOpen ? 'Fermer le menu' : 'Ouvrir le menu de navigation'}
            >
              {isMenuOpen ? (
                <X className="w-5 h-5 stroke-[1.75]" />
              ) : (
                <Menu className="w-5 h-5 stroke-[1.75]" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* FULL-HEIGHT MIDNIGHT-NAVY OVERLAY DRAWER */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex justify-end animate-fade-in">
          {/* Backdrop with soft blur */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-300"
            onClick={() => setIsMenuOpen(false)}
            aria-hidden="true"
          />

          {/* Drawer Panel */}
          <div
            className="relative w-full max-w-sm sm:max-w-md bg-[#0C1022] text-white h-full shadow-2xl border-l border-white/10 flex flex-col justify-between overflow-y-auto animate-slide-left z-10"
            role="dialog"
            aria-modal="true"
            aria-label="Menu principal de navigation"
          >
            {/* Drawer Header with Clean Close Control */}
            <div className="px-6 py-5 border-b border-white/10 flex items-center justify-between">
              <div>
                <span className="font-bold text-lg tracking-tight text-white">
                  H <span className="font-light text-zinc-400">DESTOCKAGE</span>
                </span>
                <span className="block text-[10px] font-mono text-zinc-400 uppercase tracking-wider mt-0.5">
                  Navigation Professionnelle
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsMenuOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-zinc-300 hover:text-white hover:bg-white/10 transition-colors focus:outline-none focus:ring-1 focus:ring-blue-500"
                aria-label="Fermer le menu"
              >
                <X className="w-5 h-5 stroke-[1.75]" />
              </button>
            </div>

            {/* Drawer Nav Links List - Generously Spaced */}
            <div className="px-6 py-8 space-y-3 flex-1">
              {/* Accueil */}
              <button
                type="button"
                onClick={() => handleNavigate('home')}
                className={`w-full text-left py-3 px-3 rounded-lg text-base font-semibold flex items-center gap-3 transition-colors ${
                  activeTab === 'home'
                    ? 'bg-white/10 text-white'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Home className="w-4 h-4 text-zinc-400 stroke-[1.5]" />
                <span>Accueil</span>
              </button>

              {/* Collection with Submenu */}
              <div>
                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => handleNavigate('collection')}
                    className={`flex-1 text-left py-3 px-3 rounded-lg text-base font-semibold flex items-center gap-3 transition-colors ${
                      activeTab === 'collection'
                        ? 'bg-white/10 text-white'
                        : 'text-zinc-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Grid className="w-4 h-4 text-zinc-400 stroke-[1.5]" />
                    <span>Collection Modèles</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsCollectionSubmenuOpen(!isCollectionSubmenuOpen)}
                    className="p-3 text-zinc-400 hover:text-white focus:outline-none rounded-lg"
                    aria-label="Déplier les marques de la collection"
                  >
                    <ChevronDown
                      className={`w-4 h-4 transition-transform duration-200 stroke-[1.5] ${
                        isCollectionSubmenuOpen ? 'rotate-180 text-white' : ''
                      }`}
                    />
                  </button>
                </div>

                {/* Smooth Submenu for Brands */}
                {isCollectionSubmenuOpen && (
                  <div className="pl-10 pr-2 py-2 space-y-1.5 border-l border-white/10 ml-5 my-1">
                    {quickBrands.map((b) => (
                      <button
                        key={b}
                        type="button"
                        onClick={() => handleBrandClick(b)}
                        className="w-full text-left py-1.5 px-2 text-sm text-zinc-400 hover:text-white transition-colors block rounded"
                      >
                        {b}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Marques */}
              <button
                type="button"
                onClick={() => handleNavigate('brands')}
                className={`w-full text-left py-3 px-3 rounded-lg text-base font-semibold flex items-center gap-3 transition-colors ${
                  activeTab === 'brands'
                    ? 'bg-white/10 text-white'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Layers className="w-4 h-4 text-zinc-400 stroke-[1.5]" />
                <span>Catalogue Fabricants</span>
              </button>

              {/* Suivi de Commande */}
              <button
                type="button"
                onClick={() => handleNavigate('tracking')}
                className={`w-full text-left py-3 px-3 rounded-lg text-base font-semibold flex items-center gap-3 transition-colors ${
                  activeTab === 'tracking'
                    ? 'bg-white/10 text-white'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Truck className="w-4 h-4 text-zinc-400 stroke-[1.5]" />
                <span>Suivi de Commande</span>
              </button>

              {/* Ma Sélection */}
              <button
                type="button"
                onClick={() => handleNavigate('selection')}
                className={`w-full text-left py-3 px-3 rounded-lg text-base font-semibold flex items-center justify-between transition-colors ${
                  activeTab === 'selection'
                    ? 'bg-white/10 text-white'
                    : 'text-zinc-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <ShoppingBag className="w-4 h-4 text-zinc-400 stroke-[1.5]" />
                  <span>Ma Sélection</span>
                </div>
                {selectionCount > 0 && (
                  <span className="bg-blue-600 text-white text-xs font-mono font-bold px-2 py-0.5 rounded-full">
                    {selectionCount}
                  </span>
                )}
              </button>

              {/* Espace Admin */}
              <button
                type="button"
                onClick={() => handleNavigate('admin')}
                className={`w-full text-left py-3 px-3 rounded-lg text-base font-semibold flex items-center gap-3 transition-colors ${
                  activeTab === 'admin'
                    ? 'bg-white/10 text-white'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-zinc-400 stroke-[1.5]" />
                <span>Espace Admin</span>
              </button>
            </div>

            {/* Drawer Footer Notice & WhatsApp Commercial */}
            <div className="p-6 border-t border-white/10 bg-[#080B17] space-y-3">
              <div className="flex items-center gap-2 text-zinc-300 text-xs font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>VENTE EXCLUSIVE PAR PALETTE (100 PAIRES)</span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                Contact commercial direct : +33 7 58 52 11 91
                <br />
                Email : contact@h-destockage.fr
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

