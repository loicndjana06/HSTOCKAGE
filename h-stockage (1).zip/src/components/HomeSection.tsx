import React from 'react';
import { ArrowRight, Layers, Sparkles, Flame, Check, ShieldCheck, Box, Truck } from 'lucide-react';
import { SneakerModel, Brand, WatermarkSettings, ActiveTab } from '../types';
import { ProductCard } from './ProductCard';
import heroWarehouseImg from '../assets/images/hero_warehouse_sneakers_1789795898048.jpg';

interface HomeSectionProps {
  products: SneakerModel[];
  brands: Brand[];
  watermarkSettings: WatermarkSettings;
  selectedProductIds: string[];
  selectedSizesMap?: Record<string, number[]>;
  setActiveTab: (tab: ActiveTab) => void;
  onSelectBrandFilter: (brandName: string) => void;
  onSelectProduct: (product: SneakerModel) => void;
  onQuickAdd: (product: SneakerModel) => void;
  onToggleSize?: (product: SneakerModel, size: number) => void;
}

export const HomeSection: React.FC<HomeSectionProps> = ({
  products,
  brands,
  watermarkSettings,
  selectedProductIds,
  selectedSizesMap = {},
  setActiveTab,
  onSelectBrandFilter,
  onSelectProduct,
  onQuickAdd,
  onToggleSize,
}) => {
  // Filter visible brands (max 6 brands)
  const availableBrands = brands.filter(
    (b) => b.id !== 'shox' && b.name.toLowerCase() !== 'shox'
  );
  const featuredBrands = availableBrands.slice(0, 6);

  // Filter visible products (max 8 products)
  const visibleProducts = products.filter((p) => p.status !== 'MASQUÉ');
  const featuredProducts = visibleProducts.slice(0, 8);

  return (
    <div className="space-y-14 sm:space-y-18 pb-16 animate-fade-in text-zinc-900 max-w-7xl mx-auto px-4 sm:px-6">
      {/* HERO SECTION - FULL-BLEED EDITORIAL CROP WITH WAREHOUSE PHOTOGRAPHY */}
      <section className="relative overflow-hidden rounded-2xl border border-white/10 shadow-lg text-left">
        {/* Editorial High-Resolution Warehouse Image Background */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          <img
            src={heroWarehouseImg}
            alt="Entrepôt logistique H DESTOCKAGE"
            className="w-full h-full object-cover object-center scale-102 filter brightness-90"
          />
          {/* Refined Midnight Navy Dark Overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#0C1022]/95 via-[#0C1022]/85 to-[#0C1022]/70" />
        </div>

        {/* Hero Content with Strong Hierarchy & Ample Breathing Room */}
        <div className="relative z-10 px-6 sm:px-12 md:px-16 py-16 sm:py-20 md:py-24 max-w-3xl space-y-6 text-white">
          {/* Pro Tag */}
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-xs border border-white/15 text-zinc-200 text-xs font-mono font-medium px-3.5 py-1.5 rounded-full tracking-wider">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span className="uppercase text-[11px]">GROSSISTE SNEAKERS • ARRIVAGES PRO B2B</span>
          </div>

          {/* Main Title & Subtitle */}
          <div className="space-y-2">
            <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white uppercase font-sans">
              H <span className="font-light text-zinc-400">DESTOCKAGE</span>
            </h1>
            <p className="text-xs sm:text-sm font-semibold tracking-widest text-zinc-300 uppercase font-mono">
              VENTE EN GROS & DÉSTOCKAGE SNEAKERS NEUVES
            </p>
          </div>

          {/* Description */}
          <p className="text-sm sm:text-base text-zinc-300 max-w-xl font-normal leading-relaxed">
            Plateforme réservée aux professionnels et revendeurs. Explorez les arrivages de grandes marques et commandez par palettes de 100 paires en toute transparence.
          </p>

          {/* Action Buttons: Primary Royal Blue & Subtle Translucent White */}
          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              type="button"
              onClick={() => setActiveTab('collection')}
              className="min-h-[44px] px-6 py-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm tracking-wider uppercase flex items-center justify-center gap-2 transition-colors shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500/25"
            >
              <span>Voir tous les modèles</span>
              <ArrowRight className="w-4 h-4 stroke-[1.75]" />
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('brands')}
              className="min-h-[44px] px-6 py-3 rounded-lg bg-white/10 hover:bg-white/15 border border-white/20 text-white font-semibold text-xs sm:text-sm tracking-wider uppercase flex items-center justify-center gap-2 transition-colors focus:outline-none"
            >
              <span>Voir toutes les marques</span>
              <ArrowRight className="w-4 h-4 text-zinc-400 stroke-[1.75]" />
            </button>
          </div>

          {/* Reassurance Grid */}
          <div className="pt-6 grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-2xl border-t border-white/10">
            <div className="bg-white/5 backdrop-blur-xs py-2.5 px-3 rounded-lg border border-white/10 text-left">
              <span className="text-[10px] font-mono uppercase text-white block font-bold">100% PRO</span>
              <p className="text-xs text-zinc-300">Grossiste B2B</p>
            </div>
            <div className="bg-white/5 backdrop-blur-xs py-2.5 px-3 rounded-lg border border-white/10 text-left">
              <span className="text-[10px] font-mono uppercase text-white block font-bold">STOCK DIRECT</span>
              <p className="text-xs text-zinc-300">Dispo immédiate</p>
            </div>
            <div className="bg-white/5 backdrop-blur-xs py-2.5 px-3 rounded-lg border border-white/10 text-left">
              <span className="text-[10px] font-mono uppercase text-white block font-bold">350 € HT</span>
              <p className="text-xs text-zinc-300">Palette 100 paires</p>
            </div>
            <div className="bg-white/5 backdrop-blur-xs py-2.5 px-3 rounded-lg border border-white/10 text-left">
              <span className="text-[10px] font-mono uppercase text-white block font-bold">LIVRAISON</span>
              <p className="text-xs text-zinc-300">Transport sécurisé</p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION MARQUES - EDITORIAL LIGHT AREA */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-3 border-b border-zinc-200 pb-4">
          <div>
            <span className="text-xs font-mono font-medium uppercase tracking-widest text-zinc-500 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-zinc-600 stroke-[1.5]" />
              Catalogue Fabricants
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-zinc-950 tracking-tight uppercase mt-0.5">
              Marques disponibles
            </h2>
          </div>

          <button
            type="button"
            onClick={() => setActiveTab('brands')}
            className="min-h-[40px] inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-zinc-900 hover:text-zinc-600 border border-zinc-300 bg-white hover:bg-zinc-50 px-4 py-2 rounded-lg transition-colors shadow-2xs"
          >
            <span>Voir toutes les marques</span>
            <ArrowRight className="w-3.5 h-3.5 text-zinc-600 stroke-[1.75]" />
          </button>
        </div>

        {/* Grille de marques */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 sm:gap-4">
          {featuredBrands.map((brand) => (
            <button
              key={brand.id}
              type="button"
              onClick={() => onSelectBrandFilter(brand.name)}
              className="group bg-white rounded-xl border border-zinc-200 hover:border-zinc-400 transition-all duration-200 p-4 flex flex-col items-center text-center shadow-2xs hover:shadow-xs"
            >
              <div className="w-16 h-16 rounded-lg bg-[#f4f5f7] overflow-hidden mb-3 border border-zinc-100 group-hover:scale-103 transition-transform flex items-center justify-center p-2">
                <img
                  src={brand.image}
                  alt={brand.name}
                  className="w-full h-full object-contain select-none"
                  draggable={false}
                />
              </div>
              <span className="text-xs font-semibold text-zinc-900 group-hover:text-blue-600 transition-colors uppercase truncate w-full">
                {brand.name}
              </span>
              <span className="text-[10px] text-zinc-400 mt-0.5 font-mono">
                SÉLECTION PRO
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* MIDNIGHT-NAVY CONTENT BAND (ALTERNATING DARK SECTION) */}
      <section className="bg-[#0C1022] text-white rounded-2xl border border-white/10 p-6 sm:p-10 md:p-12 shadow-md">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-3 text-left">
            <span className="text-xs font-mono font-medium uppercase tracking-widest text-blue-400 block">
              STANDARD WHOLESALE B2B
            </span>
            <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Composer une palette mixte sur mesure
            </h3>
            <p className="text-sm text-zinc-300 leading-relaxed max-w-xl">
              Chaque palette est constituée d'exactement 100 paires neuves à 350 € HT. Choisissez 1 modèle complet ou panachez librement 4 modèles distincts (25 paires par modèle sélectionné).
            </p>
            <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-zinc-300 font-mono">
              <span className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-400 stroke-[2]" />
                1 palette = 100 paires
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-400 stroke-[2]" />
                Mixte : 4 x 25 paires
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-400 stroke-[2]" />
                350 € HT par palette
              </span>
            </div>
          </div>

          <div className="shrink-0 w-full md:w-auto">
            <button
              type="button"
              onClick={() => setActiveTab('collection')}
              className="w-full md:w-auto min-h-[44px] px-6 py-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-colors shadow-sm"
            >
              <span>Accéder au catalogue</span>
              <ArrowRight className="w-4 h-4 stroke-[1.75]" />
            </button>
          </div>
        </div>
      </section>

      {/* SECTION PRODUITS - ARRIVAGES & DERNIERS MODÈLES */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-3 border-b border-zinc-200 pb-4">
          <div>
            <span className="text-xs font-mono font-medium uppercase tracking-widest text-zinc-500 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-amber-600 stroke-[1.5]" />
              Arrivages & Stocks Immédiats
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-zinc-950 tracking-tight uppercase mt-0.5">
              Derniers modèles en stock
            </h2>
          </div>

          <button
            type="button"
            onClick={() => setActiveTab('collection')}
            className="min-h-[40px] inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-zinc-900 hover:text-zinc-600 border border-zinc-300 bg-white hover:bg-zinc-50 px-4 py-2 rounded-lg transition-colors shadow-2xs"
          >
            <span>Voir tous les modèles</span>
            <ArrowRight className="w-3.5 h-3.5 text-zinc-600 stroke-[1.75]" />
          </button>
        </div>

        {featuredProducts.length === 0 ? (
          <div className="py-14 px-6 text-center bg-white rounded-2xl border border-zinc-200 space-y-3">
            <div className="w-12 h-12 rounded-xl bg-zinc-100 border border-zinc-200 text-zinc-700 flex items-center justify-center mx-auto">
              <Sparkles className="w-6 h-6 stroke-[1.5]" />
            </div>
            <h3 className="text-base font-bold text-zinc-950">Catalogue en cours de mise à jour</h3>
            <p className="text-xs text-zinc-500 max-w-md mx-auto">
              Les nouveaux arrivages grossistes seront ajoutés sous peu.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
            {featuredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                watermarkSettings={watermarkSettings}
                isSelected={selectedProductIds.includes(product.id)}
                selectedSizes={selectedSizesMap[product.id] || []}
                onSelectProduct={onSelectProduct}
                onQuickAdd={onQuickAdd}
                onToggleSize={onToggleSize}
              />
            ))}
          </div>
        )}

        <div className="pt-4 text-center">
          <button
            type="button"
            onClick={() => setActiveTab('collection')}
            className="min-h-[44px] px-8 py-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm tracking-wider uppercase inline-flex items-center gap-2 transition-colors shadow-sm"
          >
            <span>Voir tous les modèles ({visibleProducts.length})</span>
            <ArrowRight className="w-4 h-4 stroke-[1.75]" />
          </button>
        </div>
      </section>

      {/* DUAL ACTION BANNER - ÉPURÉ, MINIMALISTE ET FOCALISÉ */}
      <section className="bg-white border border-zinc-200 rounded-2xl p-6 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xs">
        <div className="space-y-1.5 text-center md:text-left">
          <span className="text-[11px] font-mono font-medium uppercase tracking-widest text-zinc-500">
            H DESTOCKAGE • EXPÉDITION PROFESSIONNELLE
          </span>
          <h3 className="text-xl sm:text-2xl font-bold text-zinc-950 tracking-tight">
            Prêt à préparer votre commande grossiste ?
          </h3>
          <p className="text-xs sm:text-sm text-zinc-600 max-w-lg">
            Parcourez l'ensemble des marques sous contrat ou filtrez par modèle et pointure.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
          <button
            type="button"
            onClick={() => setActiveTab('brands')}
            className="w-full sm:w-auto min-h-[44px] px-5 py-2.5 rounded-lg bg-white hover:bg-zinc-50 border border-zinc-300 text-zinc-900 font-semibold text-xs uppercase tracking-wider transition-colors text-center"
          >
            Voir toutes les marques
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('collection')}
            className="w-full sm:w-auto min-h-[44px] px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs uppercase tracking-wider transition-colors text-center shadow-2xs"
          >
            Voir tous les modèles
          </button>
        </div>
      </section>
    </div>
  );
};

