import React from 'react';
import { ArrowRight } from 'lucide-react';
import { SneakerModel, WatermarkSettings } from '../types';
import { WatermarkOverlay } from './WatermarkOverlay';
import { logEvent } from '../services/eventService';

interface ProductCardProps {
  product: SneakerModel;
  watermarkSettings: WatermarkSettings;
  isSelected?: boolean;
  selectedSizes?: number[];
  onSelectProduct: (product: SneakerModel) => void;
  onQuickAdd?: (product: SneakerModel) => void;
  onToggleSize?: (product: SneakerModel, size: number) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  watermarkSettings,
  onSelectProduct,
}) => {
  const handleCardClick = () => {
    logEvent('PRODUCT_VIEW', `Consultation de ${product.brand} ${product.name}`);
    onSelectProduct(product);
  };

  const getStatusBadge = () => {
    switch (product.status) {
      case 'Nouveau':
        return (
          <span className="bg-zinc-950 text-amber-400 border border-amber-400/30 font-extrabold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-md shadow-xs">
            Nouveau
          </span>
        );
      case 'Disponible':
        return (
          <span className="bg-white/95 backdrop-blur-sm text-emerald-800 border border-emerald-300 font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-md shadow-xs">
            Disponible
          </span>
        );
      case 'Indisponible':
      case 'Épuisé':
        return (
          <span className="bg-zinc-100 text-zinc-500 border border-zinc-200 font-medium text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-md shadow-xs">
            Épuisé
          </span>
        );
      default:
        return (
          <span className="bg-white/95 text-zinc-700 border border-zinc-200 font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-md shadow-xs">
            {product.status}
          </span>
        );
    }
  };

  return (
    <div
      className="group relative bg-white rounded-xl border border-zinc-200/90 hover:border-zinc-400 transition-all duration-250 overflow-hidden flex flex-col justify-between shadow-2xs hover:shadow-sm"
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* 1. La Photo - Editorial Light Cool-Gray Container */}
      <div
        className="relative aspect-4/3 w-full bg-[#f4f5f7] overflow-hidden cursor-pointer flex items-center justify-center"
        onClick={handleCardClick}
      >
        <img
          src={product.images[0]}
          alt={`${product.brand} ${product.name}`}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-103 transition-transform duration-500 select-none"
          draggable={false}
          onContextMenu={(e) => e.preventDefault()}
        />

        {/* Filigrane de protection H DESTOCKAGE */}
        <WatermarkOverlay settings={watermarkSettings} />

        {/* 4. La Disponibilité */}
        <div className="absolute top-3 left-3 z-20">{getStatusBadge()}</div>
      </div>

      {/* Détails du produit - Spacious and Editorial */}
      <div className="p-4 sm:p-5 flex flex-col flex-1 justify-between gap-3 bg-white">
        <div>
          {/* 2. La Marque */}
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-zinc-400 block mb-1">
            {product.brand}
          </span>

          {/* 3. Le Nom du Modèle */}
          <h3
            onClick={handleCardClick}
            className="text-sm sm:text-base font-semibold text-zinc-950 group-hover:text-blue-600 transition-colors cursor-pointer line-clamp-1"
          >
            {product.name}
          </h3>
        </div>

        <div className="pt-3 border-t border-zinc-100 flex items-center justify-between gap-2">
          {/* 5. Le Prix par Palette */}
          <div>
            <span className="text-[10px] font-mono text-zinc-400 uppercase block tracking-wider">Prix palette</span>
            <span className="font-mono text-xs sm:text-sm font-bold text-zinc-950">
              350 € <span className="text-[10px] font-normal text-zinc-500 font-sans">HT / pal.</span>
            </span>
          </div>

          {/* 6. Le Bouton « Voir le modèle » - Restrained Royal-Blue */}
          <button
            type="button"
            onClick={handleCardClick}
            className="min-h-[40px] px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <span>Voir le modèle</span>
            <ArrowRight className="w-3.5 h-3.5 stroke-[1.75]" />
          </button>
        </div>
      </div>
    </div>
  );
};
