import React, { useState, useEffect } from 'react';
import { X, Check, ShoppingBag, ShieldAlert, Sparkles, Layers, MessageCircle, Package } from 'lucide-react';
import { SneakerModel, WatermarkSettings } from '../types';
import { WatermarkOverlay } from './WatermarkOverlay';
import { getStoredSettings, logEvent } from '../services/eventService';

interface ProductDetailModalProps {
  product: SneakerModel | null;
  watermarkSettings: WatermarkSettings;
  isSelected: boolean;
  selectedSizesForProduct: number[];
  onClose: () => void;
  onToggleSizeSelection: (product: SneakerModel, size: number) => void;
  onSelectAllSizes: (product: SneakerModel) => void;
  onOpenSelection: () => void;
  onOrderProduct?: (product: SneakerModel, selectedSizes: number[]) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  watermarkSettings,
  isSelected,
  selectedSizesForProduct,
  onClose,
  onToggleSizeSelection,
  onSelectAllSizes,
  onOpenSelection,
  onOrderProduct,
}) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!product) return null;

  const handleDirectWhatsApp = () => {
    const settings = getStoredSettings();
    const whatsappNum = settings.whatsappNumber.replace(/[^0-9]/g, '') || '33758521191';

    const sizesStr =
      selectedSizesForProduct.length > 0
        ? `Pointures choisies : ${selectedSizesForProduct.sort((a, b) => a - b).join(', ')}`
        : `Pointures disponibles en stock : ${product.availableSizes.join(', ')}`;

    const text = `Bonjour H DESTOCKAGE,

Je souhaite commander le modèle de sneakers suivant :
- Modèle : ${product.brand} ${product.name}
- Quantité : 1 palette (100 paires) = 350 € HT
- ${sizesStr}

Règle B2B : 1 palette = 100 paires = 350 €.
Merci de me transmettre la disponibilité et les modalités de livraison.`;

    logEvent('WHATSAPP_CLICK', `Cotation WhatsApp depuis la fiche ${product.brand} ${product.name}`);
    window.open(`https://wa.me/${whatsappNum}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-zinc-900/60 backdrop-blur-sm overflow-y-auto animate-fade-in pb-safe">
      <div
        className="relative w-full max-w-4xl bg-white rounded-3xl border border-zinc-200 shadow-2xl overflow-hidden my-auto max-h-[94vh] flex flex-col lg:block overflow-y-auto"
        onContextMenu={(e) => e.preventDefault()}
      >
        {/* Header Close Button */}
        <button
          onClick={onClose}
          aria-label="Fermer la fiche produit"
          className="absolute top-3 right-3 sm:top-4 sm:right-4 z-30 w-11 h-11 rounded-full bg-white/90 backdrop-blur-md border border-zinc-200 text-zinc-700 flex items-center justify-center hover:bg-zinc-100 hover:text-zinc-950 hover:scale-105 active:scale-95 transition-all shadow-md"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
          {/* Gallery Column */}
          <div className="lg:col-span-7 bg-zinc-50 p-3.5 sm:p-6 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-zinc-200">
            {/* Main Stage Image */}
            <div className="relative aspect-4/3 w-full rounded-2xl overflow-hidden bg-white border border-zinc-200 shadow-xs">
              <img
                src={product.images[activeImageIndex] || product.images[0]}
                alt={`${product.brand} ${product.name}`}
                className="w-full h-full object-cover select-none"
                draggable={false}
                onContextMenu={(e) => e.preventDefault()}
              />
              <WatermarkOverlay settings={watermarkSettings} />

              <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[11px] font-mono text-zinc-700 border border-zinc-200 shadow-xs">
                Photo {activeImageIndex + 1} / {product.images.length}
              </div>
            </div>

            {/* Gallery Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex items-center gap-2.5 sm:gap-3 mt-3 sm:mt-4 overflow-x-auto pb-1 no-scrollbar">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-18 h-14 sm:w-20 sm:h-16 rounded-xl overflow-hidden border-2 transition-all flex-shrink-0 bg-white active:scale-95 ${
                      activeImageIndex === idx
                        ? 'border-zinc-950 scale-105 shadow-md'
                        : 'border-zinc-200 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={img}
                      alt="Aperçu"
                      className="w-full h-full object-cover"
                      draggable={false}
                    />
                  </button>
                ))}
              </div>
            )}

            {/* Wholesale Protection Note */}
            <div className="mt-3 sm:mt-4 bg-white border border-zinc-200 rounded-xl p-3 flex items-start gap-2.5 text-xs text-zinc-500 shadow-xs">
              <ShieldAlert className="w-4 h-4 text-zinc-700 flex-shrink-0 mt-0.5" />
              <p className="text-[11px] leading-relaxed">
                <strong className="text-zinc-800">Catalogue Grossiste H DESTOCKAGE :</strong> Visuels protégés réservés aux partenaires revendeurs. Vente exclusive en lots professionnels.
              </p>
            </div>
          </div>

          {/* Details Column */}
          <div className="lg:col-span-5 p-5 sm:p-8 flex flex-col justify-between bg-white text-zinc-900">
            <div>
              {/* Brand & Status */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-black uppercase tracking-widest text-zinc-600 bg-zinc-100 px-2.5 py-1 rounded border border-zinc-200">
                  {product.brand}
                </span>

                <span
                  className={`text-[11px] font-bold px-2.5 py-1 rounded-full border ${
                    product.status === 'Disponible'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : product.status === 'Nouveau'
                      ? 'bg-zinc-950 text-white border-zinc-950 font-extrabold'
                      : 'bg-zinc-100 text-zinc-500 border-zinc-200'
                  }`}
                >
                  {product.status}
                </span>
              </div>

              {/* Title */}
              <h2 className="text-xl sm:text-3xl font-black text-zinc-950 tracking-tight mb-2">
                {product.name}
              </h2>

              {/* Authentic B2B wholesale rate */}
              <div className="flex flex-wrap items-center gap-2 mb-4 bg-zinc-50 border border-zinc-200/80 px-3.5 py-2 rounded-xl w-fit">
                <span className="text-xs text-zinc-600 font-medium">Tarif grossiste B2B :</span>
                <span className="text-sm font-mono font-black text-zinc-950">
                  350 € <span className="text-[10px] text-zinc-500 font-normal font-sans">HT / palette</span>
                </span>
                <span className="text-[11px] font-mono font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                  100 paires (3,50 € / paire)
                </span>
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-zinc-600 leading-relaxed mb-4 font-normal">
                {product.description}
              </p>

              {/* Batch Info */}
              {product.batchInfo && (
                <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-3.5 mb-4 sm:mb-5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-800 mb-1 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-zinc-600" />
                    Information Lot & Dispo
                  </h4>
                  <p className="text-xs text-zinc-600 leading-snug">
                    {product.batchInfo}
                  </p>
                </div>
              )}

              {/* Size Selector */}
              <div className="mb-5 sm:mb-6">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-700 flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5 text-zinc-500" />
                    Pointures souhaitées :
                  </label>
                  <button
                    onClick={() => onSelectAllSizes(product)}
                    className="text-xs text-zinc-900 hover:underline font-bold py-1 px-2 rounded hover:bg-zinc-100 transition-colors"
                  >
                    Tout sélectionner
                  </button>
                </div>

                <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 sm:gap-2">
                  {product.availableSizes.map((size) => {
                    const isSizeSelected = selectedSizesForProduct.includes(size);
                    return (
                      <button
                        key={size}
                        type="button"
                        onClick={() => onToggleSizeSelection(product, size)}
                        className={`min-h-[44px] sm:min-h-[38px] rounded-xl text-sm sm:text-xs font-mono font-bold transition-all border flex items-center justify-center active:scale-95 ${
                          isSizeSelected
                            ? 'bg-zinc-950 text-white border-zinc-950 shadow-xs scale-105'
                            : 'bg-zinc-50 text-zinc-700 border-zinc-200 hover:border-zinc-300 hover:bg-zinc-100'
                        }`}
                      >
                        {size}
                      </button>
                    );
                  })}
                </div>
                <p className="text-[11px] text-zinc-500 mt-2 font-mono">
                  {selectedSizesForProduct.length > 0
                    ? `Pointures retenues (${selectedSizesForProduct.length}) : ${selectedSizesForProduct.sort((a,b)=>a-b).join(' · ')}`
                    : 'Cliquez sur vos pointures pour affiner votre devis.'}
                </p>
              </div>
            </div>

            {/* Wholesale Pallet Rule Notice */}
            <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-zinc-950 flex-shrink-0" />
                <div>
                  <span className="font-bold text-zinc-950 block">Conditionnement Grossiste :</span>
                  <span className="text-zinc-600 text-[11px]">1 palette = 100 paires = 350 € HT (minimum indivisible)</span>
                </div>
              </div>
              <span className="font-mono font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded text-[11px] flex-shrink-0">
                350 € / palette
              </span>
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-zinc-200 space-y-2.5">
              {/* Direct Pallet Order Button */}
              <button
                onClick={() => {
                  if (onOrderProduct) {
                    const sizes = selectedSizesForProduct.length > 0 ? selectedSizesForProduct : product.availableSizes;
                    onOrderProduct(product, sizes);
                  }
                }}
                className="w-full min-h-[48px] py-3.5 px-4 rounded-2xl bg-zinc-950 hover:bg-zinc-800 text-white font-black text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md active:scale-95"
              >
                <Package className="w-4 h-4 text-emerald-400" />
                <span>COMMANDER CE MODÈLE (1 PALETTE — 350 €)</span>
              </button>

              {/* Direct WhatsApp Quote */}
              <button
                onClick={handleDirectWhatsApp}
                className="w-full min-h-[44px] py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-xs active:scale-95"
              >
                <MessageCircle className="w-4 h-4 fill-emerald-900 text-white" />
                FINALISER SUR WHATSAPP OFFICIEL
              </button>

              {/* Add to Multi-Selection */}
              <button
                onClick={() => {
                  if (selectedSizesForProduct.length === 0) {
                    onSelectAllSizes(product);
                  }
                  onOpenSelection();
                }}
                className="w-full min-h-[42px] py-2.5 px-4 rounded-2xl bg-white border border-zinc-300 text-zinc-900 font-extrabold text-xs flex items-center justify-center gap-2 hover:bg-zinc-50 transition-all active:scale-95"
              >
                <ShoppingBag className="w-4 h-4 text-zinc-600" />
                {isSelected ? 'VOIR DANS MA SÉLECTION' : 'AJOUTER À MA SÉLECTION MULTI-MODÈLES'}
              </button>

              <button
                onClick={onClose}
                className="w-full min-h-[38px] py-2 px-4 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-600 font-medium text-xs transition-colors active:scale-95"
              >
                Continuer à parcourir le catalogue
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
