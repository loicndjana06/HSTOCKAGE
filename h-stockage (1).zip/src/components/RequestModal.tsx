import React, { useState } from 'react';
import { X, Send, CheckCircle2, MessageSquare, Building2, User, Mail, Phone, ShoppingBag, Sparkles, FileDown, Download } from 'lucide-react';
import { SelectionItem, InquiryRequest } from '../types';
import { addInquiryRequest } from '../services/storageService';
import { getStoredSettings, logEvent, addNotification } from '../services/eventService';
import { generateSelectionSummaryPdf } from '../services/pdfService';

interface RequestModalProps {
  isOpen: boolean;
  selectionItems: SelectionItem[];
  onClose: () => void;
  onRequestSubmitted: (newReq: InquiryRequest) => void;
}

export const RequestModal: React.FC<RequestModalProps> = ({
  isOpen,
  selectionItems,
  onClose,
  onRequestSubmitted,
}) => {
  const [formData, setFormData] = useState({
    clientName: '',
    email: '',
    phone: '',
    company: '',
    message: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedReq, setSubmittedReq] = useState<InquiryRequest | null>(null);

  const handleExportPdf = () => {
    if (selectionItems.length === 0) return;
    generateSelectionSummaryPdf(selectionItems, {
      company: formData.company?.trim() || undefined,
      contactName: formData.clientName?.trim() || undefined,
      email: formData.email?.trim() || undefined,
      phone: formData.phone?.trim() || undefined,
      notes: formData.message?.trim() || undefined,
      inquiryRef: submittedReq ? `DEM-${submittedReq.id}` : undefined,
      documentTitle: 'DEMANDE DE COTATION GROS B2B',
    });

    logEvent('SELECTION_PDF_DOWNLOADED', `Export PDF depuis formulaire cotation (${selectionItems.length} modèles)`, {
      clientEmail: formData.email || undefined,
      clientName: formData.clientName || undefined,
    });
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientName || !formData.phone || selectionItems.length === 0) return;

    const formattedItems = selectionItems.map((item) => ({
      productId: item.productId,
      name: item.product.name,
      brand: item.product.brand,
      sizes: item.selectedSizes.length > 0 ? item.selectedSizes : item.product.availableSizes,
    }));

    const newReq = addInquiryRequest({
      clientName: formData.clientName,
      email: formData.email,
      phone: formData.phone,
      company: formData.company,
      items: formattedItems,
      message: formData.message,
    });

    // Log event & notification
    logEvent('REQUEST_SENT', `Demande #${newReq.id} envoyée par ${formData.clientName} (${formData.email || formData.phone})`, {
      clientEmail: formData.email,
      clientName: formData.clientName,
    });

    addNotification({
      title: 'Nouvelle demande reçue',
      message: `${formData.clientName} a soumis une sélection de ${selectionItems.length} modèles.`,
      type: 'REQUEST',
      linkTab: 'requests',
    });

    setSubmittedReq(newReq);
    setIsSubmitted(true);
    onRequestSubmitted(newReq);
  };

  const handleWhatsAppRedirect = () => {
    const settings = getStoredSettings();
    const whatsappNum = settings.whatsappNumber.replace(/[^0-9]/g, '') || '33758521191';

    let formattedItemsList = '';
    let totalPallets = 0;
    selectionItems.forEach((it) => {
      const palCount = Math.max(1, it.palletCount || 1);
      totalPallets += palCount;
      const sizesStr =
        it.selectedSizes.length > 0
          ? `pointures : ${it.selectedSizes.sort((a, b) => a - b).join(', ')}`
          : 'mix standard';
      formattedItemsList += `\n• ${it.product.brand} ${it.product.name} : ${palCount} palette(s) (${palCount * 100} paires) — ${palCount * 350} € [${sizesStr}]`;
    });

    const totalPairs = totalPallets * 100;
    const subtotal = totalPallets * 350;

    const contactStr = `Coordonnées :\n- Nom : ${formData.clientName || 'Client Pro'}\n- Tél : ${formData.phone || 'Non précisé'}\n- Email : ${formData.email || 'Non précisé'}${formData.company ? `\n- Société : ${formData.company}` : ''}`;

    const text = `Bonjour H DESTOCKAGE,

Je souhaite faire une demande de commande pour ces modèles :
📦 DÉTAIL DE LA COMMANDE :${formattedItemsList}

- Total palettes : ${totalPallets} palette(s)
- Total paires : ${totalPairs} paires
- Sous-total marchandises : ${subtotal.toLocaleString('fr-FR')} € HT

${contactStr}

Règle respectée : 1 palette = 100 paires = 350 €.
Merci de me transmettre la disponibilité et les modalités de livraison.`;

    const encodedText = encodeURIComponent(text);

    logEvent('WHATSAPP_CLICK', `Redirection WhatsApp pour demande par ${formData.clientName || 'Client'}`, {
      clientEmail: formData.email,
      clientName: formData.clientName,
    });

    window.open(`https://wa.me/${whatsappNum}?text=${encodedText}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-zinc-900/60 backdrop-blur-sm overflow-y-auto animate-fade-in pb-safe">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl border border-zinc-200 shadow-2xl overflow-hidden p-5 sm:p-8 my-auto text-zinc-900 max-h-[94vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Fermer le formulaire"
          className="absolute top-4 right-4 text-zinc-500 hover:text-zinc-950 bg-zinc-100 hover:bg-zinc-200 p-2.5 rounded-full border border-zinc-200 active:scale-95 transition-all shadow-xs"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSubmitted ? (
          <div>
            <div className="mb-5 sm:mb-6 pr-8">
              <span className="bg-zinc-100 text-zinc-700 text-[11px] font-bold px-2.5 py-1 rounded uppercase tracking-widest border border-zinc-200 inline-block mb-2">
                Demande de Cotation Gros
              </span>
              <h2 className="text-xl sm:text-3xl font-black text-zinc-950 tracking-tight">
                Envoyer ma sélection à H DESTOCKAGE
              </h2>
              <p className="text-xs text-zinc-500 mt-1">
                Complétez vos coordonnées professionnelles. Notre équipe commerciale traitera votre demande en priorité.
              </p>
            </div>

            {/* Pre-populated Summary Box */}
            <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-3.5 sm:p-4 mb-5">
              <div className="flex items-center justify-between mb-2 gap-2 flex-wrap">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-700 flex items-center gap-1.5">
                  <ShoppingBag className="w-3.5 h-3.5 text-zinc-500" />
                  Modèles inclus dans la demande ({selectionItems.length})
                </span>
                <button
                  type="button"
                  id="request-modal-export-pdf-btn"
                  onClick={handleExportPdf}
                  className="text-xs font-bold text-zinc-800 hover:text-zinc-950 bg-white hover:bg-zinc-100 border border-zinc-300 rounded-lg px-2.5 py-1 flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer group"
                  title="Exporter la fiche récapitulative propre en PDF"
                >
                  <FileDown className="w-3.5 h-3.5 text-amber-700 group-hover:translate-y-0.5 transition-transform" />
                  <span>Exporter en PDF</span>
                </button>
              </div>

              <div className="max-h-36 overflow-y-auto space-y-2 pr-1">
                {selectionItems.map((item) => (
                  <div
                    key={item.productId}
                    className="flex items-center justify-between text-xs bg-white p-2.5 rounded-xl border border-zinc-200 shadow-2xs"
                  >
                    <div>
                      <span className="font-extrabold text-zinc-600 mr-1.5 uppercase">
                        {item.product.brand}
                      </span>
                      <span className="font-bold text-zinc-950">{item.product.name}</span>
                    </div>
                    <span className="text-[11px] font-mono text-zinc-600 bg-zinc-50 border border-zinc-200 px-2 py-0.5 rounded">
                      Pt: {item.selectedSizes.length > 0 ? item.selectedSizes.sort((a,b)=>a-b).join(' · ') : 'Toutes'}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-zinc-700 mb-1 flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-zinc-400" />
                    Nom / Prénom *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.clientName}
                    onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                    placeholder="Ex: Jean Dupont"
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3.5 py-3 text-base sm:text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-zinc-950 focus:bg-white transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-zinc-700 mb-1 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-zinc-400" />
                    Téléphone / WhatsApp *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="Ex: +33 6 12 34 56 78"
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3.5 py-3 text-base sm:text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-zinc-950 focus:bg-white transition-colors"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-zinc-700 mb-1 flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-zinc-400" />
                    E-mail professionnel
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="contact@boutique.com"
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3.5 py-3 text-base sm:text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-zinc-950 focus:bg-white transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-zinc-700 mb-1 flex items-center gap-1">
                    <Building2 className="w-3.5 h-3.5 text-zinc-400" />
                    Nom de l'entreprise (facultatif)
                  </label>
                  <input
                    type="text"
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    placeholder="Ex: Kicks Store Paris"
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3.5 py-3 text-base sm:text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-zinc-950 focus:bg-white transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-700 mb-1 flex items-center gap-1">
                  <MessageSquare className="w-3.5 h-3.5 text-zinc-400" />
                  Message complémentaire (quantités globales, ville, délais...)
                </label>
                <textarea
                  rows={3}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Ex: Bonjour, nous sommes une boutique basée à Lyon. Pouvez-vous nous indiquer la quantité minimale par lot ?"
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3.5 py-3 text-base sm:text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-zinc-950 focus:bg-white transition-colors"
                />
              </div>

              <div className="pt-3 flex flex-col sm:flex-row gap-3">
                <button
                  type="submit"
                  className="flex-1 min-h-[48px] py-3.5 px-4 rounded-xl bg-zinc-950 text-white font-extrabold text-sm flex items-center justify-center gap-2 hover:bg-zinc-800 active:scale-95 transition-all shadow-md"
                >
                  <Send className="w-4 h-4" />
                  ENVOYER MA DEMANDE
                </button>

                <button
                  type="button"
                  onClick={handleWhatsAppRedirect}
                  className="min-h-[48px] py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-300 animate-ping" />
                  Envoyer via WhatsApp Direct
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Confirmation Display */
          <div className="py-8 text-center space-y-6">
            <div className="w-20 h-20 bg-emerald-50 border border-emerald-200 rounded-full flex items-center justify-center mx-auto text-emerald-600 shadow-sm">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs font-mono font-bold text-emerald-700 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 inline-block mb-3">
                Réf. Demande : #{submittedReq?.id}
              </span>
              <h3 className="text-2xl sm:text-3xl font-black text-zinc-950 mb-3">
                Demande transmise avec succès !
              </h3>
              <p className="text-sm text-zinc-600 max-w-lg mx-auto leading-relaxed">
                « Votre demande a bien été envoyée à H DESTOCKAGE. Notre équipe reviendra vers vous rapidement. »
              </p>
            </div>

            <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 max-w-md mx-auto text-left text-xs space-y-1.5 text-zinc-700 font-mono">
              <div>
                <strong className="text-zinc-900">Client :</strong> {submittedReq?.clientName}
              </div>
              <div>
                <strong className="text-zinc-900">Téléphone / WhatsApp :</strong> {submittedReq?.phone}
              </div>
              <div>
                <strong className="text-zinc-900">Modèles :</strong> {submittedReq?.items.length} références sélectionnées
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto pt-2">
              <button
                type="button"
                id="request-modal-confirm-export-pdf-btn"
                onClick={handleExportPdf}
                className="w-full py-3 px-4 rounded-xl bg-zinc-950 hover:bg-zinc-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
                title="Télécharger la fiche récapitulative propre au format PDF"
              >
                <FileDown className="w-4 h-4 text-amber-400" />
                <span>Exporter en PDF</span>
              </button>
              <button
                onClick={handleWhatsAppRedirect}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer"
              >
                Ouvrir WhatsApp
              </button>
              <button
                onClick={() => {
                  setIsSubmitted(false);
                  onClose();
                }}
                className="w-full py-3 px-4 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-800 border border-zinc-200 font-bold text-xs transition-colors cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
