import React, { useState } from 'react';
import {
  Trash2,
  ShoppingBag,
  ArrowRight,
  Layers,
  ArrowLeft,
  Send,
  MessageCircle,
  Mail,
  Package,
  Plus,
  Minus,
  CheckCircle2,
  FileDown,
  Building2,
  User,
  Phone,
  X,
  Check,
  Download,
} from 'lucide-react';
import { SelectionItem, SneakerModel, WatermarkSettings } from '../types';
import { WatermarkOverlay } from './WatermarkOverlay';
import { getStoredSettings, logEvent } from '../services/eventService';
import { ENTERPRISE_WHATSAPP_RAW } from '../services/palletOrderService';
import { generateSelectionSummaryPdf, SelectionPdfOptions } from '../services/pdfService';

interface SelectionDrawerProps {
  items: SelectionItem[];
  watermarkSettings: WatermarkSettings;
  onRemoveItem: (productId: string) => void;
  onToggleSizeSelection: (product: SneakerModel, size: number) => void;
  onUpdatePalletCount?: (productId: string, delta: number) => void;
  onClearSelection: () => void;
  onOpenRequestModal: () => void;
  onNavigateToCollection: () => void;
  onStartOrder?: () => void;
}

export const SelectionDrawer: React.FC<SelectionDrawerProps> = ({
  items,
  watermarkSettings,
  onRemoveItem,
  onToggleSizeSelection,
  onUpdatePalletCount,
  onClearSelection,
  onOpenRequestModal,
  onNavigateToCollection,
  onStartOrder,
}) => {
  const [clientEmail, setClientEmail] = useState('');
  const [showPdfModal, setShowPdfModal] = useState(false);
  const [pdfCompany, setPdfCompany] = useState('');
  const [pdfContact, setPdfContact] = useState('');
  const [pdfPhone, setPdfPhone] = useState('');
  const [pdfSuccessToast, setPdfSuccessToast] = useState(false);

  // Calculations
  const totalPallets = items.reduce((sum, it) => sum + (it.palletCount || 1), 0);
  const totalPairs = totalPallets * 100;
  const merchandiseSubtotal = totalPallets * 350;

  const handleDownloadPdf = (useCustomInfo: boolean = true) => {
    if (items.length === 0) return;

    const options: SelectionPdfOptions = useCustomInfo
      ? {
          company: pdfCompany.trim() || undefined,
          contactName: pdfContact.trim() || undefined,
          email: clientEmail.trim() || undefined,
          phone: pdfPhone.trim() || undefined,
        }
      : {};

    generateSelectionSummaryPdf(items, options);

    logEvent('SELECTION_PDF_DOWNLOADED', `Export PDF de la sélection B2B (${items.length} modèles, ${totalPallets} palettes)`, {
      clientEmail: clientEmail || undefined,
      clientName: pdfContact || pdfCompany || undefined,
    });

    setShowPdfModal(false);
    setPdfSuccessToast(true);
    setTimeout(() => {
      setPdfSuccessToast(false);
    }, 4500);
  };

  const handleContinueWhatsApp = () => {
    if (items.length === 0) return;

    let formattedItemsList = '';
    items.forEach((it) => {
      const palCount = it.palletCount || 1;
      const pairCount = palCount * 100;
      const price = palCount * 350;
      const sizesStr =
        it.selectedSizes.length > 0
          ? `pointures : ${it.selectedSizes.sort((a, b) => a - b).join(', ')}`
          : 'mix assorti standard';
      formattedItemsList += `\n• ${it.product.brand} ${it.product.name} : ${palCount} palette(s) (${pairCount} paires) — ${price} € [${sizesStr}]`;
    });

    const emailPart = clientEmail ? `\nEmail de contact : ${clientEmail}` : '';

    const text = `Bonjour H DESTOCKAGE,

Je souhaite commander les lots de sneakers suivants :
📦 DÉTAIL DE LA COMMANDE :${formattedItemsList}

- Nombre de palettes : ${totalPallets} palette(s)
- Nombre de paires : ${totalPairs} paires neuves
- Sous-total marchandises : ${merchandiseSubtotal.toLocaleString('fr-FR')} € HT${emailPart}

Règle respectée : minimum 1 palette = 100 paires = 350 €.
Merci de me transmettre les modalités pour la livraison et le règlement.`;

    const encodedText = encodeURIComponent(text);

    logEvent('WHATSAPP_CLICK', `Clic WhatsApp direct pour commande ${totalPallets} palettes (${merchandiseSubtotal} € HT)`, {
      clientEmail: clientEmail || undefined,
    });

    window.open(`https://wa.me/${ENTERPRISE_WHATSAPP_RAW}?text=${encodedText}`, '_blank');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-10 text-zinc-900 animate-fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-zinc-200">
        <div>
          <button
            type="button"
            onClick={onNavigateToCollection}
            className="min-h-[44px] text-xs font-semibold text-zinc-600 hover:text-zinc-950 flex items-center gap-1.5 mb-1 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5 stroke-[1.75]" />
            Retour au catalogue
          </button>
          <h1 className="text-2xl sm:text-3xl font-bold text-zinc-950 tracking-tight flex items-center gap-3">
            <span>MA SÉLECTION GROS</span>
            {items.length > 0 && (
              <span className="bg-[#0C1022] text-white text-xs font-mono font-medium px-2.5 py-0.5 rounded-full">
                {items.length} {items.length > 1 ? 'modèles' : 'modèle'}
              </span>
            )}
          </h1>
          <p className="text-xs sm:text-sm text-zinc-500 mt-1">
            Configurez vos modèles et vos palettes (minimum 1 palette = 100 paires = 350 € HT par commande).
          </p>
        </div>

        {items.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <button
              id="header-export-selection-pdf-btn"
              type="button"
              onClick={() => setShowPdfModal(true)}
              className="min-h-[40px] text-xs text-zinc-800 hover:text-zinc-950 flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg border border-amber-300/80 bg-amber-50/80 hover:bg-amber-100 shadow-2xs transition-colors font-semibold group cursor-pointer"
              title="Exporter en PDF la fiche récapitulative de votre sélection"
            >
              <FileDown className="w-3.5 h-3.5 text-amber-700 stroke-[1.75]" />
              <span>Exporter en PDF</span>
            </button>

            <button
              type="button"
              onClick={onClearSelection}
              className="min-h-[40px] text-xs text-zinc-500 hover:text-rose-600 flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-zinc-200 hover:border-rose-200 bg-white shadow-2xs transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5 stroke-[1.75]" />
              Vider ma sélection
            </button>
          </div>
        )}
      </div>

      {/* Main List or Empty State */}
      {items.length === 0 ? (
        <div className="py-16 sm:py-24 text-center max-w-md mx-auto space-y-5">
          <div className="w-16 h-16 rounded-2xl bg-[#f4f5f7] border border-zinc-200 flex items-center justify-center mx-auto text-zinc-400 shadow-2xs">
            <ShoppingBag className="w-8 h-8 stroke-[1.5] text-zinc-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-zinc-950 mb-1.5">Votre sélection est vide</h3>
            <p className="text-xs text-zinc-500 leading-relaxed">
              Consultez notre catalogue de sneakers neuves et ajoutez vos modèles favoris pour passer commande par palette (100 paires = 350 € HT).
            </p>
          </div>
          <button
            type="button"
            onClick={onNavigateToCollection}
            className="min-h-[44px] py-2.5 px-6 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs inline-flex items-center gap-2 shadow-2xs transition-colors"
          >
            <span>EXPLORER LE CATALOGUE</span>
            <ArrowRight className="w-4 h-4 stroke-[1.75]" />
          </button>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Selected Products List */}
          <div className="lg:col-span-8 space-y-4">
            {/* Wholesale Rule Banner */}
            <div className="bg-[#0C1022] text-white rounded-xl p-4 flex items-center justify-between gap-4 shadow-xs border border-white/10">
              <div className="flex items-center gap-3">
                <Package className="w-5 h-5 text-emerald-400 shrink-0 stroke-[1.5]" />
                <div>
                  <span className="text-[10px] font-mono font-medium uppercase tracking-widest text-zinc-400 block">
                    Conditionnement B2B obligatoire
                  </span>
                  <p className="text-xs font-semibold text-white">
                    1 palette = 100 paires = 350 € HT
                  </p>
                </div>
              </div>
              <span className="text-[11px] font-mono bg-white/10 text-zinc-200 px-2.5 py-1 rounded border border-white/10 hidden sm:inline-block">
                Min. 1 palette
              </span>
            </div>

            {items.map((item) => {
              const { product, selectedSizes } = item;
              const palletCount = Math.max(1, item.palletCount || 1);
              const pairs = palletCount * 100;
              const price = palletCount * 350;

              return (
                <div
                  key={product.id}
                  className="bg-white rounded-xl border border-zinc-200/90 p-4 sm:p-5 flex flex-col gap-4 shadow-2xs relative overflow-hidden"
                >
                  <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                    {/* Left Info with Thumbnail */}
                    <div className="flex items-center gap-4 w-full sm:w-auto">
                      <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-lg overflow-hidden bg-[#f4f5f7] border border-zinc-200 shrink-0">
                        <img
                          src={product.images[0]}
                          alt={product.name}
                          className="w-full h-full object-cover select-none"
                          draggable={false}
                        />
                        <WatermarkOverlay settings={watermarkSettings} />
                      </div>

                      <div className="flex-1">
                        <span className="text-[10px] font-mono font-medium uppercase tracking-wider text-zinc-600 bg-zinc-100 px-2 py-0.5 rounded border border-zinc-200">
                          {product.brand}
                        </span>
                        <h3 className="text-base sm:text-lg font-bold text-zinc-950 mt-1">
                          {product.name}
                        </h3>
                        <p className="text-[11px] text-zinc-500 mt-0.5 line-clamp-1">
                          {product.description}
                        </p>
                      </div>
                    </div>

                    {/* Pallet Stepper on Product Card */}
                    <div className="flex items-center gap-4 self-end sm:self-center bg-[#f4f5f7] p-2 rounded-lg border border-zinc-200">
                      <div className="text-right">
                        <div className="text-xs font-mono font-bold text-zinc-950">
                          {price.toLocaleString('fr-FR')} € HT
                        </div>
                        <div className="text-[10px] font-mono text-zinc-500">
                          {palletCount} pal. ({pairs} paires)
                        </div>
                      </div>

                      <div className="flex items-center border border-zinc-300 rounded-md bg-white overflow-hidden shadow-2xs">
                        <button
                          type="button"
                          onClick={() => onUpdatePalletCount && onUpdatePalletCount(product.id, -1)}
                          disabled={palletCount <= 1}
                          className="w-7 h-7 flex items-center justify-center text-zinc-700 hover:bg-zinc-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                          title="Minimum 1 palette (100 paires)"
                        >
                          <Minus className="w-3 h-3 stroke-[1.75]" />
                        </button>
                        <span className="w-8 text-center text-xs font-mono font-bold text-zinc-950">
                          {palletCount}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdatePalletCount && onUpdatePalletCount(product.id, 1)}
                          className="w-7 h-7 flex items-center justify-center text-zinc-700 hover:bg-zinc-100 transition-colors"
                        >
                          <Plus className="w-3 h-3 stroke-[1.75]" />
                        </button>
                      </div>

                      {/* Remove Button */}
                      <button
                        type="button"
                        onClick={() => onRemoveItem(product.id)}
                        className="p-1.5 rounded-md text-zinc-400 hover:text-rose-600 hover:bg-rose-50 transition-colors ml-1 cursor-pointer"
                        title="Supprimer de ma sélection"
                        aria-label={`Supprimer ${product.name}`}
                      >
                        <Trash2 className="w-3.5 h-3.5 stroke-[1.75]" />
                      </button>
                    </div>
                  </div>

                  {/* Size Configurator */}
                  <div className="w-full bg-[#f4f5f7] p-3 rounded-lg border border-zinc-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="text-[11px] font-medium text-zinc-600 uppercase tracking-wider flex items-center gap-1">
                      <Layers className="w-3 h-3 text-zinc-400 stroke-[1.5]" />
                      Pointures souhaitées :
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {product.availableSizes.map((size) => {
                        const isChecked = selectedSizes.includes(size);
                        return (
                          <button
                            key={size}
                            type="button"
                            onClick={() => onToggleSizeSelection(product, size)}
                            className={`min-h-[30px] min-w-[30px] px-2 py-0.5 rounded text-xs font-mono font-semibold transition-colors flex items-center justify-center cursor-pointer ${
                              isChecked
                                ? 'bg-[#0C1022] text-white border border-[#0C1022] shadow-2xs'
                                : 'bg-white text-zinc-700 border border-zinc-200 hover:border-zinc-300 active:bg-zinc-100'
                            }`}
                          >
                            {size}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action Summary Panel */}
          <div className="lg:col-span-4 sticky top-24 bg-white rounded-xl border border-zinc-200/90 p-5 sm:p-6 shadow-xs space-y-4 sm:space-y-5">
            <div>
              <span className="text-[10px] font-mono font-medium uppercase tracking-wider text-zinc-600 bg-zinc-100 px-2 py-0.5 rounded border border-zinc-200">
                H DESTOCKAGE • RECAPITULATIF
              </span>
              <h3 className="text-lg sm:text-xl font-bold text-zinc-950 mt-1.5">
                Commande de Marchandises
              </h3>
              <p className="text-xs text-zinc-500 mt-1 leading-relaxed">
                Règle commerciale : 1 palette = 100 paires = 350 € HT. Frais de livraison calculés à l&apos;adresse de livraison.
              </p>
            </div>

            {/* Financial & Volume Breakdown */}
            <div className="space-y-2.5 border-y border-zinc-100 py-3.5 text-xs font-mono">
              <div className="flex justify-between text-zinc-600">
                <span>Modèles sélectionnés :</span>
                <span className="font-bold text-zinc-950">{items.length}</span>
              </div>
              <div className="flex justify-between text-zinc-600">
                <span>Nombre de palettes :</span>
                <span className="font-bold text-zinc-950">{totalPallets} palette(s)</span>
              </div>
              <div className="flex justify-between text-zinc-600">
                <span>Total de paires neuves :</span>
                <span className="font-bold text-zinc-950">{totalPairs} paires</span>
              </div>
              <div className="flex justify-between text-zinc-950 font-bold pt-2 border-t border-zinc-100 text-sm">
                <span>Sous-total Marchandises :</span>
                <span className="text-emerald-700">{merchandiseSubtotal.toLocaleString('fr-FR')} € HT</span>
              </div>
              <p className="text-[10px] text-zinc-500 font-sans pt-1">
                * Livraison calculée selon votre localisation (à partir de 106 €).
              </p>
            </div>

            {/* PRIMARY ACTION: COMMANDER (OPENS ORDER MODAL) */}
            <button
              type="button"
              onClick={() => {
                if (onStartOrder) {
                  onStartOrder();
                } else {
                  handleContinueWhatsApp();
                }
              }}
              className="w-full min-h-[48px] py-3 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-colors shadow-2xs cursor-pointer"
            >
              <span>COMMANDER ({totalPallets} PAL. — {merchandiseSubtotal} € HT)</span>
              <ArrowRight className="w-4 h-4 stroke-[1.75]" />
            </button>

            {/* SECONDARY ACTION: WHATSAPP OFFICIEL DIRECT */}
            <button
              type="button"
              onClick={handleContinueWhatsApp}
              className="w-full min-h-[44px] py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors shadow-2xs cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-emerald-900 text-white" />
              <span>Finaliser sur WhatsApp officiel</span>
            </button>

            {/* ACTION B2B: EXPORTER EN PDF */}
            <div className="pt-2 border-t border-zinc-100 space-y-2">
              <button
                type="button"
                id="export-selection-pdf-btn"
                onClick={() => setShowPdfModal(true)}
                className="w-full min-h-[44px] py-2.5 px-4 rounded-lg bg-[#0C1022] hover:bg-zinc-800 text-white font-semibold text-xs uppercase tracking-wider flex items-center justify-center gap-2.5 transition-colors shadow-2xs group cursor-pointer border border-white/10"
                title="Générer une fiche récapitulative propre de votre demande de cotation au format PDF"
              >
                <FileDown className="w-4 h-4 text-amber-400 stroke-[1.75]" />
                <span>Exporter en PDF</span>
              </button>
              <div className="flex items-center justify-between text-[11px] text-zinc-500 px-1">
                <span>Fiche récapitulative propre & cotation</span>
                <button
                  type="button"
                  onClick={() => handleDownloadPdf(false)}
                  className="font-semibold text-amber-800 hover:text-amber-950 underline underline-offset-2 flex items-center gap-1 cursor-pointer"
                  title="Téléchargement direct immédiat sans formulaire"
                >
                  <Download className="w-3 h-3 stroke-[1.75]" />
                  Téléchargement direct
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={onOpenRequestModal}
              className="w-full min-h-[40px] py-2 px-4 rounded-lg bg-[#f4f5f7] hover:bg-zinc-200 text-zinc-700 font-semibold text-xs flex items-center justify-center gap-2 border border-zinc-200 transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 stroke-[1.75]" />
              Demande de devis alternatif
            </button>

            <p className="text-[10px] text-zinc-400 text-center leading-tight">
              H DESTOCKAGE • Réservé aux professionnels et revendeurs. Vente exclusive par palettes.
            </p>
          </div>
        </div>
      )}

      {/* MODAL PERSONNALISATION ET EXPORT DU RÉCAPITULATIF PDF */}
      {showPdfModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in"
          onClick={() => setShowPdfModal(false)}
        >
          <div
            className="bg-white rounded-3xl border border-zinc-200 max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-5 text-zinc-900 relative animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-4 pb-3 border-b border-zinc-100">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                  DOCUMENT OFFICIEL B2B
                </span>
                <h3 className="text-lg sm:text-xl font-black text-zinc-950 mt-1">
                  Fiche Récapitulative & Cotation PDF
                </h3>
                <p className="text-xs text-zinc-500 mt-0.5">
                  Générez une fiche récapitulative propre au format A4 pour vos archives ou votre demande de cotation.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowPdfModal(false)}
                className="p-1.5 rounded-xl text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 transition-all cursor-pointer"
                aria-label="Fermer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Order Synthesis Pill */}
            <div className="bg-zinc-50 rounded-2xl p-3.5 border border-zinc-200 flex items-center justify-between gap-3 text-xs font-mono">
              <div>
                <span className="text-zinc-500 block text-[10px] uppercase tracking-wider">Volume sélectionné</span>
                <span className="font-bold text-zinc-950">
                  {items.length} modèle{items.length > 1 ? 's' : ''} • {totalPallets} palette{totalPallets > 1 ? 's' : ''} ({totalPairs} paires)
                </span>
              </div>
              <div className="text-right">
                <span className="text-zinc-500 block text-[10px] uppercase tracking-wider">Montant marchandises</span>
                <span className="font-extrabold text-emerald-700 text-sm">
                  {merchandiseSubtotal.toLocaleString('fr-FR')} € HT
                </span>
              </div>
            </div>

            {/* Optional Personalization Fields */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-zinc-900">
                  Mentions client (facultatives) :
                </span>
                <span className="text-[10px] text-zinc-400">
                  Apparaîtront dans l&apos;en-tête du document
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Société */}
                <div>
                  <label className="text-[11px] font-bold text-zinc-700 block mb-1">
                    Entreprise / Enseigne
                  </label>
                  <div className="relative">
                    <Building2 className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={pdfCompany}
                      onChange={(e) => setPdfCompany(e.target.value)}
                      placeholder="Ex: Sneakers Store SAS"
                      className="w-full pl-9 pr-3 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-xs focus:bg-white focus:border-zinc-950 focus:outline-hidden transition-all"
                    />
                  </div>
                </div>

                {/* Contact / Acheteur */}
                <div>
                  <label className="text-[11px] font-bold text-zinc-700 block mb-1">
                    Responsable / Acheteur
                  </label>
                  <div className="relative">
                    <User className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={pdfContact}
                      onChange={(e) => setPdfContact(e.target.value)}
                      placeholder="Ex: M. Dupont"
                      className="w-full pl-9 pr-3 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-xs focus:bg-white focus:border-zinc-950 focus:outline-hidden transition-all"
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="text-[11px] font-bold text-zinc-700 block mb-1">
                    E-mail professionnel
                  </label>
                  <div className="relative">
                    <Mail className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={clientEmail}
                      onChange={(e) => setClientEmail(e.target.value)}
                      placeholder="achats@sneakers.com"
                      className="w-full pl-9 pr-3 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-xs focus:bg-white focus:border-zinc-950 focus:outline-hidden transition-all"
                    />
                  </div>
                </div>

                {/* Téléphone */}
                <div>
                  <label className="text-[11px] font-bold text-zinc-700 block mb-1">
                    Téléphone / WhatsApp
                  </label>
                  <div className="relative">
                    <Phone className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={pdfPhone}
                      onChange={(e) => setPdfPhone(e.target.value)}
                      placeholder="+33 6 12 34 56 78"
                      className="w-full pl-9 pr-3 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-xs focus:bg-white focus:border-zinc-950 focus:outline-hidden transition-all"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Information Notice */}
            <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-3 text-[11px] text-amber-950 space-y-1 leading-relaxed">
              <p className="font-bold flex items-center gap-1.5 text-amber-900">
                <FileDown className="w-3.5 h-3.5 text-amber-700" />
                Contenu du récapitulatif PDF généré :
              </p>
              <p className="text-zinc-600">
                Le document compile la liste exacte de vos modèles, grilles de pointures choisies, volume en palettes et paires, conditions de livraison depuis notre entrepôt d&apos;Aulnay-sous-Bois (93600) et coordonnées officielles avec SIRET.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={() => handleDownloadPdf(true)}
                className="w-full min-h-[46px] py-3 px-5 rounded-2xl bg-zinc-950 hover:bg-zinc-800 active:scale-95 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
              >
                <Download className="w-4 h-4 text-amber-400" />
                <span>Télécharger la fiche récapitulative (PDF)</span>
              </button>

              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => handleDownloadPdf(false)}
                  className="text-xs text-zinc-500 hover:text-zinc-900 underline underline-offset-2 py-1 transition-colors cursor-pointer"
                >
                  Télécharger directement sans mentions personnalisées
                </button>

                <button
                  type="button"
                  onClick={() => setShowPdfModal(false)}
                  className="text-xs text-zinc-400 hover:text-zinc-600 py-1 transition-colors cursor-pointer"
                >
                  Annuler
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUCCESS FLOATING TOAST */}
      {pdfSuccessToast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-6 right-6 z-50 bg-zinc-950 text-white border border-zinc-800 shadow-2xl rounded-2xl p-4 flex items-center gap-3 animate-slide-up max-w-md"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
            <Check className="w-4 h-4" />
          </div>
          <div className="text-xs">
            <p className="font-bold text-white">Récapitulatif PDF téléchargé !</p>
            <p className="text-zinc-400 text-[11px]">
              Votre document est prêt pour l&apos;archivage ou le partage interne.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

