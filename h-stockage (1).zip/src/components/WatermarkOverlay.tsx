import React from 'react';
import { WatermarkSettings } from '../types';

interface WatermarkOverlayProps {
  settings: WatermarkSettings;
  customText?: string;
}

export const WatermarkOverlay: React.FC<WatermarkOverlayProps> = ({ settings, customText }) => {
  if (!settings.enabled) return null;

  const textToDisplay = customText || settings.clientWatermarkText || settings.text || 'H DESTOCKAGE';

  return (
    <div
      className="absolute inset-0 pointer-events-none select-none z-10 flex flex-col justify-between p-3 overflow-hidden"
      onContextMenu={(e) => e.preventDefault()}
      onDragStart={(e) => e.preventDefault()}
    >
      {/* Repeating subtle diagonal watermark text pattern */}
      <div className="absolute inset-0 flex items-center justify-center opacity-15 transform -rotate-25 pointer-events-none">
        <span className="text-white text-xs md:text-sm font-black tracking-widest uppercase text-center whitespace-nowrap bg-black/40 px-3 py-1 rounded backdrop-blur-xs border border-white/10 shadow-2xl">
          {textToDisplay} • WHOLESALE PRO
        </span>
      </div>

      {/* Discrete bottom corner watermark label */}
      <div className="mt-auto flex justify-between items-end w-full text-[10px] uppercase font-mono tracking-widest text-white/60 drop-shadow-md">
        <span className="bg-black/60 px-2 py-0.5 rounded backdrop-blur-md border border-white/10">
          H DESTOCKAGE
        </span>
        <span className="bg-black/60 px-2 py-0.5 rounded backdrop-blur-md border border-white/10">
          WHOLESALE ONLY
        </span>
      </div>
    </div>
  );
};
