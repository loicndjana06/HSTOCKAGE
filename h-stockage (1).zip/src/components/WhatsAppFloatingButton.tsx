import React from 'react';
import { MessageCircle } from 'lucide-react';
import { getStoredSettings, logEvent } from '../services/eventService';

export const WhatsAppFloatingButton: React.FC = () => {
  const handleClick = () => {
    const settings = getStoredSettings();
    const whatsappNum = settings.whatsappNumber.replace(/[^0-9]/g, '') || '33758521191';

    logEvent('WHATSAPP_CLICK', 'Clic sur le bouton flottant WhatsApp commercial');

    const defaultMsg = encodeURIComponent(
      'Bonjour H DESTOCKAGE,\n\nJe suis intéressé par vos palettes de sneakers neuves et votre déstockage grossiste. Pouvez-vous me renseigner ?\n\nMerci.'
    );

    window.open(`https://wa.me/${whatsappNum}?text=${defaultMsg}`, '_blank');
  };

  return (
    <div className="fixed bottom-[calc(4.75rem+env(safe-area-inset-bottom,0px))] md:bottom-6 right-4 sm:right-6 z-40 animate-fade-in">
      <button
        onClick={handleClick}
        aria-label="Contacter sur WhatsApp"
        className="group relative flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white p-3.5 sm:px-4 sm:py-3 rounded-full shadow-lg border border-emerald-500/40 transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer"
      >
        <MessageCircle className="w-5 h-5 fill-white/20 stroke-[2.2] transition-transform duration-200 group-hover:scale-110" />
        <span className="hidden sm:inline text-xs font-bold tracking-wide uppercase font-mono">
          WhatsApp
        </span>
      </button>
    </div>
  );
};
