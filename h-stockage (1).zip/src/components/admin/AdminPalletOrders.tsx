import React, { useState, useEffect } from 'react';
import {
  Package,
  Search,
  Filter,
  Eye,
  Download,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Truck,
  FileText,
  Clock,
  Shield,
  MessageCircle,
  X,
  Send,
  ExternalLink,
} from 'lucide-react';
import {
  PalletOrder,
  OrderStatus,
  ShippingConfig,
  BankPaymentDetails,
} from '../../types';
import {
  getStoredPalletOrders,
  saveStoredPalletOrders,
  updatePalletOrderStatus,
  reviewPaymentProof,
  getShippingConfig,
  getBankPaymentDetails,
  getCommercialWhatsAppNumber,
} from '../../services/palletOrderService';
import { generateOrderPdf } from '../../services/pdfService';

const ALL_ORDER_STATUSES: OrderStatus[] = [
  'En attente de paiement',
  'Paiement envoyé par le client',
  'Paiement en cours de vérification',
  'Paiement confirmé',
  'Commande en préparation',
  'Commande expédiée',
  'Commande livrée',
  'Commande annulée',
  'Commande créée',
  'Justificatif reçu',
  'Expédiée',
  'Livrée',
  'Paiement refusé ou justificatif invalide',
];

export const AdminPalletOrders: React.FC = () => {
  const [orders, setOrders] = useState<PalletOrder[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [selectedOrder, setSelectedOrder] = useState<PalletOrder | null>(null);

  // Status edit state in modal
  const [newStatus, setNewStatus] = useState<OrderStatus>('En attente de paiement');
  const [statusNote, setStatusNote] = useState('');
  const [carrierName, setCarrierName] = useState('');
  const [trackingNumber, setTrackingNumber] = useState('');

  // Rejection modal
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
  const [rejectionReasonInput, setRejectionReasonInput] = useState('');

  const config = getShippingConfig();
  const bankDetails = getBankPaymentDetails();
  const whatsappNumber = getCommercialWhatsAppNumber();

  const loadOrders = () => {
    setOrders(getStoredPalletOrders());
  };

  useEffect(() => {
    loadOrders();
  }, []);

  // Filtered orders
  const filteredOrders = orders.filter((order) => {
    const matchesStatus = statusFilter === 'ALL' || order.status === statusFilter;
    const q = searchQuery.toLowerCase().trim();
    if (!q) return matchesStatus;

    const matchesQuery =
      order.id.toLowerCase().includes(q) ||
      `${order.customer.firstName} ${order.customer.lastName}`.toLowerCase().includes(q) ||
      order.customer.email.toLowerCase().includes(q) ||
      order.customer.city.toLowerCase().includes(q) ||
      order.customer.postalCode.includes(q) ||
      (order.customer.company && order.customer.company.toLowerCase().includes(q));

    return matchesStatus && matchesQuery;
  });

  // KPI calculations
  const totalRevenue = orders
    .filter((o) => ['Paiement confirmé', 'Commande en préparation', 'Expédiée', 'Livrée'].includes(o.status))
    .reduce((acc, o) => acc + o.totalAmount, 0);

  const pendingProofCount = orders.filter((o) => o.status === 'Justificatif reçu' || o.status === 'Paiement en cours de vérification').length;
  const pendingPaymentCount = orders.filter((o) => o.status === 'En attente de paiement').length;

  const handleOpenOrderModal = (order: PalletOrder) => {
    setSelectedOrder(order);
    setNewStatus(order.status);
    setStatusNote('');
    setCarrierName(order.carrierName || 'Geodis / Schenker');
    setTrackingNumber(order.trackingNumber || '');
  };

  const handleUpdateStatusSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder) return;

    const updated = updatePalletOrderStatus(
      selectedOrder.id,
      newStatus,
      statusNote.trim() || undefined,
      trackingNumber.trim() || undefined,
      carrierName.trim() || undefined
    );

    if (updated) {
      setSelectedOrder(updated);
      loadOrders();
      setStatusNote('');
      alert(`Statut de la commande ${updated.id} mis à jour : ${newStatus}`);
    }
  };

  const handleConfirmPayment = () => {
    if (!selectedOrder) return;
    if (confirm(`Confirmer la réception définitive du paiement pour la commande ${selectedOrder.id} ?`)) {
      const updated = reviewPaymentProof(selectedOrder.id, 'CONFIRM');
      if (updated) {
        setSelectedOrder(updated);
        loadOrders();
        alert('Paiement confirmé ! Facture définitive prête à l\'émission.');
      }
    }
  };

  const handleOpenRejectModal = () => {
    setRejectionReasonInput('Document illisible ou virement non constaté sur notre relevé bancaire.');
    setIsRejectModalOpen(true);
  };

  const handleConfirmReject = () => {
    if (!selectedOrder || !rejectionReasonInput.trim()) return;
    const updated = reviewPaymentProof(selectedOrder.id, 'REJECT', rejectionReasonInput.trim());
    if (updated) {
      setSelectedOrder(updated);
      loadOrders();
      setIsRejectModalOpen(false);
      alert('Justificatif refusé. Notification enregistrée pour le client.');
    }
  };

  const getStatusBadgeClass = (status: OrderStatus) => {
    switch (status) {
      case 'Paiement confirmé':
      case 'Livrée':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      case 'Paiement refusé ou justificatif invalide':
      case 'Commande annulée':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'Justificatif reçu':
      case 'Paiement en cours de vérification':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'Commande en préparation':
      case 'Expédiée':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      default:
        return 'bg-zinc-800 text-zinc-300 border-zinc-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Total Commandes</span>
          <span className="text-2xl font-black text-white">{orders.length}</span>
          <span className="text-[10px] text-zinc-500 block mt-1">Toutes périodes confondues</span>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">En attente de paiement</span>
          <span className="text-2xl font-black text-amber-400">{pendingPaymentCount}</span>
          <span className="text-[10px] text-zinc-500 block mt-1">Facture pro forma transmise</span>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Justificatifs à valider</span>
          <span className="text-2xl font-black text-blue-400">{pendingProofCount}</span>
          <span className="text-[10px] text-zinc-500 block mt-1">Preuves reçues à contrôler</span>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Chiffre d'Affaires Encaissé</span>
          <span className="text-2xl font-black text-emerald-400 font-mono">{totalRevenue.toFixed(2)} €</span>
          <span className="text-[10px] text-zinc-500 block mt-1">Paiements vérifiés</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-zinc-900 border border-zinc-800 p-4 rounded-2xl">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Rechercher par N° commande, client, ville..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-zinc-500 focus:border-white focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-zinc-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:border-white focus:outline-none w-full sm:w-auto font-medium"
          >
            <option value="ALL">Tous les statuts ({orders.length})</option>
            {ALL_ORDER_STATUSES.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-sm">
        {filteredOrders.length === 0 ? (
          <div className="p-12 text-center text-zinc-500 text-xs">
            <Package className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
            <p>Aucune commande de palettes trouvée avec ces critères.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-zinc-300">
              <thead className="bg-zinc-950 text-zinc-400 font-mono text-[10px] uppercase border-b border-zinc-800">
                <tr>
                  <th className="py-3 px-4">Commande</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Client</th>
                  <th className="py-3 px-4">Destination</th>
                  <th className="py-3 px-4 text-center">Palettes</th>
                  <th className="py-3 px-4 text-right">Montant</th>
                  <th className="py-3 px-4">Statut</th>
                  <th className="py-3 px-4 text-center">Justificatif</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-zinc-800/50 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-white">
                      {order.id}
                    </td>
                    <td className="py-3 px-4 text-zinc-400 whitespace-nowrap">
                      {order.formattedDate}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">{order.customer.firstName} {order.customer.lastName}</div>
                      <div className="text-[11px] text-zinc-400">{order.customer.email}</div>
                      {order.customer.company && (
                        <div className="text-[10px] text-zinc-500 font-mono">{order.customer.company}</div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <div>{order.customer.city} ({order.customer.postalCode})</div>
                      <div className="text-[10px] text-zinc-500">
                        {order.deliveryZoneType === 'REMOTE' ? 'Zone Éloignée' : order.deliveryIsQuoteRequired ? 'Sur devis' : 'Zone Standard'}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-bold text-white">
                      {order.palletCount}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-white whitespace-nowrap">
                      {order.totalAmount.toFixed(2)} €
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadgeClass(order.status)}`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      {order.paymentProof ? (
                        <span className="inline-flex items-center gap-1 text-[10px] text-blue-400 font-bold bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                          Reçu
                        </span>
                      ) : (
                        <span className="text-[10px] text-zinc-500 font-mono">—</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={() => handleOpenOrderModal(order)}
                        className="px-3 py-1.5 bg-white text-black hover:bg-zinc-200 font-bold rounded-lg text-xs transition-all mr-2"
                      >
                        Traiter
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* DETAILED ORDER MANAGEMENT MODAL */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-zinc-900 border border-zinc-700 rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 space-y-6 text-white animate-fade-in shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-zinc-800 pb-4">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-xl font-black font-mono text-white">
                    COMMANDE {selectedOrder.id}
                  </h2>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${getStatusBadgeClass(selectedOrder.status)}`}>
                    {selectedOrder.status}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Créée le {selectedOrder.formattedDate} • Client : {selectedOrder.customer.firstName} {selectedOrder.customer.lastName}
                </p>
              </div>

              <button
                onClick={() => setSelectedOrder(null)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Action PDF Downloads */}
            <div className="flex flex-wrap gap-2 pt-1">
              <button
                type="button"
                onClick={() => generateOrderPdf(selectedOrder, bankDetails, config, false)}
                className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold rounded-lg flex items-center gap-1.5 border border-zinc-700"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Facture Pro Forma (PDF)</span>
              </button>

              <button
                type="button"
                onClick={() => generateOrderPdf(selectedOrder, bankDetails, config, true)}
                className="px-3 py-1.5 bg-emerald-600/30 text-emerald-300 hover:bg-emerald-600/40 text-xs font-bold rounded-lg flex items-center gap-1.5 border border-emerald-500/30"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Facture Acquittée Définitive (PDF)</span>
              </button>
            </div>

            {/* Customer & Address Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-zinc-950 p-4 rounded-2xl border border-zinc-800">
              <div className="space-y-1.5">
                <span className="font-mono text-[10px] uppercase text-zinc-500 block font-bold">Informations Client</span>
                <p className="font-bold text-white">{selectedOrder.customer.firstName} {selectedOrder.customer.lastName}</p>
                {selectedOrder.customer.company && (
                  <p className="text-zinc-400">Société : <strong className="text-white">{selectedOrder.customer.company}</strong></p>
                )}
                <p className="text-zinc-400">E-mail : <strong className="text-white">{selectedOrder.customer.email}</strong></p>
                <p className="text-zinc-400">Tél : <strong className="text-white font-mono">{selectedOrder.customer.phone}</strong></p>
                <p className="text-zinc-400">WhatsApp : <strong className="text-white font-mono">{selectedOrder.customer.whatsapp}</strong></p>
              </div>

              <div className="space-y-1.5">
                <span className="font-mono text-[10px] uppercase text-zinc-500 block font-bold">Adresse de Livraison</span>
                <p className="font-bold text-white">{selectedOrder.customer.deliveryAddress}</p>
                <p className="text-zinc-300">{selectedOrder.customer.postalCode} {selectedOrder.customer.city}</p>
                <p className="text-zinc-400">{selectedOrder.customer.country}</p>
                <p className="text-[11px] text-zinc-500">
                  Zone : {selectedOrder.deliveryZoneType === 'REMOTE' ? 'Éloignée (96 €)' : selectedOrder.deliveryIsQuoteRequired ? 'Sur devis' : 'Standard (66 €)'}
                </p>
                {selectedOrder.customer.deliveryInstructions && (
                  <p className="text-[10px] text-zinc-400 italic bg-zinc-900 p-2 rounded border border-zinc-800">
                    Instructions : {selectedOrder.customer.deliveryInstructions}
                  </p>
                )}
              </div>
            </div>

            {/* Palettes Composition Details */}
            {((selectedOrder.palletsComposition && selectedOrder.palletsComposition.length > 0) || (selectedOrder.items && selectedOrder.items.length > 0)) && (
              <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 text-xs space-y-3">
                <span className="font-mono text-[10px] uppercase text-zinc-500 block font-bold">
                  Composition des Palettes ({selectedOrder.palletCount} pal. • {selectedOrder.totalPairs || selectedOrder.palletCount * 100} paires)
                </span>
                <div className="space-y-2">
                  {(selectedOrder.palletsComposition || selectedOrder.items || []).map((pal: any, pIdx: number) => {
                    const isMixed = pal.type === 'MIXED' || pal.palletType === 'MIXED' || Boolean(pal.mixedLots && pal.mixedLots.length > 0);
                    const mixedLots = pal.mixedLots;
                    return (
                      <div key={pIdx} className="bg-zinc-900 p-3 rounded-xl border border-zinc-800 space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-white">
                            Palette {pIdx + 1} : {isMixed ? 'Palette Mixte (4 lots de 25 paires)' : `${pal.brand || selectedOrder.brand} - ${pal.model || selectedOrder.model}`}
                          </span>
                          <span className="font-mono text-zinc-400">100 paires • 350 € HT</span>
                        </div>
                        {isMixed && mixedLots && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1.5 border-t border-zinc-800/80 text-[11px] text-zinc-300">
                            {mixedLots.map((lot: any, lIdx: number) => (
                              <div key={lIdx} className="bg-zinc-950/80 px-2.5 py-1 rounded border border-zinc-800">
                                <span className="font-mono text-zinc-500 mr-1.5">Lot {lot.lotIndex || lIdx + 1} (25p):</span>
                                <strong className="text-white">{lot.brand}</strong> {lot.model}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Financial Details */}
            <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 text-xs space-y-1.5">
              <span className="font-mono text-[10px] uppercase text-zinc-500 block font-bold">Détail Financier</span>
              <div className="flex justify-between text-zinc-400">
                <span>{selectedOrder.palletCount} palette(s) × {selectedOrder.palletUnitPrice.toFixed(2)} €</span>
                <span className="font-mono text-white font-bold">{selectedOrder.merchandiseSubtotal.toFixed(2)} €</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Frais de livraison {selectedOrder.deliveryZoneType === 'REMOTE' ? '(Base 66€ + Supp. 30€)' : '(Standard)'}</span>
                <span className="font-mono text-white font-bold">{selectedOrder.deliveryIsQuoteRequired ? 'Sur devis' : `${selectedOrder.deliveryFee.toFixed(2)} €`}</span>
              </div>
              <div className="border-t border-zinc-800 pt-2 flex justify-between text-sm font-black text-white">
                <span>TOTAL À PAYER :</span>
                <span className="font-mono text-emerald-400 text-base">{selectedOrder.totalAmount.toFixed(2)} €</span>
              </div>
            </div>

            {/* PAYMENT PROOF REVIEW SECTION */}
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 space-y-4">
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-zinc-400" />
                Vérification du Justificatif de Paiement
              </h3>

              {selectedOrder.paymentProof ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-zinc-900 p-3 rounded-xl border border-zinc-800">
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase block font-mono">Moyen</span>
                      <strong className="text-white">{selectedOrder.paymentProof.paymentMethod}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase block font-mono">Émetteur</span>
                      <strong className="text-white">{selectedOrder.paymentProof.senderName}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase block font-mono">Réf. Virement</span>
                      <strong className="text-white font-mono">{selectedOrder.paymentProof.transactionReference}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase block font-mono">Montant payé</span>
                      <strong className="text-emerald-400 font-mono">{selectedOrder.paymentProof.paidAmount} €</strong>
                    </div>
                  </div>

                  {/* Proof Attachment Preview */}
                  <div>
                    <span className="text-[10px] font-mono text-zinc-400 uppercase block mb-1">
                      Fichier joint ({selectedOrder.paymentProof.fileName}) :
                    </span>
                    {selectedOrder.paymentProof.fileType.startsWith('image/') ? (
                      <div className="bg-zinc-900 p-2 rounded-xl border border-zinc-800 max-w-sm">
                        <img
                          src={selectedOrder.paymentProof.fileData}
                          alt="Justificatif"
                          className="max-h-56 rounded-lg w-auto mx-auto object-contain cursor-pointer"
                          onClick={() => window.open(selectedOrder.paymentProof?.fileData, '_blank')}
                        />
                        <span className="text-[10px] text-zinc-500 block text-center mt-1">
                          Cliquer sur l'image pour agrandir
                        </span>
                      </div>
                    ) : (
                      <a
                        href={selectedOrder.paymentProof.fileData}
                        download={selectedOrder.paymentProof.fileName}
                        className="inline-flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-white rounded-xl"
                      >
                        <Download className="w-4 h-4" />
                        <span>Télécharger le justificatif ({selectedOrder.paymentProof.fileName})</span>
                      </a>
                    )}
                  </div>

                  {/* Decision Buttons (Confirm or Refuse) */}
                  <div className="pt-2 flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={handleConfirmPayment}
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-sm"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Valider & Confirmer le paiement</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleOpenRejectModal}
                      className="px-4 py-2.5 bg-rose-600/30 text-rose-300 hover:bg-rose-600/40 border border-rose-500/30 font-bold text-xs rounded-xl flex items-center gap-2"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>Refuser le justificatif</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-zinc-900 rounded-xl text-xs text-zinc-500 italic">
                  Aucun justificatif de paiement n'a encore été téléversé par le client pour cette commande.
                </div>
              )}
            </div>

            {/* STATUS & LOGISTICS UPDATE FORM */}
            <form onSubmit={handleUpdateStatusSubmit} className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 space-y-4">
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <Truck className="w-4 h-4 text-zinc-400" />
                Mettre à jour le Statut & Logistique
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-zinc-400 font-bold uppercase tracking-wider mb-1">
                    Statut de la commande
                  </label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as OrderStatus)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2.5 text-xs text-white focus:border-white focus:outline-none font-medium"
                  >
                    {ALL_ORDER_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-zinc-400 font-bold uppercase tracking-wider mb-1">
                    Transporteur assigné
                  </label>
                  <input
                    type="text"
                    placeholder="Ex : Geodis / Schenker / Dachser"
                    value={carrierName}
                    onChange={(e) => setCarrierName(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2.5 text-xs text-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-zinc-400 font-bold uppercase tracking-wider mb-1">
                    Numéro de suivi d'expédition (Tracking)
                  </label>
                  <input
                    type="text"
                    placeholder="Ex : GEO-FR-84920491"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2.5 text-xs text-white font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-zinc-400 font-bold uppercase tracking-wider mb-1">
                    Note interne / Commentaire pour l'historique
                  </label>
                  <input
                    type="text"
                    placeholder="Ex : Virement bien reçu, palette chargée sur camion Geodis ce matin."
                    value={statusNote}
                    onChange={(e) => setStatusNote(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2.5 text-xs text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-white text-black hover:bg-zinc-200 font-bold text-xs rounded-xl shadow-xs transition-all"
                >
                  Enregistrer les modifications
                </button>
              </div>
            </form>

            {/* ORDER HISTORY TIMELINE */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold uppercase font-mono text-zinc-400 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                Journal des événements & Traçabilité
              </h4>
              <div className="space-y-2">
                {selectedOrder.history.map((h, i) => (
                  <div key={i} className="text-xs border-l-2 border-zinc-700 pl-3 py-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{h.status}</span>
                      <span className="text-[10px] text-zinc-500 font-mono">{h.timestamp}</span>
                    </div>
                    {h.note && <p className="text-zinc-400 text-[11px] mt-0.5">{h.note}</p>}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* REJECTION REASON MODAL */}
      {isRejectModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-700 rounded-2xl max-w-md w-full p-6 space-y-4 text-white animate-fade-in shadow-2xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-400" />
              Motif du refus du justificatif
            </h3>
            <p className="text-xs text-zinc-400">
              Indiquez la raison pour laquelle le justificatif est refusé. Cette explication sera transmise au client dans son suivi et dans le journal des notifications.
            </p>

            <textarea
              rows={3}
              value={rejectionReasonInput}
              onChange={(e) => setRejectionReasonInput(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-3 text-xs text-white focus:border-rose-400 focus:outline-none"
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsRejectModalOpen(false)}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold rounded-xl"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleConfirmReject}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl"
              >
                Confirmer le refus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
