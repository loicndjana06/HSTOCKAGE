import React, { useState } from 'react';
import {
  DollarSign,
  Truck,
  Building,
  Phone,
  Save,
  CheckCircle2,
  Plus,
  Trash2,
  AlertTriangle,
  History,
  Mail,
} from 'lucide-react';
import { ShippingConfig, BankPaymentDetails, OrderNotificationLog } from '../../types';
import {
  getShippingConfig,
  saveShippingConfig,
  getBankPaymentDetails,
  saveBankPaymentDetails,
  getCommercialWhatsAppNumber,
  saveCommercialWhatsAppNumber,
  getStoredNotifications,
} from '../../services/palletOrderService';

export const AdminPalletSettings: React.FC = () => {
  const [shippingConfig, setShippingConfig] = useState<ShippingConfig>(getShippingConfig());
  const [bankDetails, setBankDetails] = useState<BankPaymentDetails>(getBankPaymentDetails());
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getCommercialWhatsAppNumber());
  const [notifications, setNotifications] = useState<OrderNotificationLog[]>(getStoredNotifications());

  const [newPrefixInput, setNewPrefixInput] = useState('');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState(false);

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();
    saveShippingConfig(shippingConfig);
    saveBankPaymentDetails(bankDetails);
    saveCommercialWhatsAppNumber(whatsappNumber);
    setSaveSuccessMsg(true);
    setTimeout(() => setSaveSuccessMsg(false), 3000);
  };

  const handleAddPrefix = () => {
    const val = newPrefixInput.trim();
    if (!val) return;
    if (!shippingConfig.remotePostalPrefixes.includes(val)) {
      setShippingConfig({
        ...shippingConfig,
        remotePostalPrefixes: [...shippingConfig.remotePostalPrefixes, val],
      });
    }
    setNewPrefixInput('');
  };

  const handleRemovePrefix = (prefix: string) => {
    setShippingConfig({
      ...shippingConfig,
      remotePostalPrefixes: shippingConfig.remotePostalPrefixes.filter((p) => p !== prefix),
    });
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {saveSuccessMsg && (
        <div className="p-4 bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 rounded-2xl flex items-center gap-2 text-xs font-bold">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Tous les paramètres de facturation, livraison et coordonnées ont été enregistrés avec succès !</span>
        </div>
      )}

      <form onSubmit={handleSaveAll} className="space-y-8">
        {/* TARIFS PALETTES & FRAIS DE LIVRAISON */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-zinc-800 rounded-xl text-white">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Tarifs Palettes & Règles de Livraison
              </h3>
              <p className="text-xs text-zinc-400">
                Ces montants s'appliquent automatiquement dans le calcul du panier sans toucher au code source.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Prix unitaire par palette (€ HT) *
              </label>
              <input
                type="number"
                step="1"
                min="1"
                value={shippingConfig.palletUnitPrice}
                onChange={(e) =>
                  setShippingConfig({ ...shippingConfig, palletUnitPrice: parseFloat(e.target.value) || 350 })
                }
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white font-mono font-bold focus:border-white focus:outline-none"
              />
              <span className="text-[10px] text-zinc-500 block mt-1">Défaut contractuel : 350 €</span>
            </div>

            <div>
              <label className="block font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Frais de livraison base France (€) *
              </label>
              <input
                type="number"
                step="0.5"
                min="0"
                value={shippingConfig.baseFee}
                onChange={(e) =>
                  setShippingConfig({ ...shippingConfig, baseFee: parseFloat(e.target.value) || 66 })
                }
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white font-mono font-bold focus:border-white focus:outline-none"
              />
              <span className="text-[10px] text-zinc-500 block mt-1">Défaut métropole standard : 66 €</span>
            </div>

            <div>
              <label className="block font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Supplément zone éloignée (€) *
              </label>
              <input
                type="number"
                step="0.5"
                min="0"
                value={shippingConfig.remoteFeeSupplement}
                onChange={(e) =>
                  setShippingConfig({ ...shippingConfig, remoteFeeSupplement: parseFloat(e.target.value) || 30 })
                }
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white font-mono font-bold focus:border-white focus:outline-none"
              />
              <span className="text-[10px] text-zinc-500 block mt-1">Total zone éloignée : {shippingConfig.baseFee + shippingConfig.remoteFeeSupplement} € (66 + 30 = 96 €)</span>
            </div>
          </div>

          {/* Remote postal prefixes tags */}
          <div className="pt-4 border-t border-zinc-800 space-y-3">
            <label className="block font-bold text-zinc-300 uppercase tracking-wider text-xs">
              Départements / Préfixes postaux déclenchant le supplément éloigné (ex: 20 pour Corse, haute montagne) :
            </label>

            <div className="flex flex-wrap gap-2 items-center">
              {shippingConfig.remotePostalPrefixes.map((prefix) => (
                <span
                  key={prefix}
                  className="bg-zinc-800 text-zinc-200 border border-zinc-700 px-2.5 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5"
                >
                  <span>{prefix}</span>
                  <button
                    type="button"
                    onClick={() => handleRemovePrefix(prefix)}
                    className="text-zinc-400 hover:text-rose-400"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>

            <div className="flex items-center gap-2 max-w-xs pt-1">
              <input
                type="text"
                placeholder="Ajouter préfixe (ex: 29, 05...)"
                value={newPrefixInput}
                onChange={(e) => setNewPrefixInput(e.target.value)}
                className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white font-mono flex-1 focus:border-white focus:outline-none"
              />
              <button
                type="button"
                onClick={handleAddPrefix}
                className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs rounded-xl flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Ajouter</span>
              </button>
            </div>
          </div>
        </div>

        {/* COORDONNÉES BANCAIRES OFFICIELLES */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-zinc-800 rounded-xl text-white">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Coordonnées Bancaires Officielles (Virements & Dépôts)
              </h3>
              <p className="text-xs text-zinc-400">
                Transmises aux clients sur la page de paiement sécurisée et apposées sur les factures pro forma PDF.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Nom de la banque
              </label>
              <input
                type="text"
                value={bankDetails.bankName}
                onChange={(e) => setBankDetails({ ...bankDetails, bankName: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white focus:border-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Titulaire officiel du compte (Bénéficiaire)
              </label>
              <input
                type="text"
                value={bankDetails.accountHolder}
                onChange={(e) => setBankDetails({ ...bankDetails, accountHolder: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white font-bold focus:border-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                IBAN
              </label>
              <input
                type="text"
                value={bankDetails.iban}
                onChange={(e) => setBankDetails({ ...bankDetails, iban: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white font-mono font-bold focus:border-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                BIC / SWIFT
              </label>
              <input
                type="text"
                value={bankDetails.bic}
                onChange={(e) => setBankDetails({ ...bankDetails, bic: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white font-mono focus:border-white focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Adresse de l'agence bancaire (Optionnel)
              </label>
              <input
                type="text"
                value={bankDetails.branchAddress || ''}
                onChange={(e) => setBankDetails({ ...bankDetails, branchAddress: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white focus:border-white focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* NUMÉRO WHATSAPP SERVICE CLIENT */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-zinc-800 rounded-xl text-emerald-400">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Numéro WhatsApp Service Client
              </h3>
              <p className="text-xs text-zinc-400">
                Utilisé pour le bouton « Contacter le service client sur WhatsApp » après validation de commande.
              </p>
            </div>
          </div>

          <div className="max-w-md text-xs">
            <input
              type="text"
              value={whatsappNumber}
              onChange={(e) => setWhatsappNumber(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white font-mono font-bold focus:border-white focus:outline-none"
            />
            <span className="text-[10px] text-zinc-500 block mt-1">
              Format international préconisé (ex : +33 6 05 61 64 60).
            </span>
          </div>
        </div>

        {/* Bouton de Sauvegarde */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-8 py-3.5 bg-white text-black hover:bg-zinc-200 font-extrabold text-xs sm:text-sm rounded-2xl shadow-lg transition-all flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Enregistrer tous les paramètres</span>
          </button>
        </div>
      </form>

      {/* JOURNAL DES NOTIFICATIONS COMMANDES */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-zinc-800 rounded-xl text-zinc-300">
            <Mail className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-white">
              Journal des Notifications & Alertes Clients ({notifications.length})
            </h3>
            <p className="text-xs text-zinc-400">
              Historique horodaté des e-mails et messages transmis aux clients à chaque étape de leur commande.
            </p>
          </div>
        </div>

        {notifications.length === 0 ? (
          <p className="text-xs text-zinc-500 italic p-4">Aucune notification enregistrée pour l'instant.</p>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {notifications.slice(0, 15).map((notif) => (
              <div
                key={notif.id}
                className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl text-xs space-y-1"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white text-[11px]">{notif.orderId}</span>
                    <span className="text-[10px] text-zinc-400">→ {notif.recipientEmail}</span>
                  </div>
                  <span className="font-mono text-[10px] text-zinc-500">{notif.sentAt}</span>
                </div>
                <p className="text-zinc-300 font-semibold text-[11px]">{notif.subject}</p>
                <p className="text-zinc-500 text-[10px]">{notif.content}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
