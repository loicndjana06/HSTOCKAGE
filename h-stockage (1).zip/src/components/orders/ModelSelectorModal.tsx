import React, { useState, useMemo } from 'react';
import { X, Search, Check, Layers, Filter } from 'lucide-react';
import { SneakerModel, WatermarkSettings } from '../../types';
import { getStoredProducts } from '../../services/storageService';
import { WatermarkOverlay } from '../WatermarkOverlay';

interface ModelSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectModel: (model: SneakerModel) => void;
  title?: string;
  subtitle?: string;
  pairCountLabel?: string;
  currentSelectedId?: string;
  watermarkSettings?: WatermarkSettings | null;
}

export const ModelSelectorModal: React.FC<ModelSelectorModalProps> = ({
  isOpen,
  onClose,
  onSelectModel,
  title = 'Choisir un modèle dans le catalogue',
  subtitle = 'Sélectionnez le modèle à inclure dans votre palette',
  pairCountLabel = '25 paires',
  currentSelectedId,
  watermarkSettings,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string>('ALL');

  const allProducts = useMemo(() => {
    return getStoredProducts();
  }, [isOpen]);

  const brands = useMemo(() => {
    const set = new Set<string>();
    allProducts.forEach((p) => {
      if (p.brand) set.add(p.brand);
    });
    return Array.from(set).sort();
  }, [allProducts]);

  const filteredProducts = useMemo(() => {
    return allProducts.filter((product) => {
      const matchesBrand = selectedBrand === 'ALL' || product.brand.toLowerCase() === selectedBrand.toLowerCase();
      const matchesSearch =
        searchTerm.trim() === '' ||
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (product.reference && product.reference.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchesBrand && matchesSearch;
    });
  }, [allProducts, selectedBrand, searchTerm]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl border border-zinc-200 w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-200 flex items-start justify-between gap-4 bg-zinc-50/80">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-zinc-950 text-white text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded">
                {pairCountLabel}
              </span>
              <span className="text-[11px] text-zinc-500 font-mono">Catalogue B2B Grossiste</span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-zinc-950">{title}</h3>
            <p className="text-xs text-zinc-600 mt-0.5">{subtitle}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-200 hover:bg-zinc-300 flex items-center justify-center text-zinc-700 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Filters and Search */}
        <div className="p-4 border-b border-zinc-200 space-y-3 bg-white">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Rechercher par marque ou modèle (ex: Air Max, Samba, 9060...)"
              className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-xs text-zinc-950 placeholder:text-zinc-400 focus:outline-none focus:border-zinc-950"
              autoFocus
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Brand pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            <button
              type="button"
              onClick={() => setSelectedBrand('ALL')}
              className={`px-3 py-1 rounded-lg font-bold whitespace-nowrap transition-all ${
                selectedBrand === 'ALL'
                  ? 'bg-zinc-950 text-white shadow-xs'
                  : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
              }`}
            >
              Toutes ({allProducts.length})
            </button>
            {brands.map((b) => {
              const count = allProducts.filter((p) => p.brand === b).length;
              const isSelected = selectedBrand.toLowerCase() === b.toLowerCase();
              return (
                <button
                  key={b}
                  type="button"
                  onClick={() => setSelectedBrand(b)}
                  className={`px-3 py-1 rounded-lg font-bold whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-zinc-950 text-white shadow-xs'
                      : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
                  }`}
                >
                  {b} ({count})
                </button>
              );
            })}
          </div>
        </div>

        {/* Products Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-12 space-y-2">
              <Layers className="w-8 h-8 text-zinc-400 mx-auto" />
              <p className="text-sm font-bold text-zinc-700">Aucun modèle ne correspond à votre recherche</p>
              <p className="text-xs text-zinc-500">Essayez un autre mot-clé ou réinitialisez le filtre de marque.</p>
              <button
                type="button"
                onClick={() => {
                  setSearchTerm('');
                  setSelectedBrand('ALL');
                }}
                className="mt-2 px-4 py-2 bg-zinc-100 hover:bg-zinc-200 rounded-xl text-xs font-bold text-zinc-800"
              >
                Réinitialiser les filtres
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredProducts.map((product) => {
                const isCurrent = currentSelectedId === product.id;
                return (
                  <div
                    key={product.id}
                    className={`group bg-white rounded-2xl border transition-all p-3 flex flex-col justify-between cursor-pointer ${
                      isCurrent
                        ? 'border-zinc-950 ring-2 ring-zinc-950/20 shadow-sm bg-zinc-50/50'
                        : 'border-zinc-200 hover:border-zinc-400 hover:shadow-md'
                    }`}
                    onClick={() => {
                      onSelectModel(product);
                      onClose();
                    }}
                  >
                    <div className="space-y-2">
                      <div className="relative aspect-4/3 rounded-xl overflow-hidden bg-zinc-100 border border-zinc-150">
                        <img
                          src={product.images[0]}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          loading="lazy"
                        />
                        {watermarkSettings && <WatermarkOverlay settings={watermarkSettings} />}
                        <span className="absolute top-2 left-2 text-[10px] font-bold uppercase tracking-wider bg-white/90 backdrop-blur-xs text-zinc-900 px-2 py-0.5 rounded shadow-xs">
                          {product.brand}
                        </span>
                        {isCurrent && (
                          <span className="absolute top-2 right-2 bg-zinc-950 text-white text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 shadow-xs">
                            <Check className="w-3 h-3" /> Sélectionné
                          </span>
                        )}
                      </div>

                      <div>
                        <h4 className="text-xs font-extrabold text-zinc-950 line-clamp-1 group-hover:text-zinc-700 transition-colors">
                          {product.name}
                        </h4>
                        <div className="flex items-center justify-between text-[11px] text-zinc-500 mt-0.5">
                          <span className="font-mono">Réf: {product.reference || product.id.slice(0, 8)}</span>
                          <span className="text-emerald-700 font-bold">En stock</span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectModel(product);
                        onClose();
                      }}
                      className={`mt-3 w-full py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                        isCurrent
                          ? 'bg-zinc-950 text-white'
                          : 'bg-zinc-100 hover:bg-zinc-950 hover:text-white text-zinc-900'
                      }`}
                    >
                      <span>Choisir ce modèle ({pairCountLabel})</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3.5 border-t border-zinc-200 bg-zinc-50 text-center text-xs text-zinc-500 flex items-center justify-between px-5">
          <span>{filteredProducts.length} modèle(s) disponible(s)</span>
          <span className="font-mono text-zinc-600">Lot indivisible de 25 paires</span>
        </div>
      </div>
    </div>
  );
};
