import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Package,
  Truck,
  MapPin,
  CheckCircle2,
  AlertCircle,
  FileText,
  MessageCircle,
  ArrowRight,
  ArrowLeft,
  ShoppingBag,
  Building2,
  User,
  Phone,
  Mail,
  Download,
  ShieldCheck,
  Plus,
  Minus,
  Loader2,
  Layers,
  Sparkles,
  Trash2,
} from 'lucide-react';
import {
  PalletOrder,
  PalletOrderCustomer,
  CalculLivraisonResultat,
  SelectionItem,
  SneakerModel,
  WatermarkSettings,
  ConfiguredPallet,
  PalletComposition,
  PalletCartItem,
} from '../../types';
import {
  createPalletOrder,
  DEFAULT_WHATSAPP_NUMBER,
  ENTERPRISE_WHATSAPP_RAW,
} from '../../services/palletOrderService';
import {
  calculer_frais_livraison,
  calculer_frais_livraison_synchrone,
  DEFAULT_SHIPPING_CONFIG,
} from '../../services/shippingRouteCalculator';
import { generateOrderPdf } from '../../services/pdfService';
import { getStoredProducts } from '../../services/storageService';
import { GoogleMapsAddressInput, PlaceSelection } from '../pallets/GoogleMapsAddressInput';
import { PalletConfigCard } from './PalletConfigCard';
import { ModelSelectorModal } from './ModelSelectorModal';
import { logEvent } from '../../services/eventService';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialItems: SelectionItem[];
  watermarkSettings?: WatermarkSettings | null;
  onOrderCompleted?: (order: PalletOrder) => void;
  onNavigateToTracking?: () => void;
}

interface CustomerFormState {
  fullName: string;
  phone: string;
  email: string;
  company: string;
  deliveryAddress: string;
  postalCode: string;
  city: string;
  country: string;
  tailgateRequired: boolean;
  semiTruckAccessible: boolean;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  initialItems,
  watermarkSettings,
  onOrderCompleted,
  onNavigateToTracking,
}) => {
  // Steps: 1 = Configuration des Palettes, 2 = Localisation & Livraison, 3 = Confirmation & Proforma
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Palettes composition state
  const [pallets, setPallets] = useState<ConfiguredPallet[]>([]);

  // Picker target state for catalog model selection
  const [pickerTarget, setPickerTarget] = useState<{
    palletIndex: number;
    lotIndex: 1 | 2 | 3 | 4 | 'SINGLE';
  } | null>(null);

  // Customer & Delivery state
  const [customer, setCustomer] = useState<CustomerFormState>({
    fullName: '',
    phone: '',
    email: '',
    company: '',
    deliveryAddress: '',
    postalCode: '',
    city: '',
    country: 'France',
    tailgateRequired: true,
    semiTruckAccessible: true,
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isCalculatingShipping, setIsCalculatingShipping] = useState(false);
  const [shippingResult, setShippingResult] = useState<CalculLivraisonResultat | null>(null);
  const [createdOrder, setCreatedOrder] = useState<PalletOrder | null>(null);

  // Get catalog products
  const catalogProducts = useMemo(() => {
    return getStoredProducts();
  }, [isOpen]);

  // Initialize palettes when modal opens
  useEffect(() => {
    if (isOpen) {
      const fallbackProduct = catalogProducts[0] || {
        id: 'p-default',
        brand: 'Nike',
        name: 'Air Max TN',
        reference: 'TN-01',
        category: 'Running',
        wholesalePrice: 3.5,
        publicPrice: 190,
        images: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff'],
        status: 'Disponible',
      };

      if (initialItems && initialItems.length > 0) {
        const initialized: ConfiguredPallet[] = initialItems.flatMap((item, idx) => {
          const count = Math.max(1, item.palletCount || 1);
          return Array.from({ length: count }, (_, pIdx) => ({
            id: `pal-${idx}-${pIdx}-${Date.now()}`,
            mode: 'SINGLE_MODEL' as const,
            singleProduct: item.product,
            selectedSizes: item.selectedSizes || [],
            lots: [
              item.product,
              null,
              null,
              null,
            ] as [SneakerModel | null, SneakerModel | null, SneakerModel | null, SneakerModel | null],
          }));
        });
        setPallets(initialized);
      } else {
        setPallets([
          {
            id: `pal-0-${Date.now()}`,
            mode: 'SINGLE_MODEL',
            singleProduct: fallbackProduct,
            selectedSizes: [],
            lots: [fallbackProduct, null, null, null],
          },
        ]);
      }

      setStep(1);
      setCreatedOrder(null);
      setFormErrors({});
      setPickerTarget(null);
    }
  }, [isOpen, initialItems, catalogProducts]);

  if (!isOpen) return null;

  // Global calculations
  const totalPallets = pallets.length;
  const totalPairs = totalPallets * 100;
  const merchandiseSubtotal = totalPallets * 350;

  // Check if every pallet is fully completed
  const incompletePalletIndices = pallets
    .map((pal, idx) => {
      if (pal.mode === 'SINGLE_MODEL') {
        return pal.singleProduct ? null : idx + 1;
      }
      const isComplete = pal.lots.every((lot) => lot !== null);
      return isComplete ? null : idx + 1;
    })
    .filter((idx): idx is number => idx !== null);

  const isAllPalettesComplete = incompletePalletIndices.length === 0;

  // Delivery fee calculations
  const deliveryFee = shippingResult?.frais_livraison ?? 106.0;
  const isDeliveryQuote = shippingResult?.statut === 'devis_manuel_requis';
  const totalAmount = merchandiseSubtotal + (isDeliveryQuote ? 0 : deliveryFee);

  // Pallet management handlers
  const handleAddPallet = () => {
    const defaultProduct = catalogProducts[0] || (pallets[0]?.singleProduct);
    setPallets((prev) => [
      ...prev,
      {
        id: `pal-${Date.now()}-${Math.random()}`,
        mode: 'MIXED',
        singleProduct: defaultProduct,
        selectedSizes: [],
        lots: [null, null, null, null],
      },
    ]);
  };

  const handleRemovePallet = (indexToRemove: number) => {
    if (pallets.length <= 1) return;
    setPallets((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleUpdatePallet = (index: number, updated: ConfiguredPallet) => {
    setPallets((prev) => {
      const next = [...prev];
      next[index] = updated;
      return next;
    });
  };

  // Model selection callback from picker
  const handleSelectModelForPicker = (model: SneakerModel) => {
    if (!pickerTarget) return;
    const { palletIndex, lotIndex } = pickerTarget;

    setPallets((prev) => {
      const targetPallet = prev[palletIndex];
      if (!targetPallet) return prev;

      const nextPallets = [...prev];

      if (lotIndex === 'SINGLE') {
        nextPallets[palletIndex] = {
          ...targetPallet,
          singleProduct: model,
          lots: [
            model,
            targetPallet.lots[1],
            targetPallet.lots[2],
            targetPallet.lots[3],
          ],
        };
      } else {
        const nextLots = [...targetPallet.lots] as [
          SneakerModel | null,
          SneakerModel | null,
          SneakerModel | null,
          SneakerModel | null
        ];
        nextLots[lotIndex - 1] = model;
        nextPallets[palletIndex] = {
          ...targetPallet,
          lots: nextLots,
        };
      }

      return nextPallets;
    });

    setPickerTarget(null);
  };

  // Address selection from autocompletion
  const handleAddressSelect = (selection: PlaceSelection) => {
    setCustomer((prev) => ({
      ...prev,
      deliveryAddress: selection.streetAddress || selection.formattedAddress,
      postalCode: selection.postalCode || prev.postalCode,
      city: selection.city || prev.city,
    }));

    if (selection.postalCode && selection.city) {
      triggerShippingCalculation(selection.formattedAddress, selection.postalCode, selection.city);
    }
  };

  // Trigger shipping calculation
  const triggerShippingCalculation = async (address: string, postalCode: string, city: string) => {
    if (!postalCode || postalCode.length < 2) return;
    setIsCalculatingShipping(true);
    try {
      const res = await calculer_frais_livraison(
        {
          deliveryAddress: address,
          postalCode: postalCode,
          city: city,
          country: customer.country || 'France',
        },
        DEFAULT_SHIPPING_CONFIG
      );
      setShippingResult(res);
    } catch {
      const fallback = calculer_frais_livraison_synchrone(
        {
          deliveryAddress: address,
          postalCode: postalCode,
          city: city,
          country: customer.country || 'France',
        },
        DEFAULT_SHIPPING_CONFIG,
        300,
        `${address}, ${postalCode} ${city}`
      );
      setShippingResult(fallback);
    } finally {
      setIsCalculatingShipping(false);
    }
  };

  // Validate step 2 form
  const validateStep2 = () => {
    const errors: Record<string, string> = {};
    if (!customer.fullName.trim()) {
      errors.fullName = 'Le nom ou contact est requis';
    }
    if (!customer.phone.trim()) {
      errors.phone = 'Le numéro de téléphone est requis pour le transporteur';
    }
    if (!customer.email.trim() || !customer.email.includes('@')) {
      errors.email = 'Un e-mail valide est requis pour la facture pro forma';
    }
    if (!customer.deliveryAddress.trim()) {
      errors.deliveryAddress = "L'adresse de livraison est requise";
    }
    if (!customer.postalCode.trim() || customer.postalCode.length < 4) {
      errors.postalCode = 'Code postal requis';
    }
    if (!customer.city.trim()) {
      errors.city = 'Ville requise';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle proceed to step 2
  const handleProceedToStep2 = () => {
    if (!isAllPalettesComplete) return;
    setStep(2);
    if (customer.postalCode && customer.city) {
      triggerShippingCalculation(customer.deliveryAddress, customer.postalCode, customer.city);
    }
  };

  // Build compositions and items for final order
  const buildOrderData = () => {
    const palletsComposition: PalletComposition[] = pallets.map((pal, idx) => {
      if (pal.mode === 'SINGLE_MODEL') {
        return {
          palletNumber: idx + 1,
          type: 'SINGLE_MODEL' as const,
          brand: pal.singleProduct.brand,
          model: pal.singleProduct.name,
          productId: pal.singleProduct.id,
          photo: pal.singleProduct.images[0] || '',
          totalPairs: 100,
          price: 350,
        };
      } else {
        const lots = pal.lots as SneakerModel[];
        return {
          palletNumber: idx + 1,
          type: 'MIXED' as const,
          brand: 'Multi-marques',
          model: 'Palette Mixte (4 lots de 25 paires)',
          photo: lots[0]?.images[0] || '',
          totalPairs: 100,
          price: 350,
          mixedLots: lots.map((l, lIdx) => ({
            lotIndex: (lIdx + 1) as 1 | 2 | 3 | 4,
            brand: l.brand,
            model: l.name,
            pairCount: 25 as const,
            productId: l.id,
            photo: l.images[0] || '',
          })),
        };
      }
    });

    const orderItems: PalletCartItem[] = pallets.map((pal, idx) => {
      if (pal.mode === 'SINGLE_MODEL') {
        return {
          id: `pal-${idx + 1}-${pal.singleProduct.id}`,
          brand: pal.singleProduct.brand,
          model: pal.singleProduct.name,
          productId: pal.singleProduct.id,
          photo: pal.singleProduct.images[0] || '',
          palletCount: 1,
          pairCount: 100,
          palletPrice: 350,
          subtotal: 350,
          palletType: 'SINGLE_MODEL' as const,
        };
      } else {
        const lots = pal.lots as SneakerModel[];
        return {
          id: `pal-${idx + 1}-mixed`,
          brand: 'Multi-marques',
          model: `Palette Mixte #${idx + 1} (4 lots de 25 p.)`,
          productId: lots[0]?.id,
          photo: lots[0]?.images[0] || '',
          palletCount: 1,
          pairCount: 100,
          palletPrice: 350,
          subtotal: 350,
          palletType: 'MIXED' as const,
          mixedLots: lots.map((l, lIdx) => ({
            lotIndex: (lIdx + 1) as 1 | 2 | 3 | 4,
            brand: l.brand,
            model: l.name,
            pairCount: 25 as const,
            productId: l.id,
            photo: l.images[0] || '',
          })),
        };
      }
    });

    return { palletsComposition, orderItems };
  };

  // Handle submit final order
  const handleFinalizeOrder = () => {
    if (!validateStep2()) return;

    const { palletsComposition, orderItems } = buildOrderData();

    const nameParts = customer.fullName.trim().split(' ');
    const firstName = nameParts[0] || 'Client';
    const lastName = nameParts.slice(1).join(' ') || 'Professionnel';

    const orderCustomer: PalletOrderCustomer = {
      firstName,
      lastName,
      phone: customer.phone,
      whatsapp: customer.phone,
      email: customer.email,
      company: customer.company || undefined,
      deliveryAddress: customer.deliveryAddress,
      postalCode: customer.postalCode,
      city: customer.city,
      country: customer.country || 'France',
      deliveryInstructions: customer.tailgateRequired ? 'Hayon requis' : undefined,
      dataProcessingConsent: true,
    };

    const newOrder = createPalletOrder({
      palletCount: totalPallets,
      items: orderItems,
      palletsComposition: palletsComposition,
      customer: orderCustomer,
      shippingResult: shippingResult || undefined,
    });

    setCreatedOrder(newOrder);
    setStep(3);

    if (onOrderCompleted) {
      onOrderCompleted(newOrder);
    }

    logEvent('ORDER_CREATED', `Commande créée : ${newOrder.id} pour ${totalPallets} palettes (${newOrder.totalAmount} €)`, {
      clientName: `${newOrder.customer.firstName} ${newOrder.customer.lastName}`.trim(),
      clientEmail: newOrder.customer.email,
    });
  };

  // Generate WhatsApp Message & URL with full composition breakdown
  const getWhatsAppUrl = () => {
    if (!createdOrder) return `https://wa.me/${ENTERPRISE_WHATSAPP_RAW}`;

    const palletsDetails = pallets
      .map((pal, idx) => {
        if (pal.mode === 'SINGLE_MODEL') {
          return `• *Palette ${idx + 1} (Mono-modèle - 100 paires - 350 € HT) :*\n   ${pal.singleProduct.brand} - ${pal.singleProduct.name} (100 paires)`;
        } else {
          const lots = pal.lots as SneakerModel[];
          return (
            `• *Palette ${idx + 1} (Palette Mixte - 100 paires - 350 € HT) :*\n` +
            `   - Lot 1 (25 p.) : ${lots[0]?.brand} - ${lots[0]?.name}\n` +
            `   - Lot 2 (25 p.) : ${lots[1]?.brand} - ${lots[1]?.name}\n` +
            `   - Lot 3 (25 p.) : ${lots[2]?.brand} - ${lots[2]?.name}\n` +
            `   - Lot 4 (25 p.) : ${lots[3]?.brand} - ${lots[3]?.name}`
          );
        }
      })
      .join('\n\n');

    const deliveryStr =
      createdOrder.deliveryFee !== null
        ? `${createdOrder.deliveryFee.toFixed(2)} €`
        : 'Sur devis (zone spécifique)';

    const msg = `Bonjour H DESTOCKAGE,

Je souhaite finaliser ma commande de palettes de sneakers :
📋 *NUMÉRO DE COMMANDE :* ${createdOrder.id}

📦 *COMPOSITION DES PALETTES (${totalPallets} palette${totalPallets > 1 ? 's' : ''} • ${totalPairs} paires) :*
${palletsDetails}

📊 *RÉCAPITULATIF FINANCIER :*
- *Total palettes :* ${totalPallets} palette(s)
- *Total paires neuves :* ${totalPairs} paires
- *Sous-total marchandises :* ${merchandiseSubtotal.toLocaleString('fr-FR')} € HT
- *Frais de livraison :* ${deliveryStr}
- *MONTANT TOTAL :* ${createdOrder.totalAmount.toLocaleString('fr-FR')} €

📍 *DESTINATION DE LIVRAISON :*
${customer.deliveryAddress}
${customer.postalCode} ${customer.city} (${customer.country})

👤 *COORDONNÉES CLIENT :*
- Contact : ${customer.fullName}
${customer.company ? `- Société : ${customer.company}\n` : ''}- Tél : ${customer.phone}
- Email : ${customer.email}

Merci de me confirmer la disponibilité et de me communiquer le RIB pour règlement.`;

    return `https://wa.me/${ENTERPRISE_WHATSAPP_RAW}?text=${encodeURIComponent(msg)}`;
  };

  const handleDownloadProforma = () => {
    if (!createdOrder) return;
    generateOrderPdf(createdOrder);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fade-in">
        <div
          className="relative bg-white border border-zinc-200 rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Modal Top Header */}
          <div className="px-6 py-4 bg-zinc-950 text-white flex items-center justify-between border-b border-zinc-800">
            <div className="flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-sm tracking-tight">H DESTOCKAGE</span>
                  <span className="text-[10px] bg-zinc-800 text-zinc-300 font-mono px-1.5 py-0.5 rounded">
                    COMMANDE PRO B2B
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  {step === 1 && 'Étape 1 : Composition des palettes (100 paires = 350 €)'}
                  {step === 2 && 'Étape 2 : Adresse de livraison & calcul des frais'}
                  {step === 3 && 'Étape 3 : Récapitulatif & Facture Pro Forma'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stepper Progress Bar */}
          <div className="grid grid-cols-3 bg-zinc-100 border-b border-zinc-200 text-[11px] font-bold">
            <div
              className={`py-2 px-3 text-center flex items-center justify-center gap-1.5 border-r border-zinc-200 ${
                step === 1 ? 'bg-zinc-900 text-white font-extrabold' : 'text-zinc-600'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-zinc-200 text-zinc-900 flex items-center justify-center text-[10px] font-mono font-black">
                1
              </span>
              <span className="hidden sm:inline">Composition des Palettes</span>
              <span className="sm:hidden">Palettes</span>
            </div>
            <div
              className={`py-2 px-3 text-center flex items-center justify-center gap-1.5 border-r border-zinc-200 ${
                step === 2 ? 'bg-zinc-900 text-white font-extrabold' : 'text-zinc-600'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-zinc-200 text-zinc-900 flex items-center justify-center text-[10px] font-mono font-black">
                2
              </span>
              <span className="hidden sm:inline">Livraison & Coordonnées</span>
              <span className="sm:hidden">Livraison</span>
            </div>
            <div
              className={`py-2 px-3 text-center flex items-center justify-center gap-1.5 ${
                step === 3 ? 'bg-emerald-600 text-white font-extrabold' : 'text-zinc-600'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-zinc-200 text-zinc-900 flex items-center justify-center text-[10px] font-mono font-black">
                3
              </span>
              <span className="hidden sm:inline">Finalisation & Proforma</span>
              <span className="sm:hidden">Finalisation</span>
            </div>
          </div>

          {/* Scrollable Body */}
          <div className="overflow-y-auto p-5 sm:p-6 space-y-6 flex-1 text-zinc-900">
            {/* ========================================================= */}
            {/* STEP 1: COMPOSITION DES PALETTES (Mono-modèle ou Mixte)    */}
            {/* ========================================================= */}
            {step === 1 && (
              <div className="space-y-6">
                {/* Mandatory Business Rule Notice */}
                <div className="bg-zinc-50 border-2 border-zinc-950 rounded-2xl p-4 sm:p-5 shadow-xs space-y-2.5">
                  <div className="flex items-center gap-2">
                    <Package className="w-5 h-5 text-zinc-950" />
                    <span className="text-xs font-mono font-black uppercase tracking-wider text-zinc-950">
                      Règle de commande B2B
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                    <div className="bg-white p-3 rounded-xl border border-zinc-200 text-center shadow-2xs">
                      <span className="text-[10px] font-bold text-zinc-500 uppercase block">1 Palette</span>
                      <span className="text-sm font-black text-zinc-950">100 PAIRES</span>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-zinc-200 text-center shadow-2xs">
                      <span className="text-[10px] font-bold text-zinc-500 uppercase block">Composition Mixte</span>
                      <span className="text-sm font-black text-zinc-950">4 LOTS DE 25 PAIRES</span>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-zinc-200 text-center shadow-2xs">
                      <span className="text-[10px] font-bold text-zinc-500 uppercase block">Prix de la palette</span>
                      <span className="text-sm font-black text-emerald-700">350 € HT</span>
                    </div>
                  </div>
                  <p className="text-[11px] text-zinc-600 leading-relaxed pt-1">
                    * Vous pouvez commander une palette avec <strong>un seul modèle (100 paires)</strong> ou composer une <strong>palette mixte (4 lots de 25 paires)</strong>. Vous pouvez également ajouter plusieurs palettes à votre commande.
                  </p>
                </div>

                {/* List of Configured Pallets */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-mono font-black uppercase tracking-wider text-zinc-500">
                      Palettes configurées pour votre commande ({pallets.length})
                    </h3>
                    <span className="text-xs font-mono font-bold text-zinc-950">
                      Total : {totalPairs} paires ({merchandiseSubtotal.toLocaleString('fr-FR')} € HT)
                    </span>
                  </div>

                  {pallets.map((pallet, idx) => (
                    <PalletConfigCard
                      key={pallet.id}
                      pallet={pallet}
                      palletIndex={idx}
                      totalPallets={pallets.length}
                      watermarkSettings={watermarkSettings}
                      onUpdatePallet={(updated) => handleUpdatePallet(idx, updated)}
                      onRemovePallet={() => handleRemovePallet(idx)}
                      onRequestPickModel={(lotIdx) => {
                        setPickerTarget({
                          palletIndex: idx,
                          lotIndex: lotIdx,
                        });
                      }}
                    />
                  ))}

                  {/* Button to add another palette */}
                  <button
                    type="button"
                    onClick={handleAddPallet}
                    className="w-full py-3.5 px-4 rounded-2xl border-2 border-dashed border-zinc-300 hover:border-zinc-950 hover:bg-zinc-50 text-zinc-800 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer group shadow-2xs"
                  >
                    <Plus className="w-4 h-4 text-zinc-600 group-hover:scale-110 transition-transform" />
                    <span>+ AJOUTER UNE NOUVELLE PALETTE (100 PAIRES — 350 € HT)</span>
                  </button>
                </div>

                {/* Automatic Calculation Examples Table */}
                <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 space-y-2">
                  <span className="text-[10px] font-mono font-bold uppercase text-zinc-500 block">
                    Barème tarifaire déstockage :
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                    <div
                      className={`p-2 rounded-lg border text-center ${
                        totalPallets === 1
                          ? 'bg-zinc-950 text-white border-zinc-950 font-bold'
                          : 'bg-white text-zinc-700 border-zinc-200'
                      }`}
                    >
                      1 pal. = 100 p. = 350 €
                    </div>
                    <div
                      className={`p-2 rounded-lg border text-center ${
                        totalPallets === 2
                          ? 'bg-zinc-950 text-white border-zinc-950 font-bold'
                          : 'bg-white text-zinc-700 border-zinc-200'
                      }`}
                    >
                      2 pal. = 200 p. = 700 €
                    </div>
                    <div
                      className={`p-2 rounded-lg border text-center ${
                        totalPallets === 3
                          ? 'bg-zinc-950 text-white border-zinc-950 font-bold'
                          : 'bg-white text-zinc-700 border-zinc-200'
                      }`}
                    >
                      3 pal. = 300 p. = 1 050 €
                    </div>
                    <div
                      className={`p-2 rounded-lg border text-center ${
                        totalPallets >= 4
                          ? 'bg-zinc-950 text-white border-zinc-950 font-bold'
                          : 'bg-white text-zinc-700 border-zinc-200'
                      }`}
                    >
                      {totalPallets >= 4
                        ? `${totalPallets} pal. = ${totalPairs} p. = ${merchandiseSubtotal.toLocaleString('fr-FR')} €`
                        : '4 pal. = 400 p. = 1 400 €'}
                    </div>
                  </div>
                </div>

                {/* Incomplete Pallet Warning */}
                {!isAllPalettesComplete && (
                  <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 text-amber-900 text-xs">
                    <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h5 className="font-bold">Composition incomplète</h5>
                      <p className="mt-0.5 text-amber-800">
                        La palette {incompletePalletIndices.join(', ')} n&apos;est pas encore complète. Veuillez sélectionner les 4 lots de 25 paires pour atteindre 100/100 paires avant de valider.
                      </p>
                    </div>
                  </div>
                )}

                {/* Subtotal Summary Box */}
                <div className="bg-white border-2 border-zinc-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xs">
                  <div>
                    <span className="text-[11px] font-mono text-zinc-500 uppercase">Sous-total Marchandises</span>
                    <div className="text-2xl sm:text-3xl font-black text-zinc-950 font-mono">
                      {merchandiseSubtotal.toLocaleString('fr-FR')} € HT
                    </div>
                    <p className="text-xs text-zinc-500 mt-0.5">
                      {totalPallets} palette(s) • {totalPairs} paires de sneakers neuves
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleProceedToStep2}
                    disabled={!isAllPalettesComplete}
                    className="w-full sm:w-auto px-6 py-3.5 bg-zinc-950 hover:bg-zinc-800 disabled:opacity-40 disabled:cursor-not-allowed text-white font-black text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    <span>SUIVANT : ADRESSE DE LIVRAISON</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* STEP 2: LOCALISATION & CALCUL DE LIVRAISON                 */}
            {/* ========================================================= */}
            {step === 2 && (
              <div className="space-y-6">
                <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-zinc-900 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider text-zinc-950">
                      Localisation & Destination de livraison
                    </h4>
                    <p className="text-xs text-zinc-600 mt-0.5">
                      Renseignez l&apos;adresse de votre boutique ou entrepôt pour calculer précisément l&apos;acheminement routier.
                      <em> (Le prix de la palette ne comprend pas automatiquement les frais de livraison).</em>
                    </p>
                  </div>
                </div>

                {/* Compact Recap of Configured Pallets */}
                <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 space-y-2.5">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-zinc-500 block">
                    Récapitulatif des palettes sélectionnées ({totalPallets} pal. • {totalPairs} paires) :
                  </span>
                  <div className="space-y-2">
                    {pallets.map((pal, idx) => (
                      <div
                        key={pal.id}
                        className="bg-white p-3 rounded-xl border border-zinc-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs"
                      >
                        <div>
                          <span className="font-bold text-zinc-950">
                            Palette {idx + 1} : {pal.mode === 'SINGLE_MODEL' ? 'Mono-modèle (100 p.)' : 'Palette Mixte (4 lots × 25 p.)'}
                          </span>
                          <div className="text-[11px] text-zinc-600 mt-0.5">
                            {pal.mode === 'SINGLE_MODEL'
                              ? `${pal.singleProduct.brand} — ${pal.singleProduct.name}`
                              : pal.lots
                                  .filter(Boolean)
                                  .map((l, lIdx) => `L${lIdx + 1}: ${l?.brand} ${l?.name} (25p)`)
                                  .join(' • ')}
                          </div>
                        </div>
                        <span className="font-mono font-bold text-zinc-950 text-right whitespace-nowrap">
                          100 p. = 350 € HT
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Contact Information */}
                <div className="space-y-4">
                  <h4 className="text-xs font-mono font-black uppercase tracking-wider text-zinc-500 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" />
                    Vos Coordonnées Professionnelles
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-zinc-700 block mb-1">
                        Nom et Prénom (ou contact) *
                      </label>
                      <input
                        type="text"
                        value={customer.fullName}
                        onChange={(e) => setCustomer({ ...customer, fullName: e.target.value })}
                        placeholder="Ex : Marc Dupont"
                        className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950 ${
                          formErrors.fullName ? 'border-rose-500' : 'border-zinc-200'
                        }`}
                      />
                      {formErrors.fullName && (
                        <p className="text-[11px] text-rose-600 mt-1">{formErrors.fullName}</p>
                      )}
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-700 block mb-1">
                        Nom de Société / Boutique (facultatif)
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={customer.company || ''}
                          onChange={(e) => setCustomer({ ...customer, company: e.target.value })}
                          placeholder="Ex : Sneaker Shop SAS"
                          className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-700 block mb-1">
                        Numéro WhatsApp / Téléphone *
                      </label>
                      <div className="relative">
                        <input
                          type="tel"
                          value={customer.phone}
                          onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                          placeholder="06 12 34 56 78"
                          className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950 font-mono ${
                            formErrors.phone ? 'border-rose-500' : 'border-zinc-200'
                          }`}
                        />
                      </div>
                      {formErrors.phone && (
                        <p className="text-[11px] text-rose-600 mt-1">{formErrors.phone}</p>
                      )}
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-700 block mb-1">
                        E-mail professionnel (pour la pro forma) *
                      </label>
                      <input
                        type="email"
                        value={customer.email}
                        onChange={(e) => setCustomer({ ...customer, email: e.target.value })}
                        placeholder="contact@boutique.fr"
                        className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950 font-mono ${
                          formErrors.email ? 'border-rose-500' : 'border-zinc-200'
                        }`}
                      />
                      {formErrors.email && (
                        <p className="text-[11px] text-rose-600 mt-1">{formErrors.email}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Delivery Address */}
                <div className="space-y-4 pt-2 border-t border-zinc-200">
                  <h4 className="text-xs font-mono font-black uppercase tracking-wider text-zinc-500 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" />
                    Adresse Complète de Livraison
                  </h4>

                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">
                      Adresse (voie, rue, ZI, bâtiment) *
                    </label>
                    <GoogleMapsAddressInput
                      value={customer.deliveryAddress}
                      postalCode={customer.postalCode}
                      city={customer.city}
                      onChange={(val) => setCustomer((prev) => ({ ...prev, deliveryAddress: val }))}
                      onAddressSelect={handleAddressSelect}
                      hasError={Boolean(formErrors.deliveryAddress)}
                      errorMessage={formErrors.deliveryAddress}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-zinc-700 block mb-1">
                        Code Postal *
                      </label>
                      <input
                        type="text"
                        value={customer.postalCode}
                        onChange={(e) => {
                          const nextCp = e.target.value;
                          setCustomer((prev) => ({ ...prev, postalCode: nextCp }));
                          if (nextCp.length === 5) {
                            triggerShippingCalculation(customer.deliveryAddress, nextCp, customer.city);
                          }
                        }}
                        placeholder="Ex : 75001"
                        className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950 font-mono ${
                          formErrors.postalCode ? 'border-rose-500' : 'border-zinc-200'
                        }`}
                      />
                      {formErrors.postalCode && (
                        <p className="text-[11px] text-rose-600 mt-1">{formErrors.postalCode}</p>
                      )}
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-700 block mb-1">
                        Ville *
                      </label>
                      <input
                        type="text"
                        value={customer.city}
                        onChange={(e) => {
                          const nextCity = e.target.value;
                          setCustomer((prev) => ({ ...prev, city: nextCity }));
                          if (customer.postalCode && customer.postalCode.length >= 4) {
                            triggerShippingCalculation(customer.deliveryAddress, customer.postalCode, nextCity);
                          }
                        }}
                        placeholder="Ex : Paris"
                        className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:border-zinc-950 ${
                          formErrors.city ? 'border-rose-500' : 'border-zinc-200'
                        }`}
                      />
                      {formErrors.city && (
                        <p className="text-[11px] text-rose-600 mt-1">{formErrors.city}</p>
                      )}
                    </div>
                  </div>

                  {/* Delivery Options */}
                  <div className="bg-zinc-50 p-3.5 rounded-xl border border-zinc-200 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <label className="flex items-center gap-2 cursor-pointer text-xs text-zinc-800">
                      <input
                        type="checkbox"
                        checked={customer.tailgateRequired}
                        onChange={(e) => setCustomer({ ...customer, tailgateRequired: e.target.checked })}
                        className="rounded border-zinc-300 text-zinc-950 focus:ring-zinc-950"
                      />
                      <span>Hayon élévateur et transpalette requis</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer text-xs text-zinc-800">
                      <input
                        type="checkbox"
                        checked={customer.semiTruckAccessible}
                        onChange={(e) => setCustomer({ ...customer, semiTruckAccessible: e.target.checked })}
                        className="rounded border-zinc-300 text-zinc-950 focus:ring-zinc-950"
                      />
                      <span>Accès semi-remorque ou porteur disponible</span>
                    </label>
                  </div>
                </div>

                {/* Shipping Calculation Status */}
                <div className="bg-white border-2 border-zinc-200 rounded-2xl p-4 sm:p-5 space-y-3 shadow-xs">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
                    <span className="text-xs font-bold text-zinc-600 flex items-center gap-1.5">
                      <Truck className="w-4 h-4 text-zinc-900" />
                      Calcul des frais de livraison :
                    </span>
                    {isCalculatingShipping ? (
                      <span className="text-xs font-mono text-zinc-500 flex items-center gap-1">
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        Calcul routier en cours...
                      </span>
                    ) : (
                      <span className="text-xs font-mono font-bold text-zinc-950">
                        {isDeliveryQuote ? 'Devis spécifique requis' : `${deliveryFee.toFixed(2)} € TTC`}
                      </span>
                    )}
                  </div>

                  {/* Financial Summary Table */}
                  <div className="space-y-2 text-xs font-mono">
                    <div className="flex justify-between text-zinc-600">
                      <span>Sous-total Marchandises ({totalPallets} palette{totalPallets > 1 ? 's' : ''}) :</span>
                      <span className="font-bold text-zinc-950">{merchandiseSubtotal.toLocaleString('fr-FR')} €</span>
                    </div>
                    <div className="flex justify-between text-zinc-600">
                      <span>Frais de livraison :</span>
                      <span className="font-bold text-zinc-950">
                        {isDeliveryQuote ? 'Sur devis personnalisé' : `${deliveryFee.toFixed(2)} €`}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm font-black text-zinc-950 pt-2 border-t border-zinc-200">
                      <span>MONTANT TOTAL :</span>
                      <span className="text-emerald-700">
                        {isDeliveryQuote
                          ? `${merchandiseSubtotal.toLocaleString('fr-FR')} € + livraison`
                          : `${totalAmount.toLocaleString('fr-FR')} €`}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Buttons Step 2 */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="w-full sm:w-auto px-5 py-3 rounded-xl border border-zinc-300 text-zinc-700 hover:bg-zinc-100 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Modifier les palettes</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleFinalizeOrder}
                    className="w-full sm:w-auto px-8 py-3.5 bg-zinc-950 hover:bg-zinc-800 text-white font-black text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    <span>VALIDER MA COMMANDE</span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  </button>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* STEP 3: RECAPITULATIF, PROFORMA & FINALISATION WHATSAPP   */}
            {/* ========================================================= */}
            {step === 3 && createdOrder && (
              <div className="space-y-6">
                {/* Success Banner */}
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 sm:p-5 flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                      COMMANDE ENREGISTRÉE AVEC SUCCÈS
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-emerald-950 mt-1">
                      Numéro de commande : {createdOrder.id}
                    </h3>
                    <p className="text-xs text-emerald-800 mt-0.5 leading-relaxed">
                      Votre commande a été préparée et enregistrée. Pour valider l&apos;expédition, veuillez transmettre le récapitulatif à notre service commercial via WhatsApp officiel ou télécharger votre pro forma.
                    </p>
                  </div>
                </div>

                {/* Complete Order Recap with Pallets Details */}
                <div className="bg-white border border-zinc-200 rounded-2xl p-4 sm:p-5 space-y-4 shadow-xs">
                  <h4 className="text-xs font-mono font-black uppercase tracking-wider text-zinc-500 pb-2 border-b border-zinc-100">
                    Récapitulatif Officiel de Commande ({totalPallets} palette{totalPallets > 1 ? 's' : ''})
                  </h4>

                  <div className="space-y-3">
                    {pallets.map((pal, idx) => (
                      <div key={pal.id} className="p-3 bg-zinc-50 rounded-xl border border-zinc-200 text-xs">
                        <div className="flex justify-between items-center font-bold text-zinc-950">
                          <span>
                            Palette {idx + 1} : {pal.mode === 'SINGLE_MODEL' ? 'Mono-modèle (100 p.)' : 'Palette Mixte (4 lots × 25 p.)'}
                          </span>
                          <span className="font-mono">350.00 € HT</span>
                        </div>

                        {pal.mode === 'SINGLE_MODEL' ? (
                          <div className="text-[11px] text-zinc-600 mt-1">
                            {pal.singleProduct.brand} — {pal.singleProduct.name} (100 paires)
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 mt-2 pt-2 border-t border-zinc-200 text-[11px] text-zinc-700">
                            {pal.lots.map((lot, lIdx) => (
                              <div key={lIdx} className="bg-white px-2 py-1 rounded border border-zinc-200">
                                <strong>Lot {lIdx + 1} (25 p.) :</strong> {lot?.brand} {lot?.name}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-zinc-200 pt-3 space-y-1.5 text-xs font-mono">
                    <div className="flex justify-between text-zinc-600">
                      <span>Nombre total de palettes :</span>
                      <span className="font-bold text-zinc-950">{totalPallets} palette(s)</span>
                    </div>
                    <div className="flex justify-between text-zinc-600">
                      <span>Nombre total de paires :</span>
                      <span className="font-bold text-zinc-950">{totalPairs} paires neuves</span>
                    </div>
                    <div className="flex justify-between text-zinc-600">
                      <span>Prix des marchandises :</span>
                      <span className="font-bold text-zinc-950">{merchandiseSubtotal.toLocaleString('fr-FR')} €</span>
                    </div>
                    <div className="flex justify-between text-zinc-600">
                      <span>Localisation de livraison :</span>
                      <span className="font-bold text-zinc-950 text-right truncate max-w-[200px] sm:max-w-xs">
                        {customer.postalCode} {customer.city}
                      </span>
                    </div>
                    <div className="flex justify-between text-zinc-600">
                      <span>Frais de livraison :</span>
                      <span className="font-bold text-zinc-950">
                        {createdOrder.deliveryFee !== null ? `${createdOrder.deliveryFee.toFixed(2)} €` : 'Sur devis'}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm font-black text-zinc-950 pt-2 border-t border-zinc-200">
                      <span>MONTANT TOTAL :</span>
                      <span className="text-emerald-700">
                        {createdOrder.totalAmount.toLocaleString('fr-FR')} €
                      </span>
                    </div>
                  </div>
                </div>

                {/* ACTION BUTTON 1: WHATSAPP OFFICIEL (MIS EN AVANT) */}
                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full min-h-[52px] py-4 px-5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm uppercase tracking-wider flex items-center justify-center gap-3 transition-all duration-200 hover:scale-[1.01] active:scale-95 text-center shadow-md cursor-pointer"
                >
                  <MessageCircle className="w-5 h-5 fill-white/20 text-white flex-shrink-0" />
                  <span>TRANSMETTRE LA COMMANDE SUR WHATSAPP</span>
                </a>

                {/* ACTION BUTTON 2: TELECHARGER FACTURE PRO FORMA PDF */}
                <button
                  type="button"
                  onClick={handleDownloadProforma}
                  className="w-full min-h-[46px] py-3.5 px-5 rounded-2xl bg-zinc-950 hover:bg-zinc-800 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2.5 transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>TÉLÉCHARGER LA FACTURE PRO FORMA (PDF)</span>
                </button>

                {/* Secondary Navigation */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                  {onNavigateToTracking && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onNavigateToTracking();
                      }}
                      className="w-full sm:w-auto text-xs text-zinc-600 hover:text-zinc-950 flex items-center justify-center gap-1.5 py-2 cursor-pointer"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      <span>Consulter le suivi de cette commande</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={onClose}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-zinc-300 text-zinc-700 hover:bg-zinc-100 text-xs font-semibold cursor-pointer"
                  >
                    Fermer
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Model Selector Modal for lots or single-model changes */}
      {pickerTarget && (
        <ModelSelectorModal
          isOpen={Boolean(pickerTarget)}
          onClose={() => setPickerTarget(null)}
          onSelectModel={handleSelectModelForPicker}
          title={
            pickerTarget.lotIndex === 'SINGLE'
              ? `Changer le modèle de la Palette ${pickerTarget.palletIndex + 1}`
              : `Choisir pour le Lot ${pickerTarget.lotIndex} (Palette ${pickerTarget.palletIndex + 1})`
          }
          subtitle={
            pickerTarget.lotIndex === 'SINGLE'
              ? 'Sélectionnez le modèle unique pour l’ensemble des 100 paires'
              : 'Ce modèle composera un lot de 25 paires au sein de votre palette mixte'
          }
          pairCountLabel={pickerTarget.lotIndex === 'SINGLE' ? '100 paires' : '25 paires'}
          watermarkSettings={watermarkSettings}
        />
      )}
    </>
  );
};
