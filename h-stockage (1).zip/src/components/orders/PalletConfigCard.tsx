import React from 'react';
import {
  Package,
  Layers,
  Sparkles,
  Trash2,
  Edit3,
  CheckCircle2,
  AlertCircle,
  Plus,
  X,
} from 'lucide-react';
import { ConfiguredPallet, SneakerModel, WatermarkSettings } from '../../types';
import { WatermarkOverlay } from '../WatermarkOverlay';

interface PalletConfigCardProps {
  pallet: ConfiguredPallet;
  palletIndex: number;
  totalPallets: number;
  watermarkSettings?: WatermarkSettings | null;
  onUpdatePallet: (updated: ConfiguredPallet) => void;
  onRemovePallet?: () => void;
  onRequestPickModel: (lotIndex: 1 | 2 | 3 | 4 | 'SINGLE') => void;
}

export const PalletConfigCard: React.FC<PalletConfigCardProps> = ({
  pallet,
  palletIndex,
  totalPallets,
  watermarkSettings,
  onUpdatePallet,
  onRemovePallet,
  onRequestPickModel,
}) => {
  const filledLotsCount = pallet.lots.filter((l) => l !== null).length;
  const isMixedComplete = filledLotsCount === 4;
  const isPalletReady = pallet.mode === 'SINGLE_MODEL' ? Boolean(pallet.singleProduct) : isMixedComplete;

  const handleSetMode = (mode: 'SINGLE_MODEL' | 'MIXED') => {
    if (mode === pallet.mode) return;
    if (mode === 'MIXED') {
      // If switching to mixed, make sure slot 0 has the single product as starter if empty
      const nextLots = [...pallet.lots] as [
        SneakerModel | null,
        SneakerModel | null,
        SneakerModel | null,
        SneakerModel | null
      ];
      if (!nextLots[0] && pallet.singleProduct) {
        nextLots[0] = pallet.singleProduct;
      }
      onUpdatePallet({
        ...pallet,
        mode: 'MIXED',
        lots: nextLots,
      });
    } else {
      // Switching to single model
      onUpdatePallet({
        ...pallet,
        mode: 'SINGLE_MODEL',
      });
    }
  };

  const handleClearLot = (slotIdx: number) => {
    const nextLots = [...pallet.lots] as [
      SneakerModel | null,
      SneakerModel | null,
      SneakerModel | null,
      SneakerModel | null
    ];
    nextLots[slotIdx] = null;
    onUpdatePallet({
      ...pallet,
      lots: nextLots,
    });
  };

  return (
    <div
      className={`bg-white rounded-2xl border transition-all shadow-xs overflow-hidden ${
        isPalletReady ? 'border-zinc-300' : 'border-amber-300 ring-1 ring-amber-200'
      }`}
    >
      {/* Card Header */}
      <div className="bg-zinc-50 border-b border-zinc-200 p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-zinc-950 text-white flex items-center justify-center font-mono font-bold text-xs">
            #{palletIndex + 1}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-black text-zinc-950">Palette {palletIndex + 1}</h4>
              <span className="bg-zinc-200 text-zinc-800 text-[10px] font-mono font-bold px-2 py-0.5 rounded">
                100 paires = 350 € HT
              </span>
            </div>
            <p className="text-[11px] text-zinc-500">
              {pallet.mode === 'SINGLE_MODEL' ? 'Composition : Modèle unique' : 'Composition : Palette mixte (4 lots)'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {totalPallets > 1 && onRemovePallet && (
            <button
              type="button"
              onClick={onRemovePallet}
              className="text-zinc-400 hover:text-rose-600 hover:bg-rose-50 p-2 rounded-xl transition-colors text-xs flex items-center gap-1"
              title="Supprimer cette palette de la commande"
            >
              <Trash2 className="w-4 h-4" />
              <span className="hidden sm:inline">Supprimer</span>
            </button>
          )}
        </div>
      </div>

      {/* Mode Switcher */}
      <div className="p-4 sm:p-5 border-b border-zinc-100 bg-zinc-50/40">
        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-zinc-500 block mb-2">
          Type de composition pour cette palette :
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {/* Option 1: Palette avec un seul modèle */}
          <button
            type="button"
            onClick={() => handleSetMode('SINGLE_MODEL')}
            className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all ${
              pallet.mode === 'SINGLE_MODEL'
                ? 'bg-zinc-950 text-white border-zinc-950 shadow-xs'
                : 'bg-white text-zinc-800 border-zinc-200 hover:border-zinc-300'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center flex-shrink-0 ${
                pallet.mode === 'SINGLE_MODEL' ? 'border-white bg-white' : 'border-zinc-400'
              }`}
            >
              {pallet.mode === 'SINGLE_MODEL' && <div className="w-2 h-2 rounded-full bg-zinc-950" />}
            </div>
            <div>
              <div className="text-xs font-bold">Palette avec un seul modèle</div>
              <div
                className={`text-[11px] mt-0.5 ${
                  pallet.mode === 'SINGLE_MODEL' ? 'text-zinc-300' : 'text-zinc-500'
                }`}
              >
                100 paires du même modèle
              </div>
            </div>
          </button>

          {/* Option 2: Palette mixte */}
          <button
            type="button"
            onClick={() => handleSetMode('MIXED')}
            className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all ${
              pallet.mode === 'MIXED'
                ? 'bg-zinc-950 text-white border-zinc-950 shadow-xs'
                : 'bg-white text-zinc-800 border-zinc-200 hover:border-zinc-300'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center flex-shrink-0 ${
                pallet.mode === 'MIXED' ? 'border-white bg-white' : 'border-zinc-400'
              }`}
            >
              {pallet.mode === 'MIXED' && <div className="w-2 h-2 rounded-full bg-zinc-950" />}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold">Palette mixte</span>
                <span
                  className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold ${
                    pallet.mode === 'MIXED' ? 'bg-zinc-800 text-emerald-300' : 'bg-emerald-50 text-emerald-700'
                  }`}
                >
                  Multi-modèles
                </span>
              </div>
              <div
                className={`text-[11px] mt-0.5 ${
                  pallet.mode === 'MIXED' ? 'text-zinc-300' : 'text-zinc-500'
                }`}
              >
                Composez vos 100 paires avec 4 lots de 25 paires
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Mode Content */}
      <div className="p-4 sm:p-5 space-y-4">
        {/* CASE A: SINGLE MODEL */}
        {pallet.mode === 'SINGLE_MODEL' && (
          <div className="space-y-3">
            <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-white border border-zinc-200 flex-shrink-0 shadow-2xs">
                  <img
                    src={pallet.singleProduct.images[0]}
                    alt={pallet.singleProduct.name}
                    className="w-full h-full object-cover"
                  />
                  {watermarkSettings && <WatermarkOverlay settings={watermarkSettings} />}
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-600 bg-zinc-200 px-1.5 py-0.5 rounded">
                    {pallet.singleProduct.brand}
                  </span>
                  <h5 className="text-sm font-extrabold text-zinc-950 mt-0.5">
                    {pallet.singleProduct.name}
                  </h5>
                  <p className="text-[11px] text-zinc-500">
                    {pallet.selectedSizes && pallet.selectedSizes.length > 0
                      ? `Pointures : ${pallet.selectedSizes.sort((a, b) => a - b).join(', ')}`
                      : 'Assortiment complet (tailles 38 à 45)'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 self-end sm:self-center">
                <div className="text-right">
                  <div className="text-sm font-black text-zinc-950 font-mono">100 paires</div>
                  <div className="text-[11px] text-zinc-500 font-mono">350 € HT</div>
                </div>

                <button
                  type="button"
                  onClick={() => onRequestPickModel('SINGLE')}
                  className="px-3.5 py-2 bg-white border border-zinc-300 hover:border-zinc-950 rounded-xl text-xs font-bold text-zinc-800 flex items-center gap-1.5 transition-colors shadow-2xs"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Changer</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-zinc-500 pt-1 px-1">
              <span className="flex items-center gap-1 text-emerald-700 font-bold">
                <CheckCircle2 className="w-4 h-4" /> 100/100 paires — Palette complète
              </span>
              <span className="font-mono text-[11px]">1 palette = 100 paires</span>
            </div>
          </div>
        )}

        {/* CASE B: MIXED PALETTE (4 lots of 25 pairs) */}
        {pallet.mode === 'MIXED' && (
          <div className="space-y-4">
            {/* Progression Bar & Discreet Count */}
            <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-3.5 sm:p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-zinc-950 font-mono">
                    PROGRESSION : {filledLotsCount * 25} / 100 PAIRES
                  </span>
                  {isMixedComplete ? (
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Complète
                    </span>
                  ) : (
                    <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                      {4 - filledLotsCount} lot(s) restant(s)
                    </span>
                  )}
                </div>
                <span className="text-[11px] font-mono text-zinc-500 hidden sm:inline">
                  4 lots × 25 paires = 1 palette (350 €)
                </span>
              </div>

              {/* 4-Segment Visual Progress Bar */}
              <div className="grid grid-cols-4 gap-1.5">
                {[0, 1, 2, 3].map((slotIdx) => {
                  const isFilled = pallet.lots[slotIdx] !== null;
                  return (
                    <div key={slotIdx} className="space-y-1">
                      <div
                        className={`h-2.5 rounded-full transition-all duration-300 ${
                          isFilled ? 'bg-zinc-950' : 'bg-zinc-200 border border-zinc-300'
                        }`}
                      />
                      <div className="text-[10px] text-center font-mono text-zinc-500">
                        {isFilled ? '25 p. ✓' : '25 p.'}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* The 4 Lots Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[0, 1, 2, 3].map((slotIdx) => {
                const lotIndex = (slotIdx + 1) as 1 | 2 | 3 | 4;
                const lotProduct = pallet.lots[slotIdx];

                if (!lotProduct) {
                  return (
                    <div
                      key={slotIdx}
                      onClick={() => onRequestPickModel(lotIndex)}
                      className="border-2 border-dashed border-zinc-300 hover:border-zinc-950 hover:bg-zinc-50 rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer transition-all min-h-[110px] group"
                    >
                      <div className="w-8 h-8 rounded-full bg-zinc-100 group-hover:bg-zinc-200 flex items-center justify-center text-zinc-600 mb-1.5 transition-colors">
                        <Plus className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-extrabold text-zinc-950">
                        Lot {lotIndex} : Choisir 25 paires
                      </span>
                      <span className="text-[11px] text-zinc-500 mt-0.5">
                        Cliquez pour sélectionner marque & modèle
                      </span>
                    </div>
                  );
                }

                return (
                  <div
                    key={slotIdx}
                    className="bg-white border border-zinc-200 rounded-2xl p-3 flex items-center justify-between gap-3 shadow-2xs hover:border-zinc-300 transition-all"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-zinc-100 border border-zinc-200 flex-shrink-0">
                        <img
                          src={lotProduct.images[0]}
                          alt={lotProduct.name}
                          className="w-full h-full object-cover"
                        />
                        {watermarkSettings && <WatermarkOverlay settings={watermarkSettings} />}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[9px] font-mono font-bold uppercase bg-zinc-100 text-zinc-700 px-1.5 py-0.2 rounded border border-zinc-200">
                            Lot {lotIndex}
                          </span>
                          <span className="text-[9px] font-bold text-zinc-600 truncate">
                            {lotProduct.brand}
                          </span>
                        </div>
                        <h6 className="text-xs font-bold text-zinc-950 truncate mt-0.5">
                          {lotProduct.name}
                        </h6>
                        <span className="text-[10px] font-mono font-bold text-emerald-700">
                          25 paires incluses
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button
                        type="button"
                        onClick={() => onRequestPickModel(lotIndex)}
                        className="p-1.5 text-zinc-500 hover:text-zinc-950 hover:bg-zinc-100 rounded-lg transition-colors"
                        title="Remplacer ce modèle"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleClearLot(slotIdx)}
                        className="p-1.5 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Retirer ce lot"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Discrete explanation note */}
            <p className="text-[11px] text-zinc-500 leading-relaxed px-1">
              * Vous pouvez mixer les marques et les modèles (ex: 2 lots Nike + 2 lots Adidas, ou 4 modèles différents). Chaque lot correspond strictement à 25 paires. Les 4 lots doivent être sélectionnés pour valider la palette.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
