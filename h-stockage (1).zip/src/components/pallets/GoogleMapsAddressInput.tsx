import React, { useState, useEffect, useRef } from 'react';
import { MapPin, Search, Navigation, Check, Loader2, AlertCircle } from 'lucide-react';

export interface PlaceSelection {
  formattedAddress: string;
  streetAddress: string;
  postalCode: string;
  city: string;
  latitude?: number;
  longitude?: number;
  placeId?: string;
}

interface GoogleMapsAddressInputProps {
  value: string;
  postalCode?: string;
  city?: string;
  onChange: (value: string) => void;
  onAddressSelect: (selection: PlaceSelection) => void;
  hasError?: boolean;
  errorMessage?: string;
  disabled?: boolean;
}

interface Prediction {
  place_id: string;
  description: string;
  structured_formatting?: {
    main_text: string;
    secondary_text: string;
  };
}

export const GoogleMapsAddressInput: React.FC<GoogleMapsAddressInputProps> = ({
  value,
  postalCode,
  city,
  onChange,
  onAddressSelect,
  hasError,
  errorMessage,
  disabled,
}) => {
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Debounced autocomplete query
  useEffect(() => {
    if (!value || value.length < 3 || confirmed) {
      setPredictions([]);
      setIsOpen(false);
      return;
    }

    const timer = setTimeout(async () => {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/maps/autocomplete?input=${encodeURIComponent(value)}`);
        if (res.ok) {
          const data = await res.json();
          if (data.predictions && Array.isArray(data.predictions)) {
            setPredictions(data.predictions);
            setIsOpen(data.predictions.length > 0);
          }
        }
      } catch (err) {
        console.error('Google Maps Autocomplete fetch error:', err);
      } finally {
        setIsLoading(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [value, confirmed]);

  // Handle outside click to close dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectPrediction = async (prediction: Prediction) => {
    setIsLoading(true);
    setIsOpen(false);
    setConfirmed(true);

    try {
      const res = await fetch(`/api/maps/place-details?placeId=${encodeURIComponent(prediction.place_id)}`);
      if (res.ok) {
        const data = await res.json();
        const result = data.result;

        let streetNumber = '';
        let route = '';
        let pCode = '';
        let locality = '';

        if (result && Array.isArray(result.address_components)) {
          for (const comp of result.address_components) {
            const types = comp.types || [];
            if (types.includes('street_number')) streetNumber = comp.long_name;
            if (types.includes('route')) route = comp.long_name;
            if (types.includes('postal_code')) pCode = comp.long_name;
            if (types.includes('locality')) locality = comp.long_name;
          }
        }

        const streetAddress = streetNumber ? `${streetNumber} ${route}`.trim() : route || prediction.description.split(',')[0];
        const formatted = result?.formatted_address || prediction.description;
        const lat = result?.geometry?.location?.lat;
        const lng = result?.geometry?.location?.lng;

        onChange(streetAddress || formatted);

        onAddressSelect({
          formattedAddress: formatted,
          streetAddress: streetAddress || formatted,
          postalCode: pCode,
          city: locality,
          latitude: lat,
          longitude: lng,
          placeId: prediction.place_id,
        });
      } else {
        // Fallback with prediction text
        onChange(prediction.description);
        onAddressSelect({
          formattedAddress: prediction.description,
          streetAddress: prediction.description,
          postalCode: postalCode || '',
          city: city || '',
          placeId: prediction.place_id,
        });
      }
    } catch (err) {
      console.error('Error fetching place details:', err);
      onChange(prediction.description);
    } finally {
      setIsLoading(false);
    }
  };

  // Browser Geolocation
  const handleGeolocation = () => {
    if (!navigator.geolocation) {
      alert('La géolocalisation n\'est pas supportée par votre navigateur.');
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords;
          const res = await fetch(`/api/maps/reverse-geocode?lat=${latitude}&lng=${longitude}`);
          if (res.ok) {
            const data = await res.json();
            const firstResult = data.results?.[0];
            if (firstResult) {
              let streetNumber = '';
              let route = '';
              let pCode = '';
              let locality = '';

              for (const comp of firstResult.address_components || []) {
                const types = comp.types || [];
                if (types.includes('street_number')) streetNumber = comp.long_name;
                if (types.includes('route')) route = comp.long_name;
                if (types.includes('postal_code')) pCode = comp.long_name;
                if (types.includes('locality')) locality = comp.long_name;
              }

              const streetAddress = streetNumber ? `${streetNumber} ${route}`.trim() : route || firstResult.formatted_address;

              onChange(streetAddress);
              setConfirmed(true);

              onAddressSelect({
                formattedAddress: firstResult.formatted_address,
                streetAddress: streetAddress,
                postalCode: pCode,
                city: locality,
                latitude,
                longitude,
                placeId: firstResult.place_id,
              });
            }
          }
        } catch (err) {
          console.error('Reverse geocode error:', err);
        } finally {
          setIsLocating(false);
        }
      },
      (err) => {
        console.warn('Geolocation error or denied:', err);
        setIsLocating(false);
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <div className="relative flex items-center">
        <div className="absolute left-3 text-zinc-400 pointer-events-none">
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin text-zinc-950" />
          ) : confirmed ? (
            <Check className="w-4 h-4 text-emerald-600" />
          ) : (
            <MapPin className="w-4 h-4 text-zinc-500" />
          )}
        </div>

        <input
          type="text"
          value={value}
          disabled={disabled}
          onChange={(e) => {
            setConfirmed(false);
            onChange(e.target.value);
          }}
          placeholder="Tapez le numéro et le nom de la rue (ex: 26 rue Alfred Nobel)..."
          className={`w-full bg-zinc-50 border rounded-xl py-3 pl-10 pr-24 text-xs text-zinc-900 focus:bg-white focus:border-zinc-950 focus:ring-1 focus:ring-zinc-950 transition-colors ${
            hasError ? 'border-red-500' : 'border-zinc-300'
          }`}
        />

        <div className="absolute right-2 flex items-center gap-1">
          <button
            type="button"
            onClick={handleGeolocation}
            disabled={isLocating || disabled}
            title="Utiliser ma position actuelle"
            className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-950 hover:bg-zinc-200/70 transition-colors disabled:opacity-40"
          >
            {isLocating ? (
              <Loader2 className="w-4 h-4 animate-spin text-zinc-900" />
            ) : (
              <Navigation className="w-4 h-4" />
            )}
          </button>
          <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-zinc-200 text-zinc-700">
            Maps
          </span>
        </div>
      </div>

      {hasError && errorMessage && (
        <span className="text-[10px] text-red-500 font-bold block mt-1 flex items-center gap-1">
          <AlertCircle className="w-3 h-3" />
          {errorMessage}
        </span>
      )}

      {/* Autocomplete Predictions Dropdown */}
      {isOpen && predictions.length > 0 && (
        <div className="absolute z-50 left-0 right-0 mt-1.5 bg-white border border-zinc-200 rounded-2xl shadow-xl overflow-hidden divide-y divide-zinc-100 max-h-64 overflow-y-auto">
          <div className="px-3 py-1.5 bg-zinc-50 text-[10px] font-mono font-bold uppercase text-zinc-500 tracking-wider flex items-center justify-between">
            <span>Suggestions d'adresses (Google Maps)</span>
            <span className="text-zinc-400">France métropolitaine</span>
          </div>
          {predictions.map((p) => (
            <button
              key={p.place_id}
              type="button"
              onClick={() => handleSelectPrediction(p)}
              className="w-full text-left px-3.5 py-2.5 hover:bg-zinc-50 transition-colors flex items-start gap-2.5 text-xs text-zinc-800"
            >
              <MapPin className="w-4 h-4 text-zinc-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1 truncate">
                <span className="font-bold text-zinc-950 block truncate">
                  {p.structured_formatting?.main_text || p.description.split(',')[0]}
                </span>
                <span className="text-[11px] text-zinc-500 block truncate">
                  {p.structured_formatting?.secondary_text || p.description}
                </span>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
