import React, { useState } from 'react';
import {
  Search,
  Package,
  Clock,
  Download,
  AlertTriangle,
  CheckCircle2,
  Truck,
  MessageCircle,
  FileText,
  Upload,
} from 'lucide-react';
import { PalletOrder, OrderStatus } from '../../types';
import {
  getPalletOrderById,
  getShippingConfig,
  getBankPaymentDetails,
  getCommercialWhatsAppNumber,
  submitPaymentProof,
} from '../../services/palletOrderService';
import { generateOrderPdf } from '../../services/pdfService';

interface OrderTrackingViewProps {
  onNavigateToOrder?: () => void;
}

export const OrderTrackingView: React.FC<OrderTrackingViewProps> = ({
  onNavigateToOrder,
}) => {
  const [searchId, setSearchId] = useState('');
  const [searchEmail, setSearchEmail] = useState('');
  const [foundOrder, setFoundOrder] = useState<PalletOrder | null>(null);
  const [searched, setSearched] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // New proof upload in tracking if rejected or re-upload needed
  const [proofFile, setProofFile] = useState<{ name: string; type: string; data: string } | null>(null);
  const [proofSender, setProofSender] = useState('');
  const [proofReference, setProofReference] = useState('');
  const [proofAmount, setProofAmount] = useState('');
  const [proofSubmitting, setProofSubmitting] = useState(false);
  const [proofSuccess, setProofSuccess] = useState(false);

  const config = getShippingConfig();
  const bankDetails = getBankPaymentDetails();
  const whatsappNumber = getCommercialWhatsAppNumber();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSearched(true);
    setProofSuccess(false);

    const cleanId = searchId.trim().toUpperCase();
    const order = getPalletOrderById(cleanId);

    if (!order) {
      setFoundOrder(null);
      setErrorMsg(`Aucune commande trouvée pour le numéro "${cleanId}". Veuillez vérifier votre référence (ex : CMD-2026-XXXX).`);
      return;
    }

    if (searchEmail.trim()) {
      if (order.customer.email.toLowerCase().trim() !== searchEmail.toLowerCase().trim()) {
        setFoundOrder(null);
        setErrorMsg('L\'adresse e-mail ne correspond pas à celle enregistrée pour cette commande.');
        return;
      }
    }

    setFoundOrder(order);
    setProofSender(`${order.customer.firstName} ${order.customer.lastName}`);
    setProofReference(order.id);
    setProofAmount(order.totalAmount.toString());
  };

  const handleReuploadProof = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foundOrder || !proofFile) return;

    setProofSubmitting(true);
    try {
      const updated = submitPaymentProof(foundOrder.id, {
        uploadedAt: new Date().toISOString(),
        paymentMethod: 'Virement bancaire SEPA',
        senderName: proofSender || `${foundOrder.customer.firstName} ${foundOrder.customer.lastName}`,
        transactionReference: proofReference || foundOrder.id,
        paymentDate: new Date().toISOString().split('T')[0],
        paidAmount: parseFloat(proofAmount) || foundOrder.totalAmount,
        fileName: proofFile.name,
        fileData: proofFile.data,
        fileType: proofFile.type,
      });

      if (updated) {
        setFoundOrder(updated);
        setProofSuccess(true);
      }
    } catch {
      setErrorMsg('Erreur lors du renvoi du justificatif.');
    } finally {
      setProofSubmitting(false);
    }
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'Paiement confirmé':
      case 'Livrée':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'Paiement refusé ou justificatif invalide':
      case 'Commande annulée':
        return 'bg-red-50 text-red-800 border-red-200';
      case 'Justificatif reçu':
      case 'Paiement en cours de vérification':
        return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'Commande en préparation':
      case 'Expédiée':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      default:
        return 'bg-zinc-100 text-zinc-800 border-zinc-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Title */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-zinc-100 text-zinc-800 rounded-full text-xs font-mono font-bold mb-3 border border-zinc-200">
          <Truck className="w-3.5 h-3.5 text-zinc-900" />
          <span>SUIVI LOGISTIQUE & ÉTAT DE COMMANDE</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-zinc-950 tracking-tight">
          SUIVRE MA COMMANDE DE PALETTES
        </h1>
        <p className="text-zinc-500 text-xs sm:text-sm mt-1">
          Renseignez votre numéro de commande unique (ex: CMD-2026-XXXX) pour consulter l'avancement, télécharger vos documents et transmettre votre justificatif.
        </p>
      </div>

      {/* Search Box */}
      <div className="bg-white border border-zinc-200 rounded-3xl p-6 sm:p-8 shadow-xs mb-8">
        <form onSubmit={handleSearch} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-1.5">
                Numéro de commande unique *
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Ex : CMD-2026-4821"
                  value={searchId}
                  onChange={(e) => setSearchId(e.target.value)}
                  required
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl p-3 text-xs text-zinc-900 font-mono uppercase focus:bg-white focus:border-zinc-950"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-1.5">
                Adresse e-mail associée (Optionnel)
              </label>
              <input
                type="email"
                placeholder="Ex : contact@monmagasin.fr"
                value={searchEmail}
                onChange={(e) => setSearchEmail(e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl p-3 text-xs text-zinc-900 focus:bg-white focus:border-zinc-950"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3.5 bg-zinc-950 text-white hover:bg-zinc-800 font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2"
          >
            <Search className="w-4 h-4" />
            <span>Rechercher ma commande</span>
          </button>
        </form>

        {errorMsg && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-xs font-semibold flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Found Order Card */}
      {foundOrder && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white border border-zinc-200 rounded-3xl p-6 sm:p-8 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-200">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-xl font-black text-zinc-950 font-mono">
                    {foundOrder.id}
                  </h2>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${getStatusBadge(foundOrder.status)}`}>
                    {foundOrder.status}
                  </span>
                </div>
                <p className="text-xs text-zinc-500 mt-1">
                  Enregistrée le {foundOrder.formattedDate} pour {foundOrder.customer.firstName} {foundOrder.customer.lastName}
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                {/* Download Pro Forma */}
                <button
                  type="button"
                  onClick={() => generateOrderPdf(foundOrder, bankDetails, config, false)}
                  className="px-4 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-900 border border-zinc-300 font-bold text-xs rounded-xl flex items-center gap-2 transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Facture Pro Forma (PDF)</span>
                </button>

                {/* Download Final Invoice if Paid */}
                {['Paiement confirmé', 'Commande en préparation', 'Expédiée', 'Livrée'].includes(foundOrder.status) && (
                  <button
                    type="button"
                    onClick={() => generateOrderPdf(foundOrder, bankDetails, config, true)}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-2 transition-all"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Facture Acquittée (PDF)</span>
                  </button>
                )}
              </div>
            </div>

            {/* Rejection Alert if rejected */}
            {foundOrder.status === 'Paiement refusé ou justificatif invalide' && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-2xl text-xs space-y-2">
                <div className="flex items-center gap-2 text-red-800 font-bold">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <span>Justificatif refusé par l'administration comptable</span>
                </div>
                <p className="text-red-700">
                  Motif : {foundOrder.rejectionReason || 'Document illisible ou référence introuvable sur nos relevés bancaires.'}
                </p>
                <p className="text-zinc-600">
                  Veuillez téléverser ci-dessous une nouvelle preuve valide afin de débloquer le traitement de votre commande.
                </p>
              </div>
            )}

            {/* Carrier & Tracking if shipped */}
            {foundOrder.trackingNumber && (
              <div className="p-4 bg-zinc-950 text-white rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-mono text-zinc-400 uppercase block">Suivi d'expédition Transporteur</span>
                  <p className="font-bold text-sm">
                    {foundOrder.carrierName || 'Transporteur spécialisé'} : <span className="font-mono text-emerald-400">{foundOrder.trackingNumber}</span>
                  </p>
                </div>
                <span className="text-[11px] text-zinc-300">
                  Livraison par camion avec hayon et transpalette.
                </span>
              </div>
            )}

            {/* Order Content & Financial Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-2xl space-y-2">
                <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-zinc-500 block">
                  Détail de la commande
                </span>
                <p className="text-zinc-700">
                  Marchandises : <strong>{foundOrder.palletCount} palette(s) ({foundOrder.totalPairs || foundOrder.palletCount * 100} paires) × {foundOrder.palletUnitPrice.toFixed(2)} €</strong>
                </p>
                {((foundOrder.palletsComposition && foundOrder.palletsComposition.length > 0) || (foundOrder.items && foundOrder.items.length > 0)) && (
                  <div className="space-y-1.5 py-1 text-[11px]">
                    {(foundOrder.palletsComposition || foundOrder.items || []).map((pal: any, idx: number) => {
                      const isMixed = pal.type === 'MIXED' || pal.palletType === 'MIXED' || Boolean(pal.mixedLots && pal.mixedLots.length > 0);
                      const lots = pal.mixedLots;
                      return (
                        <div key={idx} className="bg-white p-2 rounded-lg border border-zinc-200">
                          <div className="font-bold text-zinc-900">
                            Palette {idx + 1} : {isMixed ? 'Mixte (4 lots × 25 p.)' : `${pal.brand || foundOrder.brand} - ${pal.model || foundOrder.model}`}
                          </div>
                          {isMixed && lots && (
                            <div className="text-[10px] text-zinc-600 mt-0.5">
                              {lots.map((l: any, lIdx: number) => `L${l.lotIndex || lIdx + 1}: ${l.brand} ${l.model}`).join(' • ')}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
                <p className="text-zinc-700">
                  Sous-total : <strong className="font-mono">{foundOrder.merchandiseSubtotal.toFixed(2)} €</strong>
                </p>
                <p className="text-zinc-700">
                  Livraison : <strong className="font-mono">{foundOrder.deliveryIsQuoteRequired ? 'Sur devis' : `${foundOrder.deliveryFee.toFixed(2)} €`}</strong>
                </p>
                <p className="text-zinc-950 font-black text-sm pt-1 border-t border-zinc-200">
                  Total : <span className="font-mono">{foundOrder.totalAmount.toFixed(2)} €</span>
                </p>
              </div>

              <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-2xl space-y-2">
                <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-zinc-500 block">
                  Adresse de livraison
                </span>
                <p className="font-bold text-zinc-900">{foundOrder.customer.deliveryAddress}</p>
                <p className="text-zinc-600">{foundOrder.customer.postalCode} {foundOrder.customer.city} ({foundOrder.customer.country})</p>
                <p className="text-zinc-500 text-[11px]">Tél : {foundOrder.customer.phone} • WhatsApp : {foundOrder.customer.whatsapp}</p>
              </div>
            </div>

            {/* If proof rejected or not yet provided, show upload form */}
            {(!foundOrder.paymentProof || foundOrder.status === 'Paiement refusé ou justificatif invalide' || foundOrder.status === 'En attente de paiement') && (
              <div className="p-6 bg-zinc-50 border border-zinc-200 rounded-2xl space-y-4">
                <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
                  <Upload className="w-4 h-4 text-zinc-700" />
                  Transmettre un justificatif de paiement
                </h3>

                {proofSuccess ? (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold">
                    Votre nouveau justificatif a bien été transmis. Notre service comptable va le vérifier sous 24h ouvrées.
                  </div>
                ) : (
                  <form onSubmit={handleReuploadProof} className="space-y-3 text-xs">
                    <div>
                      <label className="block font-bold text-zinc-700 mb-1">
                        Sélectionner la preuve de virement (JPG, PNG, PDF) :
                      </label>
                      <input
                        type="file"
                        accept=".jpg,.jpeg,.png,.pdf"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          const reader = new FileReader();
                          reader.onload = () => {
                            setProofFile({ name: file.name, type: file.type, data: reader.result as string });
                          };
                          reader.readAsDataURL(file);
                        }}
                        className="w-full text-xs"
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={proofSubmitting || !proofFile}
                      className="px-6 py-2.5 bg-zinc-950 text-white hover:bg-zinc-800 font-bold text-xs rounded-xl disabled:opacity-50"
                    >
                      {proofSubmitting ? 'Envoi...' : 'Envoyer la preuve'}
                    </button>
                  </form>
                )}
              </div>
            )}

            {/* History timeline */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-3 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                Historique des événements
              </h3>
              <div className="space-y-2">
                {foundOrder.history.map((h, i) => (
                  <div key={i} className="text-xs border-l-2 border-zinc-300 pl-3 py-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-zinc-900">{h.status}</span>
                      <span className="text-[10px] text-zinc-400 font-mono">{h.timestamp}</span>
                    </div>
                    {h.note && <p className="text-zinc-500 text-[11px] mt-0.5">{h.note}</p>}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
