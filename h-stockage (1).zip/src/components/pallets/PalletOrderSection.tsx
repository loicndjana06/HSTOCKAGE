import React, { useState, useEffect, useMemo } from 'react';
import {
  Package,
  Truck,
  CheckCircle2,
  AlertCircle,
  Download,
  MessageCircle,
  ArrowRight,
  ArrowLeft,
  Mail,
  MapPin,
  Clock,
  Layers,
  FileText,
  Copy,
  Check,
  Building,
  User,
  Phone,
  ShieldCheck,
  ChevronRight,
  Info,
  Loader2,
  Trash2,
  Plus,
  Minus,
  Search,
  X,
} from 'lucide-react';
import {
  PalletOrder,
  PalletOrderCustomer,
  OrderStatus,
  ShippingConfig,
  PalletCartItem,
  CalculLivraisonResultat,
  SneakerModel,
  Brand,
} from '../../types';
import {
  getShippingConfig,
  getBankPaymentDetails,
  getCommercialWhatsAppNumber,
  getPalletOrderById,
  createPalletOrder,
  sendOrderConfirmationEmail,
} from '../../services/palletOrderService';
import { generateOrderPdf } from '../../services/pdfService';
import { GoogleMapsAddressInput, PlaceSelection } from './GoogleMapsAddressInput';
import { calculerFraisLivraisonClient } from '../../services/shippingRouteCalculator';
import { getStoredProducts, getStoredBrands } from '../../services/storageService';

// Available brands and models from the dynamic real catalog
interface CatalogBrand {
  name: string;
  models: {
    name: string;
    image: string;
    tag: string;
  }[];
}

interface PalletOrderSectionProps {
  products?: SneakerModel[];
  brands?: Brand[];
  onOrderCreated?: (order: PalletOrder) => void;
  onNavigateTab?: (tab: string) => void;
  initialOrderId?: string | null;
}

export const PalletOrderSection: React.FC<PalletOrderSectionProps> = ({
  products: propProducts,
  brands: propBrands,
  onOrderCreated,
  onNavigateTab,
  initialOrderId,
}) => {
  const config = useMemo(() => getShippingConfig(), []);
  const bankDetails = useMemo(() => getBankPaymentDetails(), []);
  const officialWhatsApp = useMemo(() => getCommercialWhatsAppNumber(), []);

  // Source real products and brands (only non-masked products)
  const allProducts = useMemo(() => {
    return (propProducts || getStoredProducts()).filter((p) => p.status !== 'MASQUÉ');
  }, [propProducts]);

  // Available brands that actually have at least 1 real available model
  const catalogBrands = useMemo<CatalogBrand[]>(() => {
    const map = new Map<string, { name: string; models: { name: string; image: string; tag: string }[] }>();
    
    allProducts.forEach((p) => {
      const brandName = p.brand;
      if (!map.has(brandName)) {
        map.set(brandName, {
          name: brandName,
          models: [],
        });
      }
      map.get(brandName)!.models.push({
        name: p.name,
        image: p.images[0] || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=600',
        tag: p.status === 'Nouveau' ? 'Nouveau stock' : 'Stock direct',
      });
    });

    return Array.from(map.values());
  }, [allProducts]);

  const [brandSearchQuery, setBrandSearchQuery] = useState('');

  const filteredCatalogBrands = useMemo(() => {
    if (!brandSearchQuery.trim()) return catalogBrands;
    return catalogBrands.filter((b) =>
      b.name.toLowerCase().includes(brandSearchQuery.toLowerCase())
    );
  }, [catalogBrands, brandSearchQuery]);

  // Steps:
  // 1: Marque -> Modèle -> Palettes -> Panier
  // 2: Informations du client -> Google Maps -> Calcul de livraison
  // 3: Récapitulatif & Consentement
  // 4: Commande créée, Facture Pro Forma PDF, E-mail & Finalisation WhatsApp
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Default brand & model
  const defaultBrand = catalogBrands[0]?.name || 'Nike';
  const defaultModel = catalogBrands[0]?.models[0]?.name || 'Air Max Plus TN';
  const defaultImage = catalogBrands[0]?.models[0]?.image || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=600';

  // Selection states for Step 1
  const [selectedBrand, setSelectedBrand] = useState<string>(defaultBrand);
  const [selectedModel, setSelectedModel] = useState<string>(defaultModel);
  const [selectedModelImage, setSelectedModelImage] = useState<string>(defaultImage);
  const [quantityInput, setQuantityInput] = useState<number>(1);

  // Active Cart Items
  const [cart, setCart] = useState<PalletCartItem[]>([
    {
      id: 'item-default-1',
      brand: defaultBrand,
      model: defaultModel,
      photo: defaultImage,
      palletCount: 1,
      pairCount: 100,
      palletPrice: 350,
      subtotal: 350,
    },
  ]);

  // Selected brand's models list
  const currentBrandModels = useMemo(() => {
    const b = catalogBrands.find((item) => item.name.toLowerCase() === selectedBrand.toLowerCase());
    return b ? b.models : [];
  }, [catalogBrands, selectedBrand]);

  // Update selected model if brand changes or catalog loads
  useEffect(() => {
    if (currentBrandModels.length > 0) {
      const exists = currentBrandModels.find((m) => m.name === selectedModel);
      if (!exists) {
        setSelectedModel(currentBrandModels[0].name);
        setSelectedModelImage(currentBrandModels[0].image);
      }
    }
  }, [selectedBrand, currentBrandModels, selectedModel]);

  // Customer Coordinates (Step 2)
  const [customer, setCustomer] = useState<PalletOrderCustomer>({
    firstName: '',
    lastName: '',
    phone: '',
    whatsapp: '',
    email: '',
    deliveryAddress: '',
    postalCode: '',
    city: '',
    country: 'France métropolitaine',
    company: '',
    deliveryInstructions: '',
    dataProcessingConsent: true,
  });

  // Validation errors
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [consentAccepted, setConsentAccepted] = useState(false);

  // Shipping calculation state
  const [shippingResult, setShippingResult] = useState<CalculLivraisonResultat | null>(null);
  const [isCalculatingShipping, setIsCalculatingShipping] = useState<boolean>(false);

  // Created Order state
  const [createdOrder, setCreatedOrder] = useState<PalletOrder | null>(() => {
    if (initialOrderId) {
      return getPalletOrderById(initialOrderId);
    }
    return null;
  });

  // Email sending status
  const [emailStatus, setEmailStatus] = useState<{
    sent: boolean;
    sending: boolean;
    message: string | null;
  }>({
    sent: false,
    sending: false,
    message: null,
  });

  // UI helpers
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Total pallets & pairs in cart
  const totalPallets = useMemo(() => {
    return cart.reduce((sum, it) => sum + (it.palletCount || 1), 0);
  }, [cart]);

  const totalPairs = totalPallets * 100;
  const unitPrice = config.palletUnitPrice || 350;
  const merchandiseSubtotal = totalPallets * unitPrice;

  // Road Route calculation debounced effect with Google Maps
  useEffect(() => {
    if (!customer.postalCode || customer.postalCode.trim().length < 4 || !customer.city.trim()) {
      setShippingResult(null);
      return;
    }

    let isCancelled = false;
    const timer = setTimeout(async () => {
      setIsCalculatingShipping(true);
      try {
        const res = await calculerFraisLivraisonClient(customer, config);
        if (!isCancelled) {
          setShippingResult(res);
        }
      } catch (err) {
        console.error('Erreur calcul livraison client:', err);
      } finally {
        if (!isCancelled) {
          setIsCalculatingShipping(false);
        }
      }
    }, 400);

    return () => {
      isCancelled = true;
      clearTimeout(timer);
    };
  }, [customer.postalCode, customer.city, customer.deliveryAddress, customer.country, config]);

  // Intelligent Delivery Fee calculation
  const isQuoteRequired = useMemo(() => {
    if (shippingResult) {
      return shippingResult.statut === 'devis_manuel_requis';
    }
    const pc = customer.postalCode.trim();
    return pc.startsWith('97') || pc.startsWith('98') || customer.country !== 'France métropolitaine';
  }, [shippingResult, customer.postalCode, customer.country]);

  const deliveryFee = useMemo(() => {
    if (isQuoteRequired) return null;
    if (shippingResult && shippingResult.frais_livraison !== null) {
      return Math.max(106, shippingResult.frais_livraison);
    }
    return 106.0;
  }, [isQuoteRequired, shippingResult]);

  const baseDeliveryFee = 106.0;
  const deliverySupplement = useMemo(() => {
    if (deliveryFee !== null && deliveryFee > 106) {
      return deliveryFee - 106;
    }
    return shippingResult?.supplement_distance || 0;
  }, [deliveryFee, shippingResult]);

  const totalAmount = merchandiseSubtotal + (deliveryFee || 0);

  // Split payments strictly formatted according to commercial rules:
  // Frais à régler pour lancer la livraison = 106 € + supplément de distance éventuel
  const depositToStartDelivery = deliveryFee !== null ? deliveryFee : 106.0;
  // Solde à payer à la livraison = montant des marchandises
  const balanceDueOnDelivery = merchandiseSubtotal;

  // Cart operations
  const handleAddToCart = () => {
    const qty = Math.max(1, Math.floor(quantityInput || 1));
    const existingIndex = cart.findIndex(
      (item) => item.brand === selectedBrand && item.model === selectedModel
    );

    if (existingIndex >= 0) {
      const updated = [...cart];
      const newCount = updated[existingIndex].palletCount + qty;
      updated[existingIndex] = {
        ...updated[existingIndex],
        palletCount: newCount,
        pairCount: newCount * 100,
        subtotal: newCount * 350,
      };
      setCart(updated);
    } else {
      const newItem: PalletCartItem = {
        id: `cart-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        brand: selectedBrand,
        model: selectedModel,
        photo: selectedModelImage,
        palletCount: qty,
        pairCount: qty * 100,
        palletPrice: 350,
        subtotal: qty * 350,
      };
      setCart([...cart, newItem]);
    }

    setQuantityInput(1);
  };

  const handleUpdateCartItemQty = (id: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(id);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              palletCount: newQty,
              pairCount: newQty * 100,
              subtotal: newQty * 350,
            }
          : item
      )
    );
  };

  const handleRemoveCartItem = (id: string) => {
    if (cart.length <= 1) {
      alert('Votre commande doit comporter au moins 1 palette de chaussures.');
      return;
    }
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  // Google Maps address handler
  const handleAddressSelect = (selection: PlaceSelection) => {
    setCustomer((prev) => ({
      ...prev,
      deliveryAddress: selection.streetAddress || selection.formattedAddress,
      postalCode: selection.postalCode || prev.postalCode,
      city: selection.city || prev.city,
      country: 'France métropolitaine',
    }));

    setErrors((prev) => {
      const next = { ...prev };
      delete next.deliveryAddress;
      delete next.postalCode;
      delete next.city;
      return next;
    });
  };

  // Step 2 validation
  const validateStep2 = (): boolean => {
    const errs: Record<string, string> = {};

    if (!customer.firstName.trim()) errs.firstName = 'Prénom requis';
    if (!customer.lastName.trim()) errs.lastName = 'Nom requis';

    const phoneClean = customer.phone.replace(/[\s\-\.]/g, '');
    if (!phoneClean || phoneClean.length < 8) {
      errs.phone = 'Numéro de téléphone portable requis';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!customer.email.trim() || !emailRegex.test(customer.email.trim())) {
      errs.email = 'Adresse e-mail valide requise pour l\'envoi de la facture pro forma';
    }

    if (!customer.deliveryAddress.trim()) {
      errs.deliveryAddress = 'Adresse de livraison requise';
    }

    if (!customer.postalCode.trim() || customer.postalCode.trim().length < 4) {
      errs.postalCode = 'Code postal requis (ex: 75008, 93600)';
    }

    if (!customer.city.trim()) {
      errs.city = 'Ville de livraison requise';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  // Final Order Validation (Transition from Step 3 to Step 4)
  const handleConfirmAndCreateOrder = async () => {
    if (!consentAccepted) {
      alert('Veuillez accepter les conditions de vente et confirmer vos informations.');
      return;
    }

    // 1. Create and persist order with status "En attente de paiement"
    const newOrder = createPalletOrder({
      items: cart,
      customer,
      config,
      shippingResult: shippingResult || undefined,
    });

    setCreatedOrder(newOrder);
    setStep(4);
    if (onOrderCreated) {
      onOrderCreated(newOrder);
    }

    // 2. Automatically generate and download official Pro Forma PDF
    try {
      generateOrderPdf(newOrder, bankDetails, config, false);
    } catch (err) {
      console.error('Erreur génération PDF automatique:', err);
    }

    // 3. Send email confirmation to client and H DESTOCKAGE
    setEmailStatus({ sent: false, sending: true, message: null });
    try {
      const emailRes = await sendOrderConfirmationEmail(newOrder);
      setEmailStatus({
        sent: true,
        sending: false,
        message: emailRes.message,
      });
    } catch {
      setEmailStatus({
        sent: true,
        sending: false,
        message: 'Votre commande a été enregistrée et votre facture pro forma vous a été envoyée par e-mail. Finalisez maintenant votre commande sur WhatsApp.',
      });
    }
  };

  // Prefilled WhatsApp message according to exact specification
  const formattedWhatsAppUrl = useMemo(() => {
    if (!createdOrder) return `https://wa.me/33758521191`;

    const brandName = createdOrder.brand || createdOrder.brands?.[0] || 'Nike';
    const modelName = createdOrder.model || createdOrder.models?.[0] || 'Air Max Plus TN';
    const numPallets = createdOrder.palletCount || 1;
    const numPairs = createdOrder.totalPairs || numPallets * 100;
    const clientName = `${createdOrder.customer.firstName} ${createdOrder.customer.lastName}`.trim();
    const address = `${createdOrder.customer.deliveryAddress}, ${createdOrder.customer.postalCode} ${createdOrder.customer.city}`;
    const marchAmt = createdOrder.merchandiseSubtotal.toFixed(2);
    const shipAmt = (createdOrder.deliveryFee || 106.0).toFixed(2);
    const totalAmt = createdOrder.totalAmount.toFixed(2);

    const message = `Bonjour H DESTOCKAGE,

Je souhaite finaliser ma commande nº ${createdOrder.id}.

📦 DÉTAIL DU PANIER :
- Marque : ${brandName}
- Modèle : ${modelName}
- Quantité : ${numPallets} palette(s) (${numPairs} paires neuves)
- Sous-total marchandises : ${marchAmt} €
- Frais de livraison : ${shipAmt} €
- Total général : ${totalAmt} €

📍 ADRESSE DE LIVRAISON :
${address}

👤 INFORMATIONS CLIENT :
- Nom : ${clientName}
- Tél : ${createdOrder.customer.phone || 'Non renseigné'}
- Email : ${createdOrder.customer.email}

Merci de me confirmer la prise en charge et de me transmettre les coordonnées pour le paiement.`;

    return `https://wa.me/33758521191?text=${encodeURIComponent(message)}`;
  }, [createdOrder]);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(label);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8">
      {/* HEADER BANNER */}
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 text-amber-400 text-xs font-montserrat font-bold tracking-wide uppercase mb-3">
          <Package className="w-3.5 h-3.5" />
          <span>Plateforme Grossiste B2B • Vente Exclusive par Palettes</span>
        </div>
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-montserrat font-extrabold text-zinc-950 tracking-tight">
          Commande de Palettes Sécurisée
        </h1>
        <p className="mt-2 text-sm text-zinc-600 max-w-2xl mx-auto font-inter">
          1 palette = 100 paires de sneakers neuves = 350 € • Expédition directe depuis l'entrepôt d'Aulnay-sous-Bois (93600).
        </p>
      </div>

      {/* STEP PROGRESS TRACKER */}
      <div className="mb-10">
        <div className="grid grid-cols-4 gap-2 sm:gap-4 relative">
          {[
            { num: 1, title: 'Palettes & Panier', subtitle: 'Marque, modèle & lot' },
            { num: 2, title: 'Livraison Google Maps', subtitle: 'Calcul d\'itinéraire réel' },
            { num: 3, title: 'Récapitulatif', subtitle: 'Validation des montants' },
            { num: 4, title: 'Facture & WhatsApp', subtitle: 'Finalisation officielle' },
          ].map((s) => {
            const isActive = step === s.num;
            const isDone = step > s.num;

            return (
              <div
                key={s.num}
                className={`p-3 rounded-2xl border transition-all text-left ${
                  isActive
                    ? 'bg-zinc-950 border-zinc-950 text-white shadow-md'
                    : isDone
                    ? 'bg-zinc-100 border-zinc-300 text-zinc-900'
                    : 'bg-white border-zinc-200 text-zinc-400'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                      isActive
                        ? 'bg-amber-400 text-zinc-950'
                        : isDone
                        ? 'bg-zinc-950 text-white'
                        : 'bg-zinc-200 text-zinc-600'
                    }`}
                  >
                    {isDone ? <Check className="w-3.5 h-3.5" /> : s.num}
                  </div>
                  <span className="text-xs font-montserrat font-bold truncate">
                    {s.title}
                  </span>
                </div>
                <p className={`text-[11px] truncate hidden sm:block font-inter ${isActive ? 'text-zinc-300' : 'text-zinc-500'}`}>
                  {s.subtitle}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* STEP 1: MARQUE -> MODÈLE -> PALETTES -> PANIER */}
      {/* ========================================================================= */}
      {step === 1 && (
        <div className="space-y-8 animate-fadeIn">
          {/* Brand & Model Selector Box */}
          <div className="bg-white border border-zinc-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div>
              <h2 className="text-lg font-montserrat font-bold text-zinc-950 mb-1 flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-zinc-100 text-zinc-900 text-xs flex items-center justify-center font-mono">1</span>
                Sélectionnez une Marque & un Modèle
              </h2>
              <p className="text-xs text-zinc-500 font-inter">
                Recherchez votre marque partenaire, choisissez un modèle en stock certifié neuf et déterminez le nombre de palettes (1 palette = 100 paires = 350 € HT).
              </p>
            </div>

            {/* 1. Recherche et sélection de marque */}
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-600 font-mono">
                  1. Rechercher / Choisir une marque ({filteredCatalogBrands.length} disponible{filteredCatalogBrands.length > 1 ? 's' : ''})
                </label>
                {brandSearchQuery && (
                  <button
                    onClick={() => setBrandSearchQuery('')}
                    className="text-[11px] text-zinc-500 hover:text-zinc-950 font-bold"
                  >
                    Effacer recherche
                  </button>
                )}
              </div>

              {/* Champ avec recherche */}
              <div className="relative max-w-md">
                <Search className="w-4 h-4 absolute left-3.5 top-3 text-zinc-400" />
                <input
                  type="text"
                  value={brandSearchQuery}
                  onChange={(e) => setBrandSearchQuery(e.target.value)}
                  placeholder="Rechercher une marque (Nike, Adidas, Jordan...)..."
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl pl-10 pr-8 py-2.5 text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-zinc-950 focus:bg-white font-medium"
                />
                {brandSearchQuery && (
                  <button
                    onClick={() => setBrandSearchQuery('')}
                    className="absolute right-3 top-2.5 text-zinc-400 hover:text-zinc-900"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Brand Selector Pills */}
              <div className="flex flex-wrap gap-2 pt-1">
                {filteredCatalogBrands.length === 0 ? (
                  <p className="text-xs text-zinc-400 italic py-1">
                    Aucune marque disponible correspondant à « {brandSearchQuery} ».
                  </p>
                ) : (
                  filteredCatalogBrands.map((brand) => {
                    const isSelected = selectedBrand.toLowerCase() === brand.name.toLowerCase();
                    return (
                      <button
                        key={brand.name}
                        type="button"
                        onClick={() => {
                          setSelectedBrand(brand.name);
                          if (brand.models.length > 0) {
                            setSelectedModel(brand.models[0].name);
                            setSelectedModelImage(brand.models[0].image);
                          }
                        }}
                        className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                          isSelected
                            ? 'bg-zinc-950 text-white shadow'
                            : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                        }`}
                      >
                        <span>{brand.name}</span>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                            isSelected ? 'bg-zinc-800 text-white' : 'bg-zinc-200 text-zinc-600'
                          }`}
                        >
                          {brand.models.length}
                        </span>
                      </button>
                    );
                  })
                )}
              </div>
            </div>

            {/* 2. Modèles disponibles de cette marque */}
            <div className="space-y-3 pt-4 border-t border-zinc-100">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-600 font-mono">
                  2. Modèles disponibles pour {selectedBrand} ({currentBrandModels.length})
                </label>
                <span className="text-[11px] text-zinc-500 font-mono">
                  Sélectionnez votre modèle
                </span>
              </div>

              {currentBrandModels.length === 0 ? (
                <div className="py-8 text-center text-zinc-500 text-xs bg-zinc-50 rounded-2xl border border-dashed border-zinc-200">
                  Aucun modèle disponible pour le moment pour cette marque.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {currentBrandModels.map((m) => {
                    const isSelected = selectedModel === m.name;
                    return (
                      <div
                        key={m.name}
                        onClick={() => {
                          setSelectedModel(m.name);
                          setSelectedModelImage(m.image);
                        }}
                        className={`cursor-pointer rounded-2xl border p-3.5 transition-all flex flex-col justify-between ${
                          isSelected
                            ? 'border-zinc-950 ring-2 ring-zinc-950 bg-zinc-50/70 shadow-sm'
                            : 'border-zinc-200 hover:border-zinc-400 bg-white'
                        }`}
                      >
                        <div className="relative aspect-video rounded-xl overflow-hidden mb-3 bg-zinc-100">
                          <img
                            src={m.image}
                            alt={m.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <span className="absolute top-2 left-2 bg-zinc-950/80 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-0.5 rounded-md">
                            {m.tag}
                          </span>
                        </div>

                        <div>
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-mono text-zinc-400 uppercase">
                              {selectedBrand}
                            </span>
                            <span className="text-[11px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                              350 € / pal.
                            </span>
                          </div>
                          <h3 className="font-montserrat font-bold text-sm text-zinc-950 mt-0.5 line-clamp-1">
                            {m.name}
                          </h3>
                          <p className="text-[11px] text-zinc-500 font-inter mt-1">
                            Lot standard : 100 paires (tailles 36 à 46)
                          </p>
                        </div>

                        <div className="mt-3 pt-3 border-t border-zinc-100 flex items-center justify-between text-xs">
                          <span className="text-zinc-500 text-[11px]">
                            {isSelected ? '✓ Modèle sélectionné' : 'Cliquer pour choisir'}
                          </span>
                          <div
                            className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                              isSelected
                                ? 'bg-zinc-950 border-zinc-950 text-white'
                                : 'border-zinc-300'
                            }`}
                          >
                            {isSelected && <Check className="w-2.5 h-2.5" />}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* 3. Choix du nombre de palettes & Ajout au Panier */}
            <div className="bg-zinc-50 rounded-2xl p-4 sm:p-5 border border-zinc-200 flex flex-col sm:flex-row items-center justify-between gap-4 pt-4">
              <div className="text-left w-full sm:w-auto">
                <span className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-wider block">
                  3. Modèle confirmé & Nombre de palettes
                </span>
                <p className="text-sm font-montserrat font-bold text-zinc-950">
                  {selectedBrand} — {selectedModel}
                </p>
                <p className="text-xs text-zinc-600 font-inter">
                  Conditionnement : 1 palette = 100 paires = 350 € HT
                </p>
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                <div className="flex items-center bg-white border border-zinc-300 rounded-xl p-1 shadow-sm">
                  <button
                    type="button"
                    onClick={() => setQuantityInput(Math.max(1, quantityInput - 1))}
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-zinc-600 hover:bg-zinc-100"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-16 text-center font-mono font-bold text-sm text-zinc-950">
                    {quantityInput} pal.
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantityInput(quantityInput + 1)}
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-zinc-600 hover:bg-zinc-100"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleAddToCart}
                  className="px-5 py-2.5 rounded-xl bg-zinc-950 text-white font-montserrat font-bold text-xs hover:bg-zinc-800 transition-colors flex items-center gap-2 shadow"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Ajouter au panier</span>
                </button>
              </div>
            </div>
          </div>

          {/* ACTIVE CART SUMMARY */}
          <div className="bg-white border border-zinc-200 rounded-3xl p-6 sm:p-8 shadow-sm">
            <div className="flex items-center justify-between mb-4 pb-4 border-b border-zinc-100">
              <div>
                <h3 className="text-lg font-montserrat font-bold text-zinc-950 flex items-center gap-2">
                  <Package className="w-5 h-5 text-amber-500" />
                  <span>Votre Panier de Palettes ({totalPallets} palette{totalPallets > 1 ? 's' : ''})</span>
                </h3>
                <p className="text-xs text-zinc-500 font-inter">
                  Total : {totalPairs} paires de chaussures prêtes pour expédition
                </p>
              </div>

              <div className="text-right">
                <span className="text-xs text-zinc-500 block font-inter">Sous-total Marchandises</span>
                <span className="text-xl font-montserrat font-extrabold text-zinc-950">
                  {merchandiseSubtotal.toFixed(2)} €
                </span>
              </div>
            </div>

            {/* Cart Table List */}
            <div className="divide-y divide-zinc-100">
              {cart.map((item) => (
                <div key={item.id} className="py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={item.photo}
                      alt={item.model}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-xl object-cover border border-zinc-200"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono font-bold uppercase text-zinc-400">
                          {item.brand}
                        </span>
                        <span className="text-[10px] bg-zinc-100 text-zinc-700 font-bold px-1.5 py-0.5 rounded">
                          {item.palletCount * 100} paires
                        </span>
                      </div>
                      <h4 className="font-montserrat font-bold text-sm text-zinc-950">
                        {item.model}
                      </h4>
                      <p className="text-xs text-zinc-500 font-inter">
                        {item.palletCount} × 350.00 € = {(item.palletCount * 350).toFixed(2)} €
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                    {/* Quantity modifier */}
                    <div className="flex items-center bg-zinc-50 border border-zinc-200 rounded-xl p-1">
                      <button
                        type="button"
                        onClick={() => handleUpdateCartItemQty(item.id, item.palletCount - 1)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-zinc-500 hover:bg-zinc-200"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-10 text-center font-mono font-bold text-xs text-zinc-900">
                        {item.palletCount}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleUpdateCartItemQty(item.id, item.palletCount + 1)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-zinc-500 hover:bg-zinc-200"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="font-montserrat font-bold text-sm text-zinc-950 w-20 text-right">
                      {item.subtotal.toFixed(2)} €
                    </span>

                    <button
                      type="button"
                      onClick={() => handleRemoveCartItem(item.id)}
                      className="p-2 text-zinc-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                      title="Supprimer du panier"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Cart Footer */}
            <div className="mt-8 pt-6 border-t border-zinc-200 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-zinc-500 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Tarif garanti H DESTOCKAGE • Facture pro forma immédiate</span>
              </div>

              <button
                type="button"
                onClick={() => setStep(2)}
                className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-zinc-950 hover:bg-zinc-800 text-white font-montserrat font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md group"
              >
                <span>Continuer vers les coordonnées & la livraison</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* STEP 2: INFORMATIONS CLIENT -> GOOGLE MAPS -> CALCUL LIVRAISON */}
      {/* ========================================================================= */}
      {step === 2 && (
        <div className="bg-white border border-zinc-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-8 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-zinc-100 pb-4">
            <div>
              <h2 className="text-lg font-montserrat font-bold text-zinc-950 flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-zinc-100 text-zinc-900 text-xs flex items-center justify-center font-mono">2</span>
                Coordonnées du Client & Adresse de Livraison
              </h2>
              <p className="text-xs text-zinc-500 font-inter">
                Intégration Google Maps officielle pour le calcul automatique de l'itinéraire depuis Aulnay-sous-Bois (93600).
              </p>
            </div>
            <button
              type="button"
              onClick={() => setStep(1)}
              className="text-xs font-montserrat font-bold text-zinc-500 hover:text-zinc-900 flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Modifier le panier</span>
            </button>
          </div>

          {/* Form Fields Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Prénom */}
            <div>
              <label className="block text-xs font-montserrat font-bold text-zinc-700 mb-1">
                Prénom du client / destinataire *
              </label>
              <input
                type="text"
                value={customer.firstName}
                onChange={(e) => setCustomer({ ...customer, firstName: e.target.value })}
                placeholder="Ex: Alexandre"
                className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 font-inter focus:bg-white focus:border-zinc-950 ${
                  errors.firstName ? 'border-red-500' : 'border-zinc-300'
                }`}
              />
              {errors.firstName && (
                <span className="text-[10px] text-red-500 font-bold block mt-1">{errors.firstName}</span>
              )}
            </div>

            {/* Nom */}
            <div>
              <label className="block text-xs font-montserrat font-bold text-zinc-700 mb-1">
                Nom de famille *
              </label>
              <input
                type="text"
                value={customer.lastName}
                onChange={(e) => setCustomer({ ...customer, lastName: e.target.value })}
                placeholder="Ex: Dupont"
                className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 font-inter focus:bg-white focus:border-zinc-950 ${
                  errors.lastName ? 'border-red-500' : 'border-zinc-300'
                }`}
              />
              {errors.lastName && (
                <span className="text-[10px] text-red-500 font-bold block mt-1">{errors.lastName}</span>
              )}
            </div>

            {/* Téléphone */}
            <div>
              <label className="block text-xs font-montserrat font-bold text-zinc-700 mb-1">
                Téléphone portable (appel livreur) *
              </label>
              <input
                type="tel"
                value={customer.phone}
                onChange={(e) => setCustomer({ ...customer, phone: e.target.value, whatsapp: customer.whatsapp || e.target.value })}
                placeholder="Ex: 06 12 34 56 78"
                className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 font-inter focus:bg-white focus:border-zinc-950 ${
                  errors.phone ? 'border-red-500' : 'border-zinc-300'
                }`}
              />
              {errors.phone && (
                <span className="text-[10px] text-red-500 font-bold block mt-1">{errors.phone}</span>
              )}
            </div>

            {/* WhatsApp */}
            <div>
              <label className="block text-xs font-montserrat font-bold text-zinc-700 mb-1">
                Numéro WhatsApp client (pour suivi en direct)
              </label>
              <input
                type="tel"
                value={customer.whatsapp}
                onChange={(e) => setCustomer({ ...customer, whatsapp: e.target.value })}
                placeholder="Ex: +33 6 12 34 56 78"
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 font-inter focus:bg-white focus:border-zinc-950"
              />
            </div>

            {/* E-mail */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-montserrat font-bold text-zinc-700 mb-1">
                Adresse e-mail (Réception immédiate de la Facture Pro Forma PDF) *
              </label>
              <input
                type="email"
                value={customer.email}
                onChange={(e) => setCustomer({ ...customer, email: e.target.value })}
                placeholder="Ex: client@entreprise.fr"
                className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 font-inter focus:bg-white focus:border-zinc-950 ${
                  errors.email ? 'border-red-500' : 'border-zinc-300'
                }`}
              />
              {errors.email && (
                <span className="text-[10px] text-red-500 font-bold block mt-1">{errors.email}</span>
              )}
            </div>

            {/* Société éventuelle */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-montserrat font-bold text-zinc-700 mb-1">
                Nom d'entreprise / Société (Facultatif - Particuliers et Professionnels acceptés)
              </label>
              <input
                type="text"
                value={customer.company || ''}
                onChange={(e) => setCustomer({ ...customer, company: e.target.value })}
                placeholder="Ex: SAS Sneaker Resell (ou laissez vide si particulier)"
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 font-inter focus:bg-white focus:border-zinc-950"
              />
            </div>

            {/* GOOGLE MAPS ADDRESS INPUT */}
            <div className="sm:col-span-2 pt-2">
              <label className="block text-xs font-montserrat font-bold text-zinc-900 mb-1 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-red-500" />
                  Adresse de livraison (Recherche automatique Google Maps) *
                </span>
                <span className="text-[11px] text-zinc-500 font-normal font-inter">
                  Entrez votre adresse ou cliquez sur l'icône de géolocalisation
                </span>
              </label>
              <GoogleMapsAddressInput
                value={customer.deliveryAddress}
                postalCode={customer.postalCode}
                city={customer.city}
                onChange={(val) => setCustomer({ ...customer, deliveryAddress: val })}
                onAddressSelect={handleAddressSelect}
                hasError={Boolean(errors.deliveryAddress)}
                errorMessage={errors.deliveryAddress}
              />
            </div>

            {/* Code Postal */}
            <div>
              <label className="block text-xs font-montserrat font-bold text-zinc-700 mb-1">
                Code postal *
              </label>
              <input
                type="text"
                value={customer.postalCode}
                onChange={(e) => setCustomer({ ...customer, postalCode: e.target.value })}
                placeholder="Ex: 75008"
                className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 font-inter focus:bg-white focus:border-zinc-950 ${
                  errors.postalCode ? 'border-red-500' : 'border-zinc-300'
                }`}
              />
              {errors.postalCode && (
                <span className="text-[10px] text-red-500 font-bold block mt-1">{errors.postalCode}</span>
              )}
            </div>

            {/* Ville */}
            <div>
              <label className="block text-xs font-montserrat font-bold text-zinc-700 mb-1">
                Ville *
              </label>
              <input
                type="text"
                value={customer.city}
                onChange={(e) => setCustomer({ ...customer, city: e.target.value })}
                placeholder="Ex: Paris"
                className={`w-full bg-zinc-50 border rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 font-inter focus:bg-white focus:border-zinc-950 ${
                  errors.city ? 'border-red-500' : 'border-zinc-300'
                }`}
              />
              {errors.city && (
                <span className="text-[10px] text-red-500 font-bold block mt-1">{errors.city}</span>
              )}
            </div>
          </div>

          {/* REAL-TIME SHIPPING CALCULATION PANEL */}
          <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-zinc-900" />
                <span className="text-xs font-montserrat font-bold text-zinc-950 uppercase tracking-wider">
                  Calcul du transport routier Google Maps
                </span>
              </div>
              {isCalculatingShipping ? (
                <div className="flex items-center gap-1.5 text-xs text-zinc-500">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Calcul d'itinéraire en cours...</span>
                </div>
              ) : (
                <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  Départ : 26-36 rue Alfred Nobel, 93600 Aulnay-sous-Bois
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs font-inter">
              <div className="bg-white p-3 rounded-xl border border-zinc-200">
                <span className="text-[10px] text-zinc-400 uppercase font-mono block">Distance calculée</span>
                <span className="font-montserrat font-bold text-zinc-900 text-sm">
                  {shippingResult?.distance_routiere_km
                    ? `${shippingResult.distance_routiere_km} km`
                    : 'En attente d\'adresse'}
                </span>
                <span className="text-[10px] text-zinc-500 block mt-0.5">
                  Itinéraire poids lourd direct
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-zinc-200">
                <span className="text-[10px] text-zinc-400 uppercase font-mono block">Forfait de base</span>
                <span className="font-montserrat font-bold text-zinc-900 text-sm">
                  106.00 €
                </span>
                <span className="text-[10px] text-zinc-500 block mt-0.5">
                  France métropolitaine
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-zinc-200">
                <span className="text-[10px] text-zinc-400 uppercase font-mono block">Frais de livraison total</span>
                <span className="font-montserrat font-bold text-zinc-950 text-sm">
                  {deliveryFee !== null ? `${deliveryFee.toFixed(2)} €` : 'Devis requis'}
                </span>
                {deliverySupplement > 0 && (
                  <span className="text-[10px] text-amber-600 block mt-0.5 font-bold">
                    Dont {deliverySupplement.toFixed(2)} € de supplément distance
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-zinc-200">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="px-5 py-3 rounded-xl border border-zinc-300 text-zinc-700 font-montserrat font-bold text-xs hover:bg-zinc-100 flex items-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Retour au panier</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (validateStep2()) {
                  setStep(3);
                }
              }}
              className="px-8 py-3.5 rounded-2xl bg-zinc-950 hover:bg-zinc-800 text-white font-montserrat font-bold text-sm flex items-center gap-2 shadow-md group"
            >
              <span>Vérifier le récapitulatif</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* STEP 3: RÉCAPITULATIF & VALIDATION AVANT COMMANDE */}
      {/* ========================================================================= */}
      {step === 3 && (
        <div className="bg-white border border-zinc-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-8 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-zinc-100 pb-4">
            <div>
              <h2 className="text-lg font-montserrat font-bold text-zinc-950 flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-zinc-100 text-zinc-900 text-xs flex items-center justify-center font-mono">3</span>
                Récapitulatif de la Commande
              </h2>
              <p className="text-xs text-zinc-500 font-inter">
                Vérifiez attentivement les détails des palettes, l'adresse et le décompte financier avant création.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setStep(2)}
              className="text-xs font-montserrat font-bold text-zinc-500 hover:text-zinc-900 flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Modifier les coordonnées</span>
            </button>
          </div>

          {/* Items Summary */}
          <div className="bg-zinc-50 rounded-2xl p-5 border border-zinc-200">
            <h3 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-wider mb-3">
              Articles & Palettes commandées ({totalPallets} palette{totalPallets > 1 ? 's' : ''} — {totalPairs} paires)
            </h3>
            <div className="divide-y divide-zinc-200/60">
              {cart.map((item) => (
                <div key={item.id} className="py-2.5 flex items-center justify-between text-xs font-inter">
                  <div className="flex items-center gap-2.5">
                    <img src={item.photo} alt={item.model} referrerPolicy="no-referrer" className="w-10 h-10 rounded-lg object-cover border" />
                    <div>
                      <span className="font-montserrat font-bold text-zinc-950 block">
                        {item.brand} — {item.model}
                      </span>
                      <span className="text-[11px] text-zinc-500">
                        {item.palletCount} palette(s) • {item.palletCount * 100} paires neuves
                      </span>
                    </div>
                  </div>
                  <span className="font-montserrat font-bold text-zinc-900">
                    {item.subtotal.toFixed(2)} €
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery & Client Coordinates Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-inter">
            <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-200">
              <span className="text-[10px] font-mono font-bold uppercase text-zinc-400 block mb-1">
                Destinataire & Contact
              </span>
              <p className="font-montserrat font-bold text-zinc-950 text-sm">
                {customer.firstName} {customer.lastName}
              </p>
              {customer.company && (
                <p className="text-zinc-600 font-medium">{customer.company}</p>
              )}
              <p className="text-zinc-600 mt-1">Tél : {customer.phone}</p>
              <p className="text-zinc-600">E-mail : {customer.email}</p>
            </div>

            <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-200">
              <span className="text-[10px] font-mono font-bold uppercase text-zinc-400 block mb-1">
                Lieu de livraison
              </span>
              <p className="font-montserrat font-bold text-zinc-950 text-sm">
                {customer.deliveryAddress}
              </p>
              <p className="text-zinc-600">
                {customer.postalCode} {customer.city}
              </p>
              <p className="text-zinc-500 text-[11px] mt-1">
                Distance routière : {shippingResult?.distance_routiere_km || '220'} km depuis Aulnay-sous-Bois
              </p>
            </div>
          </div>

          {/* Financial Breakdown with Prominent Dual Split Blocks */}
          <div className="border border-zinc-200 rounded-2xl p-5 bg-white space-y-4">
            <h3 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-wider">
              Décompte Financier & Modalités de Règlement
            </h3>

            <div className="space-y-2 text-xs font-inter">
              <div className="flex justify-between text-zinc-600">
                <span>Montant des marchandises ({totalPallets} palette{totalPallets > 1 ? 's' : ''}) :</span>
                <span className="font-montserrat font-bold text-zinc-900">{merchandiseSubtotal.toFixed(2)} €</span>
              </div>
              <div className="flex justify-between text-zinc-600">
                <span>Frais de livraison (Forfait de base) :</span>
                <span className="font-montserrat font-bold text-zinc-900">{baseDeliveryFee.toFixed(2)} €</span>
              </div>
              {deliverySupplement > 0 && (
                <div className="flex justify-between text-zinc-600">
                  <span>Supplément distance d'acheminement :</span>
                  <span className="font-montserrat font-bold text-amber-600">{deliverySupplement.toFixed(2)} €</span>
                </div>
              )}
              <div className="pt-3 border-t flex justify-between text-base font-montserrat font-extrabold text-zinc-950">
                <span>MONTANT TOTAL DÛ :</span>
                <span className="text-lg text-amber-900">{totalAmount.toFixed(2)} €</span>
              </div>
            </div>
          </div>

          {/* Consent Checkbox */}
          <div className="pt-2">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={consentAccepted}
                onChange={(e) => setConsentAccepted(e.target.checked)}
                className="mt-1 w-4 h-4 rounded border-zinc-300 text-zinc-950 focus:ring-zinc-950"
              />
              <span className="text-xs text-zinc-700 font-inter">
                Je confirme l'exactitude de mes informations et j'accepte les conditions de vente et de livraison de <strong>H DESTOCKAGE</strong>. Je comprends que la commande sera enregistrée sous le statut <em>« En attente de paiement »</em> et finalisée en direct sur WhatsApp.
              </span>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-zinc-200">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="px-5 py-3 rounded-xl border border-zinc-300 text-zinc-700 font-montserrat font-bold text-xs hover:bg-zinc-100 flex items-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Retour aux coordonnées</span>
            </button>

            <button
              type="button"
              disabled={!consentAccepted}
              onClick={handleConfirmAndCreateOrder}
              className="px-8 py-3.5 rounded-2xl bg-zinc-950 hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-montserrat font-bold text-sm flex items-center gap-2 shadow-lg transition-all"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Valider et créer ma commande</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* STEP 4: COMMANDE CRÉÉE, FACTURE PRO FORMA PDF, E-MAIL & WHATSAPP */}
      {/* ========================================================================= */}
      {step === 4 && createdOrder && (
        <div className="bg-white border border-zinc-200 rounded-3xl p-6 sm:p-10 shadow-sm space-y-8 animate-fadeIn">
          {/* SUCCESS BANNER */}
          <div className="text-center pb-6 border-b border-zinc-100">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <span className="inline-block px-3 py-1 rounded-full bg-zinc-100 text-zinc-800 text-xs font-mono font-bold uppercase mb-2">
              Statut : En attente de paiement
            </span>

            <h2 className="text-2xl sm:text-3xl font-montserrat font-extrabold text-zinc-950 tracking-tight">
              Commande N° {createdOrder.id} enregistrée !
            </h2>

            {/* MANDATORY PROMPT NOTIFICATION MESSAGE */}
            <div className="mt-4 p-4 rounded-2xl bg-zinc-50 border border-zinc-200 max-w-2xl mx-auto">
              <p className="text-sm font-inter text-zinc-900 font-medium">
                « Votre commande a été enregistrée et votre facture pro forma vous a été envoyée par e-mail. Finalisez maintenant votre commande sur WhatsApp. »
              </p>
              <div className="mt-2 text-xs text-zinc-500 flex items-center justify-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-zinc-400" />
                <span>Copie transmise à : <strong>{createdOrder.customer.email}</strong></span>
              </div>
            </div>
          </div>

          {/* TWO PRIMARY CALL-TO-ACTIONS: WHATSAPP & DOWNLOAD PDF */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* WHATSAPP FINALIZATION (PRIMARY MANDATORY ACTION) */}
            <a
              href={formattedWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white flex flex-col justify-between transition-all shadow-lg group"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
                    <MessageCircle className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-mono font-bold uppercase bg-white/20 px-2 py-0.5 rounded-full">
                    Étape Finale Requise
                  </span>
                </div>
                <h3 className="text-lg font-montserrat font-bold text-white mb-1">
                  Finaliser ma commande sur WhatsApp
                </h3>
                <p className="text-xs text-emerald-100 font-inter">
                  Message pré-rempli avec votre numéro {createdOrder.id}, palettes et coordonnées. H DESTOCKAGE vous transmettra les détails de règlement.
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-emerald-500/50 flex items-center justify-between font-montserrat text-xs font-bold">
                <span>Ouvrir WhatsApp</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </a>

            {/* DOWNLOAD PRO FORMA PDF (MANDATORY REQUIREMENT) */}
            <button
              type="button"
              onClick={() => generateOrderPdf(createdOrder, bankDetails, config, false)}
              className="p-6 rounded-2xl bg-zinc-950 hover:bg-zinc-800 text-white flex flex-col justify-between transition-all shadow-lg group text-left"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-400 text-zinc-950 flex items-center justify-center">
                    <Download className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-mono font-bold uppercase bg-white/10 px-2 py-0.5 rounded-full text-amber-300">
                    Format A4 Officiel
                  </span>
                </div>
                <h3 className="text-lg font-montserrat font-bold text-white mb-1">
                  Télécharger la facture pro forma (PDF)
                </h3>
                <p className="text-xs text-zinc-400 font-inter">
                  Véritable document vectoriel avec logo H DESTOCKAGE, cachet circulaire, signature électronique et décompte des paiements.
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between font-montserrat text-xs font-bold text-amber-300">
                <span>Téléchargement immédiat du PDF</span>
                <Download className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
              </div>
            </button>
          </div>

          {/* ORDER DETAILS SUMMARY CARD */}
          <div className="border border-zinc-200 rounded-2xl p-6 bg-zinc-50 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-zinc-200 gap-2">
              <div>
                <span className="text-xs font-mono font-bold text-zinc-400 uppercase">Référence Commande</span>
                <p className="text-lg font-montserrat font-bold text-zinc-950 flex items-center gap-2">
                  <span>{createdOrder.id}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(createdOrder.id, 'id')}
                    className="p-1 hover:bg-zinc-200 rounded text-zinc-500"
                    title="Copier le numéro"
                  >
                    {copiedField === 'id' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </p>
              </div>

              <div className="text-left sm:text-right">
                <span className="text-xs font-mono font-bold text-zinc-400 uppercase">Montant Total</span>
                <p className="text-lg font-montserrat font-bold text-zinc-950">
                  {createdOrder.totalAmount.toFixed(2)} €
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-inter pt-2">
              <div>
                <span className="text-zinc-500 block">Articles commandés :</span>
                <span className="font-bold text-zinc-900">
                  {createdOrder.palletCount} palette(s) ({createdOrder.totalPairs} paires) • {createdOrder.brand} {createdOrder.model}
                </span>
              </div>

              <div>
                <span className="text-zinc-500 block">Adresse de livraison :</span>
                <span className="font-bold text-zinc-900">
                  {createdOrder.customer.deliveryAddress}, {createdOrder.customer.postalCode} {createdOrder.customer.city}
                </span>
              </div>

              <div>
                <span className="text-zinc-500 block">Frais de livraison :</span>
                <span className="font-bold text-zinc-900">
                  {(createdOrder.deliveryFee ?? 106).toFixed(2)} €
                </span>
              </div>

              <div>
                <span className="text-zinc-500 block">Montant des marchandises :</span>
                <span className="font-bold text-zinc-900">
                  {createdOrder.merchandiseSubtotal.toFixed(2)} €
                </span>
              </div>
            </div>
          </div>

          {/* NEXT STEPS NOTICE */}
          <div className="p-5 rounded-2xl bg-zinc-900 text-white flex items-start gap-4">
            <Info className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="text-xs font-inter space-y-1">
              <p className="font-montserrat font-bold text-amber-300">
                Procédure de validation H DESTOCKAGE :
              </p>
              <p className="text-zinc-300">
                1. Cliquez sur le bouton vert <strong>« Finaliser ma commande sur WhatsApp »</strong> pour contacter notre service commercial.
              </p>
              <p className="text-zinc-300">
                2. Les coordonnées de règlement (virement bancaire ou dépôt sécurisé) vous seront confirmées directement par H DESTOCKAGE.
              </p>
              <p className="text-zinc-300">
                3. Après transmission de votre justificatif sur ce même WhatsApp, le statut passera à <em>« Paiement en cours de vérification »</em> puis <em>« Paiement confirmé »</em> pour affrètement transporteur.
              </p>
            </div>
          </div>

          {/* Back / New Order Action */}
          <div className="pt-4 flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                setStep(1);
                setCreatedOrder(null);
                setConsentAccepted(false);
              }}
              className="text-xs font-montserrat font-bold text-zinc-600 hover:text-zinc-950 flex items-center gap-1.5"
            >
              <Package className="w-3.5 h-3.5" />
              <span>Passer une autre commande de palettes</span>
            </button>

            {onNavigateTab && (
              <button
                type="button"
                onClick={() => onNavigateTab('tracking')}
                className="text-xs font-montserrat font-bold text-zinc-950 underline flex items-center gap-1"
              >
                <span>Accéder au suivi en direct de vos commandes</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
