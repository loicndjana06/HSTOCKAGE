export interface SuggestedModel {
  brand: string;
  name: string;
  category?: string;
  descriptionSnippet?: string;
}

export const SUGGESTED_MODELS_PRESETS: SuggestedModel[] = [
  // NIKE
  { brand: 'Nike', name: 'Air Force 1', descriptionSnippet: 'Le classique basique indispensable pour revendeurs.' },
  { brand: 'Nike', name: 'Air Max 1', descriptionSnippet: 'Silhouette mythique d\'amorti Air.' },
  { brand: 'Nike', name: 'Air Max 90', descriptionSnippet: 'L\'icône des années 90 à forte rotation.' },
  { brand: 'Nike', name: 'Air Max 95', descriptionSnippet: 'Anatomie humaine & bulles d\'air visibles.' },
  { brand: 'Nike', name: 'Air Max 97', descriptionSnippet: 'Inspiration train à grande vitesse japonais.' },
  { brand: 'Nike', name: 'Air Max Plus / TN', descriptionSnippet: 'Silhouette agressive streetwear incontournable.' },
  { brand: 'Nike', name: 'Dunk Low', descriptionSnippet: 'Baskets skate & lifestyle à très forte demande.' },
  { brand: 'Nike', name: 'Dunk High', descriptionSnippet: 'Version montante rétro incontournable.' },
  { brand: 'Nike', name: 'Vomero', descriptionSnippet: 'Tech-runner rétro ultra confortable.' },
  { brand: 'Nike', name: 'P-6000', descriptionSnippet: 'Inspiration running des années 2000.' },

  // JORDAN
  { brand: 'Jordan', name: 'Air Jordan 1', descriptionSnippet: 'Le modèle originel de 1985.' },
  { brand: 'Jordan', name: 'Air Jordan 1 Low', descriptionSnippet: 'Version basse à très forte rotation.' },
  { brand: 'Jordan', name: 'Air Jordan 1 Mid', descriptionSnippet: 'Hauteur intermédiaire populaire.' },
  { brand: 'Jordan', name: 'Air Jordan 3', descriptionSnippet: 'Imprimé éléphant signature de Tinker Hatfield.' },
  { brand: 'Jordan', name: 'Air Jordan 4', descriptionSnippet: 'La star absolue du marché sneaker actuel.' },
  { brand: 'Jordan', name: 'Air Jordan 5', descriptionSnippet: 'Inspiration avions de chasse avec semelle translucide.' },
  { brand: 'Jordan', name: 'Air Jordan 6', descriptionSnippet: 'Premier titre NBA de Michael Jordan.' },
  { brand: 'Jordan', name: 'Air Jordan 11', descriptionSnippet: 'Cuir verni emblématique et plaque en fibre de carbone.' },
  { brand: 'Jordan', name: 'Jordan 4 RM', descriptionSnippet: 'Reinvented Modernized Jordan 4 low.' },

  // ADIDAS
  { brand: 'Adidas', name: 'Samba', descriptionSnippet: 'Le phénomène rétro incontournable.' },
  { brand: 'Adidas', name: 'Gazelle', descriptionSnippet: 'Tige en suède iconique lifestyle.' },
  { brand: 'Adidas', name: 'Campus', descriptionSnippet: 'Silhouette oversize 00s très demandée.' },
  { brand: 'Adidas', name: 'Handball Spezial', descriptionSnippet: 'Classique terrace culture en suède.' },
  { brand: 'Adidas', name: 'SL 72', descriptionSnippet: 'Modèle léger rétro running 1972.' },
  { brand: 'Adidas', name: 'Tokyo', descriptionSnippet: 'Style minimaliste rétro profilé.' },
  { brand: 'Adidas', name: 'Superstar', descriptionSnippet: 'Shell-toe iconique hip-hop.' },
  { brand: 'Adidas', name: 'Forum', descriptionSnippet: 'Basket basketball rétro à sangle.' },

  // NEW BALANCE
  { brand: 'New Balance', name: '530', descriptionSnippet: 'La référence retro running dad-shoe.' },
  { brand: 'New Balance', name: '550', descriptionSnippet: 'Basketball vintage très prisé.' },
  { brand: 'New Balance', name: '574', descriptionSnippet: 'Le classique indémodable multiterrain.' },
  { brand: 'New Balance', name: '9060', descriptionSnippet: 'Design futuriste à semelle sculptée.' },
  { brand: 'New Balance', name: '2002R', descriptionSnippet: 'Confort Premium N-ergy.' },
  { brand: 'New Balance', name: '1906R', descriptionSnippet: 'Tech-runner rétro mesh & TPU.' },
  { brand: 'New Balance', name: '990', descriptionSnippet: 'Série Made in USA haut de gamme.' },
  { brand: 'New Balance', name: '991', descriptionSnippet: 'Fabrication Flimby Angleterre.' },
  { brand: 'New Balance', name: '992', descriptionSnippet: 'Craftsmanship d\'exception.' },

  // ASICS
  { brand: 'Asics', name: 'GEL-Kayano 14', descriptionSnippet: 'Tendance runner Y2K par excellence.' },
  { brand: 'Asics', name: 'GEL-1130', descriptionSnippet: 'Design fluide fin 2000s.' },
  { brand: 'Asics', name: 'GEL-NYC', descriptionSnippet: 'Hybrid moderne & vintage.' },
  { brand: 'Asics', name: 'GEL-Nimbus', descriptionSnippet: 'Amorti moelleux maximaliste.' },
  { brand: 'Asics', name: 'GEL-Quantum', descriptionSnippet: 'GEL à 360 degrés style streetwear.' },

  // SAUCONY
  { brand: 'Saucony', name: '2000', descriptionSnippet: 'Heritage ProGrid Y2K.' },
  { brand: 'Saucony', name: '5000', descriptionSnippet: 'Shadow 5000 silhouette rétro.' },
  { brand: 'Saucony', name: '6000', descriptionSnippet: 'Running rétro premium suede.' },
  { brand: 'Saucony', name: 'Shadow', descriptionSnippet: 'Modèle classique de légende.' },
  { brand: 'Saucony', name: 'Jazz', descriptionSnippet: 'Basic running iconique.' },

  // PUMA
  { brand: 'Puma', name: 'Palermo', descriptionSnippet: 'Terrace culture classique italiens.' },
  { brand: 'Puma', name: 'Suede', descriptionSnippet: 'Modèle suède emblématique.' },
  { brand: 'Puma', name: 'Speedcat', descriptionSnippet: 'Inspiration sport automobile profilée.' },
  { brand: 'Puma', name: 'Easy Rider', descriptionSnippet: 'Heritage running 1970s.' },
  { brand: 'Puma', name: 'RS-X', descriptionSnippet: 'Design volumineux chunky.' },

  // AUTRES
  { brand: 'Autres modèles', name: 'Autre référence custom', descriptionSnippet: 'Création libre pour tout autre modèle.' },
];
