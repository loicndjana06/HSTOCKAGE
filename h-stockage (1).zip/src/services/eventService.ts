import {
  ActivityEvent,
  ActivityEventType,
  AdminNotification,
  AdminSettings,
} from '../types';

const KEYS = {
  EVENTS: 'destock34_events_v1',
  NOTIFICATIONS: 'destock34_notifications_v1',
  SETTINGS: 'destock34_settings_v1',
};

export const DEFAULT_ADMIN_SETTINGS: AdminSettings = {
  companyName: 'H DESTOCKAGE',
  logoUrl: '',
  whatsappNumber: '33758521191',
  contactEmail: 'contact@h-destockage.fr',
  presentationText: 'Plateforme grossiste B2B officielle réservée aux professionnels et revendeurs de sneakers neuves en gros.',
  isProductionMode: false,
};

// --- EVENTS ---
export function getStoredEvents(): ActivityEvent[] {
  try {
    const data = localStorage.getItem(KEYS.EVENTS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveEvents(events: ActivityEvent[]): void {
  localStorage.setItem(KEYS.EVENTS, JSON.stringify(events));
}

export function logEvent(
  eventType: ActivityEventType,
  details: string,
  extra?: {
    clientId?: string;
    clientEmail?: string;
    clientName?: string;
    productId?: string;
    productName?: string;
  }
): ActivityEvent {
  const events = getStoredEvents();
  const now = new Date();
  const formattedTimestamp = now.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const newEvent: ActivityEvent = {
    id: `evt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: formattedTimestamp,
    eventType,
    details,
    clientId: extra?.clientId,
    clientEmail: extra?.clientEmail,
    clientName: extra?.clientName,
    productId: extra?.productId,
    productName: extra?.productName,
  };

  const updated = [newEvent, ...events].slice(0, 500); // keep max 500 logs
  saveEvents(updated);
  return newEvent;
}

export function clearEvents(): void {
  localStorage.removeItem(KEYS.EVENTS);
}

// --- NOTIFICATIONS ---
export function getStoredNotifications(): AdminNotification[] {
  try {
    const data = localStorage.getItem(KEYS.NOTIFICATIONS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveNotifications(notifs: AdminNotification[]): void {
  localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify(notifs));
}

export function addNotification(
  notifData: Omit<AdminNotification, 'id' | 'timestamp' | 'read'>
): AdminNotification {
  const notifs = getStoredNotifications();
  const now = new Date();
  const formattedTimestamp = now.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });

  const newNotif: AdminNotification = {
    ...notifData,
    id: `notif-${Date.now()}`,
    timestamp: formattedTimestamp,
    read: false,
  };

  const updated = [newNotif, ...notifs];
  saveNotifications(updated);
  return newNotif;
}

export function markNotificationRead(id: string): void {
  const notifs = getStoredNotifications();
  const updated = notifs.map((n) => (n.id === id ? { ...n, read: true } : n));
  saveNotifications(updated);
}

export function markAllNotificationsRead(): void {
  const notifs = getStoredNotifications();
  const updated = notifs.map((n) => ({ ...n, read: true }));
  saveNotifications(updated);
}

export function deleteNotification(id: string): void {
  const notifs = getStoredNotifications();
  const updated = notifs.filter((n) => n.id !== id);
  saveNotifications(updated);
}

export function clearNotifications(): void {
  saveNotifications([]);
}

// --- SETTINGS ---
export function getStoredSettings(): AdminSettings {
  try {
    const data = localStorage.getItem(KEYS.SETTINGS);
    return data ? { ...DEFAULT_ADMIN_SETTINGS, ...JSON.parse(data) } : DEFAULT_ADMIN_SETTINGS;
  } catch {
    return DEFAULT_ADMIN_SETTINGS;
  }
}

export function saveSettings(settings: AdminSettings): void {
  localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
}
