import {
  PalletOrder,
  PalletOrderCustomer,
  PalletCartItem,
  PalletComposition,
  ShippingConfig,
  BankPaymentDetails,
  PaymentProof,
  OrderStatus,
  OrderNotificationLog,
  CalculLivraisonResultat,
} from '../types';
import { db } from './firebase';
import { doc, setDoc, getDoc, collection, getDocs } from 'firebase/firestore';
import {
  DEFAULT_SHIPPING_CONFIG,
  calculer_frais_livraison,
  calculer_frais_livraison_synchrone,
  CONSTANTE_TARIF_MINIMUM_DEFAUT,
} from './shippingRouteCalculator';

export { DEFAULT_SHIPPING_CONFIG };

const STORAGE_KEYS = {
  ORDERS: 'destock34_pallet_orders_v1',
  SHIPPING_CONFIG: 'destock34_shipping_config_v2',
  BANK_DETAILS: 'destock34_bank_details_v1',
  NOTIFICATIONS: 'destock34_notifications_v1',
  WHATSAPP_NUMBER: 'destock34_whatsapp_number_v1',
};

export const DEFAULT_BANK_DETAILS: BankPaymentDetails = {
  bankName: 'BNP Paribas Entreprises',
  accountHolder: 'H DESTOCKAGE S.A.S.',
  iban: 'FR76 3000 4000 0100 2345 6789 012',
  bic: 'BNPAFRPPXXX',
  branchAddress: 'Entrepôt Logistique B2B, 93600 Aulnay-sous-Bois',
  paymentNotice: 'Reportez impérativement votre référence unique de commande en libellé de virement afin de valider sans délai le traitement logistique.',
};

export const DEFAULT_WHATSAPP_NUMBER = '+33 7 58 52 11 91';
export const ENTERPRISE_WHATSAPP_RAW = '33758521191';

// --- CONFIGURATION MANAGEMENT ---
export function getShippingConfig(): ShippingConfig {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SHIPPING_CONFIG);
    if (!data) return DEFAULT_SHIPPING_CONFIG;
    const parsed = JSON.parse(data);
    return {
      ...DEFAULT_SHIPPING_CONFIG,
      ...parsed,
      tarif_minimum: Math.max(106.0, parsed.tarif_minimum || 106.0),
      baseFee: Math.max(106.0, parsed.tarif_minimum || parsed.baseFee || 106.0),
      palletUnitPrice: parsed.palletUnitPrice || 350,
      tranches_distance: parsed.tranches_distance || DEFAULT_SHIPPING_CONFIG.tranches_distance,
      zones_difficiles_acces: parsed.zones_difficiles_acces || DEFAULT_SHIPPING_CONFIG.zones_difficiles_acces,
    };
  } catch {
    return DEFAULT_SHIPPING_CONFIG;
  }
}

export function saveShippingConfig(config: ShippingConfig): void {
  // Enforce rule: tarif_minimum >= 106.00 €
  const sanitized: ShippingConfig = {
    ...config,
    tarif_minimum: Math.max(106.0, config.tarif_minimum || 106.0),
    baseFee: Math.max(106.0, config.tarif_minimum || 106.0),
  };
  localStorage.setItem(STORAGE_KEYS.SHIPPING_CONFIG, JSON.stringify(sanitized));
  try {
    setDoc(doc(db, 'settings', 'shipping'), sanitized).catch(() => {});
  } catch {}
}

export function getBankPaymentDetails(): BankPaymentDetails {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.BANK_DETAILS);
    return data ? JSON.parse(data) : DEFAULT_BANK_DETAILS;
  } catch {
    return DEFAULT_BANK_DETAILS;
  }
}

export function saveBankPaymentDetails(details: BankPaymentDetails): void {
  localStorage.setItem(STORAGE_KEYS.BANK_DETAILS, JSON.stringify(details));
  try {
    setDoc(doc(db, 'settings', 'bank'), details).catch(() => {});
  } catch {}
}

export function getCommercialWhatsAppNumber(): string {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.WHATSAPP_NUMBER);
    return saved && saved.trim() ? saved : DEFAULT_WHATSAPP_NUMBER;
  } catch {
    return DEFAULT_WHATSAPP_NUMBER;
  }
}

export function saveCommercialWhatsAppNumber(phone: string): void {
  localStorage.setItem(STORAGE_KEYS.WHATSAPP_NUMBER, phone);
  try {
    setDoc(doc(db, 'settings', 'whatsapp'), { phone }).catch(() => {});
  } catch {}
}

/**
 * Calcul intelligent des frais de livraison côté serveur avec repli sécurisé
 */
export async function calculerFraisLivraisonClient(
  customer: Partial<PalletOrderCustomer>,
  config: ShippingConfig = getShippingConfig()
): Promise<CalculLivraisonResultat> {
  const adresseClient = {
    deliveryAddress: customer.deliveryAddress || '',
    postalCode: customer.postalCode || '',
    city: customer.city || '',
    country: customer.country || 'France métropolitaine',
  };

  // 1. Tenter l'appel API serveur
  try {
    const res = await fetch('/api/shipping/calculate-route', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adresseClient,
        configuration: config,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success && data.calculation) {
        return data.calculation;
      }
    }
  } catch {
    // Si échec réseau ou SSR, repli direct
  }

  // 2. Repli direct dans le service client
  return await calculer_frais_livraison(adresseClient, config);
}

// Backward compatible sync calculation for immediate typing feedback
export function calculateShipping(
  postalCode: string,
  country: string,
  config: ShippingConfig = getShippingConfig()
) {
  const cleanCode = (postalCode || '').trim();
  const cleanCountry = (country || '').trim().toLowerCase();

  const isDomestic =
    cleanCountry === 'france' ||
    cleanCountry === 'france métropolitaine' ||
    cleanCountry === 'monaco' ||
    cleanCountry === '';

  const isDomTom = cleanCode.startsWith('97') || cleanCode.startsWith('98');

  if (!isDomestic || isDomTom) {
    return {
      isQuoteRequired: true,
      isRemote: false,
      remoteReason: 'Destination hors France métropolitaine ou zone insulaire ultramarine (devis requis).',
      baseFee: config.tarif_minimum || 106.0,
      supplementFee: 0,
      totalDeliveryFee: 0,
      zoneType: 'QUOTE' as const,
    };
  }

  const isCorse = cleanCode.startsWith('20');
  const supplement = isCorse ? 85.0 : 0.0;

  return {
    isQuoteRequired: false,
    isRemote: isCorse,
    remoteReason: isCorse ? 'Territoire insulaire de Corse (acheminement maritime)' : undefined,
    baseFee: config.tarif_minimum || 106.0,
    supplementFee: supplement,
    totalDeliveryFee: (config.tarif_minimum || 106.0) + supplement,
    zoneType: (isCorse ? 'REMOTE' : 'STANDARD') as 'REMOTE' | 'STANDARD',
  };
}

// --- ORDER STORAGE & RETRIEVAL ---
export function getStoredPalletOrders(): PalletOrder[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveStoredPalletOrders(orders: PalletOrder[]): void {
  localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
}

export function getPalletOrderById(orderId: string): PalletOrder | null {
  const cleanId = orderId.trim().toUpperCase();
  const orders = getStoredPalletOrders();
  return orders.find((o) => o.id.toUpperCase() === cleanId) || null;
}

// --- PSEUDO-CODE IMPLEMENTATION: valider_commande ---
export function createPalletOrder(params: {
  palletCount?: number;
  items?: PalletCartItem[];
  palletsComposition?: PalletComposition[];
  customer: PalletOrderCustomer;
  config?: ShippingConfig;
  shippingResult?: CalculLivraisonResultat;
}): PalletOrder {
  const config = params.config || getShippingConfig();

  // Determine items and pallet count
  const items = params.items && params.items.length > 0 ? params.items : undefined;
  let palletCount = params.palletCount || 1;
  if (params.palletsComposition && params.palletsComposition.length > 0) {
    palletCount = params.palletsComposition.length;
  } else if (items && items.length > 0) {
    palletCount = items.reduce((sum, item) => sum + (item.palletCount || 1), 0);
  }
  palletCount = Math.max(1, Math.round(palletCount));

  const totalPairs = palletCount * 100;
  const palletUnitPrice = config.palletUnitPrice || 350;
  const merchandiseSubtotal = palletCount * palletUnitPrice;

  // Extract brands and models across items and mixed lots
  const brandsSet = new Set<string>();
  const modelsSet = new Set<string>();

  if (params.palletsComposition && params.palletsComposition.length > 0) {
    params.palletsComposition.forEach((pal) => {
      if (pal.type === 'MIXED' && pal.mixedLots) {
        pal.mixedLots.forEach((lot) => {
          if (lot.brand) brandsSet.add(lot.brand);
          if (lot.model) modelsSet.add(lot.model);
        });
      } else {
        if (pal.brand) brandsSet.add(pal.brand);
        if (pal.model) modelsSet.add(pal.model);
      }
    });
  }

  if (items && items.length > 0) {
    items.forEach((it) => {
      if (it.mixedLots && it.mixedLots.length > 0) {
        it.mixedLots.forEach((lot) => {
          if (lot.brand) brandsSet.add(lot.brand);
          if (lot.model) modelsSet.add(lot.model);
        });
      } else {
        if (it.brand) brandsSet.add(it.brand);
        if (it.model) modelsSet.add(it.model);
      }
    });
  }

  const brands = brandsSet.size > 0 ? Array.from(brandsSet) : ['Nike'];
  const models = modelsSet.size > 0 ? Array.from(modelsSet) : ['Air Max TN'];
  const brand = brands[0] || 'Nike';
  const model = models[0] || 'Air Max TN';

  // Calcul intelligent ou repli
  const calc =
    params.shippingResult ||
    calculer_frais_livraison_synchrone(
      params.customer,
      config,
      params.customer.postalCode?.startsWith('20') ? 650 : 220,
      `${params.customer.deliveryAddress}, ${params.customer.postalCode} ${params.customer.city}`
    );

  const isQuote = calc.statut === 'devis_manuel_requis';
  const deliveryFee = isQuote ? null : (calc.frais_livraison || 106.0);
  const baseDelivery = calc.tarif_minimum || 106.0;
  const deliverySupplement = calc.supplement_distance || 0;
  const totalAmount = merchandiseSubtotal + (deliveryFee || 0);

  // Split payments (Prompt rules):
  // Frais à régler pour lancer la livraison = 106 € + supplément éventuel
  const depositToStartDelivery = isQuote ? 106.0 : (deliveryFee || 106.0);
  // Solde à payer à la livraison = montant des marchandises
  const balanceDueOnDelivery = merchandiseSubtotal;

  const now = new Date();
  const year = now.getFullYear();
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const orderId = `CMD-HD-${year}-${randomSuffix}`;

  const formattedDate = now.toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const initialStatus: OrderStatus = isQuote
    ? 'Livraison en attente de devis'
    : 'En attente de paiement';

  const historyNote = isQuote
    ? `Commande créée avec devis de livraison en attente (${calc.motif || 'Destination spécifique'}).`
    : `Commande créée. Frais de livraison calculés automatiquement (${deliveryFee?.toFixed(2)} € pour ${calc.distance_routiere_km || 0} km). Facture pro forma générée instantanément.`;

  const newOrder: PalletOrder = {
    id: orderId,
    createdAt: now.toISOString(),
    formattedDate,
    palletCount,
    totalPairs,
    pairCount: totalPairs,
    items,
    palletsComposition: params.palletsComposition,
    brands,
    models,
    brand,
    model,
    palletUnitPrice,
    merchandiseSubtotal,
    deliveryFee,
    baseDeliveryFee: baseDelivery,
    deliverySupplement,
    deliveryIsQuoteRequired: isQuote,
    deliveryZoneType: isQuote ? 'QUOTE' : (calc.supplement_zones ? 'REMOTE' : 'STANDARD'),
    remoteReason: calc.motif,
    totalAmount,
    depositToStartDelivery,
    balanceDueOnDelivery,
    customer: params.customer,
    status: initialStatus,

    // Intelligent delivery snapshots according to pseudo-code
    tarifLivraisonVerrouille: !isQuote,
    distanceRoutiereKm: calc.distance_routiere_km,
    distanceIncluseKm: calc.distance_incluse_km ?? config.distance_incluse_km,
    tarifMinimum: calc.tarif_minimum ?? config.tarif_minimum,
    supplementDistance: calc.supplement_distance ?? 0,
    supplementZones: calc.supplement_zones ?? 0,
    destinationReconnue: calc.destination_reconnue,
    motifDevis: isQuote ? calc.motif : undefined,
    dateCalculLivraison: now.toISOString(),
    configurationLivraisonUtilisee: JSON.parse(JSON.stringify(config)),

    history: [
      {
        timestamp: formattedDate,
        status: 'Commande créée',
        note: `Commande de ${palletCount} palette(s) (${brand} ${model}) pour ${params.customer.firstName} ${params.customer.lastName}.`,
      },
      {
        timestamp: formattedDate,
        status: initialStatus,
        note: historyNote,
      },
    ],
  };

  // Save to local storage
  const existing = getStoredPalletOrders();
  const updated = [newOrder, ...existing];
  saveStoredPalletOrders(updated);

  // Sync to Firestore non-blockingly
  try {
    setDoc(doc(db, 'palletOrders', orderId), newOrder).catch(() => {});
  } catch {}

  // Record notification log
  addNotificationLog({
    orderId,
    recipientEmail: params.customer.email,
    subject: isQuote
      ? `Commande ${orderId} reçue - Devis livraison en cours d'établissement`
      : `Confirmation et facture pro forma - Commande N° ${orderId}`,
    type: 'CREATION',
    content: isQuote
      ? `Votre commande N° ${orderId} (${palletCount} palette(s)) est enregistrée. Notre service logistique calcule votre devis de livraison personnalisé.`
      : `Votre commande N° ${orderId} (${palletCount} palette(s)) d'un montant de ${totalAmount.toFixed(2)} € a bien été enregistrée. Votre facture pro forma est immédiatement disponible.`,
  });

  return newOrder;
}

// --- E-MAIL CONFIRMATION SERVICE (CLIENT & H DESTOCKAGE) ---
export async function sendOrderConfirmationEmail(order: PalletOrder): Promise<{ success: boolean; message: string }> {
  try {
    const res = await fetch('/api/orders/send-email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ order }),
    });

    if (res.ok) {
      const data = await res.json();
      return {
        success: true,
        message: data.message || 'Votre commande a été enregistrée et votre facture pro forma vous a été envoyée par e-mail. Finalisez maintenant votre commande sur WhatsApp.',
      };
    }
  } catch (err) {
    console.error('Email call error:', err);
  }

  // Fallback client notification log
  addNotificationLog({
    orderId: order.id,
    recipientEmail: order.customer.email,
    subject: `Facture Pro Forma — Commande N° ${order.id} H DESTOCKAGE`,
    type: 'PRO_FORMA',
    content: `Votre facture pro forma pour la commande N° ${order.id} est émise. Total : ${order.totalAmount.toFixed(2)} €. Finalisez votre commande sur WhatsApp au +33 7 58 52 11 91.`,
  });

  return {
    success: true,
    message: 'Votre commande a été enregistrée et votre facture pro forma vous a été envoyée par e-mail. Finalisez maintenant votre commande sur WhatsApp.',
  };
}

// --- PSEUDO-CODE IMPLEMENTATION: valider_devis_manuel ---
export function validerDevisManuel(params: {
  orderId: string;
  montantLivraison: number;
  administrateur?: string;
  motif?: string;
}): { success: boolean; order?: PalletOrder; error?: string } {
  const montant = Number(params.montantLivraison);
  if (isNaN(montant) || montant < 106.0) {
    return {
      success: false,
      error: 'Le tarif minimum de livraison pour la France métropolitaine est fixé à 106.00 €. Aucun devis ne peut être validé en dessous de ce montant.',
    };
  }

  const orders = getStoredPalletOrders();
  const index = orders.findIndex((o) => o.id === params.orderId);
  if (index === -1) {
    return { success: false, error: 'Commande introuvable' };
  }

  const order = orders[index];
  const roundedFee = Math.round(montant * 100) / 100;
  const newTotal = order.merchandiseSubtotal + roundedFee;
  const now = new Date();
  const formattedDate = now.toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const updatedOrder: PalletOrder = {
    ...order,
    deliveryFee: roundedFee,
    totalAmount: newTotal,
    status: 'En attente de paiement',
    deliveryIsQuoteRequired: false,
    tarifLivraisonVerrouille: true,
    dateValidationLivraison: now.toISOString(),
    validePar: params.administrateur || 'Direction Logistique H DESTOCKAGE',
    history: [
      {
        timestamp: formattedDate,
        status: 'En attente de paiement',
        note: `Devis de livraison validé à ${roundedFee.toFixed(2)} € par ${params.administrateur || 'l\'administrateur'}. Montant total commande : ${newTotal.toFixed(2)} €. Facture pro forma mise à jour et paiement débloqué.`,
      },
      ...order.history,
    ],
  };

  orders[index] = updatedOrder;
  saveStoredPalletOrders(orders);

  try {
    setDoc(doc(db, 'palletOrders', order.id), updatedOrder).catch(() => {});
  } catch {}

  addNotificationLog({
    orderId: order.id,
    recipientEmail: order.customer.email,
    subject: `Votre devis de livraison pour la commande ${order.id} est prêt`,
    type: 'CREATION',
    content: `Le montant de la livraison pour votre commande ${order.id} a été fixé à ${roundedFee.toFixed(2)} € (Total : ${newTotal.toFixed(2)} €). Votre facture pro forma est prête pour le règlement par virement.`,
  });

  return { success: true, order: updatedOrder };
}

// --- UPDATE ORDER STATUS ---
export function updatePalletOrderStatus(
  orderId: string,
  newStatus: OrderStatus,
  note?: string,
  trackingNumber?: string,
  carrierName?: string
): PalletOrder | null {
  const orders = getStoredPalletOrders();
  const index = orders.findIndex((o) => o.id === orderId);
  if (index === -1) return null;

  const now = new Date().toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const order = orders[index];
  const updatedOrder: PalletOrder = {
    ...order,
    status: newStatus,
    trackingNumber: trackingNumber !== undefined ? trackingNumber : order.trackingNumber,
    carrierName: carrierName !== undefined ? carrierName : order.carrierName,
    history: [
      {
        timestamp: now,
        status: newStatus,
        note: note || `Statut mis à jour : ${newStatus}`,
      },
      ...order.history,
    ],
  };

  orders[index] = updatedOrder;
  saveStoredPalletOrders(orders);

  // Sync to Firestore
  try {
    setDoc(doc(db, 'palletOrders', orderId), updatedOrder).catch(() => {});
  } catch {}

  // Trigger Notification
  let notifType: OrderNotificationLog['type'] = 'PREPARATION';
  if (newStatus === 'Paiement confirmé') notifType = 'PAYMENT_CONFIRMED';
  else if (newStatus === 'Paiement refusé ou justificatif invalide') notifType = 'PAYMENT_REJECTED';
  else if (newStatus === 'Expédiée') notifType = 'SHIPPED';
  else if (newStatus === 'Livrée') notifType = 'DELIVERED';

  addNotificationLog({
    orderId,
    recipientEmail: order.customer.email,
    subject: `Mise à jour de votre commande ${orderId} : ${newStatus}`,
    type: notifType,
    content: note || `Le statut de votre commande ${orderId} est désormais : ${newStatus}.`,
  });

  return updatedOrder;
}

// --- SUBMIT PAYMENT PROOF ---
export function submitPaymentProof(
  orderId: string,
  proof: PaymentProof
): PalletOrder | null {
  const orders = getStoredPalletOrders();
  const index = orders.findIndex((o) => o.id === orderId);
  if (index === -1) return null;

  const now = new Date().toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const order = orders[index];
  const updatedOrder: PalletOrder = {
    ...order,
    status: 'Justificatif reçu',
    paymentProof: proof,
    rejectionReason: undefined, // Clear prior rejection if any
    history: [
      {
        timestamp: now,
        status: 'Justificatif reçu',
        note: `Justificatif de paiement téléversé (${proof.paymentMethod}, réf : ${proof.transactionReference}, montant : ${proof.paidAmount} €). En attente de vérification administrative.`,
      },
      ...order.history,
    ],
  };

  orders[index] = updatedOrder;
  saveStoredPalletOrders(orders);

  try {
    setDoc(doc(db, 'palletOrders', orderId), updatedOrder).catch(() => {});
  } catch {}

  addNotificationLog({
    orderId,
    recipientEmail: order.customer.email,
    subject: `Justificatif reçu pour la commande ${orderId}`,
    type: 'PROOF_RECEIVED',
    content: `Votre justificatif de paiement pour la commande ${orderId} a bien été téléversé. Notre service comptable procède à sa vérification sous 24h ouvrées.`,
  });

  return updatedOrder;
}

// --- REVIEW PAYMENT PROOF (ADMIN) ---
export function reviewPaymentProof(
  orderId: string,
  action: 'CONFIRM' | 'REJECT',
  reason?: string
): PalletOrder | null {
  const orders = getStoredPalletOrders();
  const index = orders.findIndex((o) => o.id === orderId);
  if (index === -1) return null;

  const now = new Date().toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const order = orders[index];
  let newStatus: OrderStatus;
  let note: string;

  if (action === 'CONFIRM') {
    newStatus = 'Paiement confirmé';
    note = 'Règlement validé par le service comptable. Facture définitive émise et commande transmise à l\'entrepôt.';
  } else {
    newStatus = 'Paiement refusé ou justificatif invalide';
    note = `Justificatif refusé : ${reason || 'Document non conforme ou virement non parvenu sur le compte'}. Nouveau justificatif demandé au client.`;
  }

  const updatedOrder: PalletOrder = {
    ...order,
    status: newStatus,
    rejectionReason: action === 'REJECT' ? reason : undefined,
    history: [
      {
        timestamp: now,
        status: newStatus,
        note,
      },
      ...order.history,
    ],
  };

  orders[index] = updatedOrder;
  saveStoredPalletOrders(orders);

  try {
    setDoc(doc(db, 'palletOrders', orderId), updatedOrder).catch(() => {});
  } catch {}

  addNotificationLog({
    orderId,
    recipientEmail: order.customer.email,
    subject: action === 'CONFIRM' ? `Paiement validé pour la commande ${orderId}` : `Problème avec le justificatif de votre commande ${orderId}`,
    type: action === 'CONFIRM' ? 'PAYMENT_CONFIRMED' : 'PAYMENT_REJECTED',
    content: note,
  });

  return updatedOrder;
}

// --- NOTIFICATION AUDIT LOGS ---
export function getStoredNotifications(): OrderNotificationLog[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function addNotificationLog(log: Omit<OrderNotificationLog, 'id' | 'sentAt'>): OrderNotificationLog {
  const existing = getStoredNotifications();
  const entry: OrderNotificationLog = {
    ...log,
    id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    sentAt: new Date().toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }),
  };

  const updated = [entry, ...existing];
  localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(updated));
  return entry;
}
