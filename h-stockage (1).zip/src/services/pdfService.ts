import { jsPDF } from 'jspdf';
import { PalletOrder, BankPaymentDetails, ShippingConfig, SelectionItem } from '../types';

export function generateOrderPdf(
  order: PalletOrder,
  bankDetails?: BankPaymentDetails,
  config?: ShippingConfig,
  isFinalInvoice: boolean = false
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm
  const margin = 14;
  const contentWidth = pageWidth - margin * 2; // 182mm

  // Luxury Gold & Black Palette
  const COLOR_BLACK = [15, 17, 21]; // #0F1115
  const COLOR_GOLD = [197, 160, 89]; // #C5A059
  const COLOR_GOLD_DARK = [166, 124, 52]; // #A67C34
  const COLOR_GOLD_LIGHT = [253, 250, 243]; // #FDFAF3
  const COLOR_BG_SLATE = [248, 250, 252]; // #F8FAFC
  const COLOR_BORDER = [226, 232, 240]; // #E2E8F0
  const COLOR_BORDER_GOLD = [218, 192, 140]; // #DAC08C
  const COLOR_TEXT_DARK = [20, 24, 33];
  const COLOR_TEXT_MUTED = [100, 116, 139];

  // =========================================================================
  // 1. TOP HEADER WITH BLACK & GOLD GRAPHICAL BANDS
  // =========================================================================
  // Main Top Black Banner
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(0, 0, pageWidth, 28, 'F');

  // Gold Graphical Accent Line (Bande graphique dorée)
  doc.setFillColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.rect(0, 28, pageWidth, 2.5, 'F');

  // Logo Brand Name (H DESTOCKAGE)
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('H DESTOCKAGE', margin, 13);

  // Subtitle / Specialization
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.text('GROSSISTE MULTIMARQUES & DESTOCKAGE DE SNEAKERS', margin, 19);

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(203, 213, 225);
  doc.text('PLATEFORME LOGISTIQUE NATIONALE • 26-36 RUE ALFRED NOBEL, 93600 AULNAY-SOUS-BOIS', margin, 24);

  // Top Right Header: FACTURE PRO FORMA & Order Number
  const docTitle = isFinalInvoice ? 'FACTURE ACQUITTÉE' : 'FACTURE PRO FORMA';
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.text(docTitle, pageWidth - margin, 12, { align: 'right' });

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text(`N° ${order.id}`, pageWidth - margin, 18, { align: 'right' });

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(203, 213, 225);
  const dateStr = order.formattedDate || new Date(order.createdAt).toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
  doc.text(`Émise le : ${dateStr}`, pageWidth - margin, 24, { align: 'right' });

  // =========================================================================
  // 2. SUPPLIER & CUSTOMER INFORMATION BLOCKS (SIDE-BY-SIDE)
  // =========================================================================
  let y = 36;
  const colWidth = (contentWidth - 6) / 2; // 88mm

  // Supplier Box (Émetteur)
  doc.setFillColor(COLOR_BG_SLATE[0], COLOR_BG_SLATE[1], COLOR_BG_SLATE[2]);
  doc.rect(margin, y, colWidth, 42, 'F');
  doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
  doc.setLineWidth(0.3);
  doc.rect(margin, y, colWidth, 42, 'S');

  // Supplier Box Header Strip
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(margin, y, colWidth, 6.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(255, 255, 255);
  doc.text('FOURNISSEUR / ÉMETTEUR', margin + 3.5, y + 4.5);

  // Supplier Details
  let sy = y + 11;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text('H DESTOCKAGE', margin + 3.5, sy);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(COLOR_TEXT_DARK[0], COLOR_TEXT_DARK[1], COLOR_TEXT_DARK[2]);
  sy += 4;
  doc.text('26-36 rue Alfred Nobel', margin + 3.5, sy);
  sy += 3.5;
  doc.text('93600 Aulnay-sous-Bois — France', margin + 3.5, sy);
  sy += 3.5;
  doc.text('SIRET : 794 442 331 00016', margin + 3.5, sy);
  sy += 3.5;
  doc.text('E-mail : hdestockageentreprise.fr@gmail.com', margin + 3.5, sy);
  sy += 3.5;
  doc.setFont('helvetica', 'bold');
  doc.text('Tél / WhatsApp officiel : +33 7 58 52 11 91', margin + 3.5, sy);

  // Customer Box (Destinataire / Client)
  const custX = margin + colWidth + 6;
  doc.setFillColor(COLOR_BG_SLATE[0], COLOR_BG_SLATE[1], COLOR_BG_SLATE[2]);
  doc.rect(custX, y, colWidth, 42, 'F');
  doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
  doc.rect(custX, y, colWidth, 42, 'S');

  // Customer Box Header Strip
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(custX, y, colWidth, 6.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(255, 255, 255);
  doc.text('DESTINATAIRE / LIVRAISON', custX + 3.5, y + 4.5);

  // Customer Details
  let cy = y + 11;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text(`${order.customer.firstName} ${order.customer.lastName}`, custX + 3.5, cy);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(COLOR_TEXT_DARK[0], COLOR_TEXT_DARK[1], COLOR_TEXT_DARK[2]);
  cy += 4;
  if (order.customer.company) {
    doc.text(`Société : ${order.customer.company}`, custX + 3.5, cy);
    cy += 3.5;
  }
  doc.text(`Adresse : ${order.customer.deliveryAddress}`, custX + 3.5, cy, { maxWidth: colWidth - 7 });
  cy += 3.5;
  doc.text(`Ville / CP : ${order.customer.postalCode} ${order.customer.city} (${order.customer.country})`, custX + 3.5, cy);
  cy += 3.5;
  doc.text(`Téléphone : ${order.customer.phone}`, custX + 3.5, cy);
  cy += 3.5;
  doc.text(`E-mail : ${order.customer.email}`, custX + 3.5, cy);

  // =========================================================================
  // 3. CENTRAL ITEMS TABLE (DÉSIGNATION, MARQUE, MODÈLE, PALETTES, PAIRES, PRIX)
  // =========================================================================
  y = 84;

  // Table Columns Definition
  const colX = {
    desig: margin,
    marque: margin + 60,
    modele: margin + 90,
    palettes: margin + 124,
    paires: margin + 144,
    unitPrice: margin + 162,
    total: pageWidth - margin,
  };

  // Table Header Background (Black)
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(margin, y, contentWidth, 7, 'F');

  // Gold separator line on table header
  doc.setFillColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.rect(margin, y + 7, contentWidth, 0.6, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(255, 255, 255);
  doc.text('DÉSIGNATION DES ARTICLES', colX.desig + 3, y + 4.8);
  doc.text('MARQUE', colX.marque, y + 4.8);
  doc.text('MODÈLE', colX.modele, y + 4.8);
  doc.text('PALETTES', colX.palettes, y + 4.8, { align: 'center' });
  doc.text('PAIRES', colX.paires, y + 4.8, { align: 'center' });
  doc.text('PRIX UNIT.', colX.unitPrice, y + 4.8, { align: 'right' });
  doc.text('TOTAL HT', colX.total - 3, y + 4.8, { align: 'right' });

  y += 7.6;

  // Render Table Items
  const items = order.items && order.items.length > 0 ? order.items : [
    {
      id: 'item-1',
      brand: order.brand || order.brands?.[0] || 'Nike',
      model: order.model || order.models?.[0] || 'Air Max TN',
      photo: '',
      palletCount: order.palletCount || 1,
      pairCount: (order.palletCount || 1) * 100,
      palletPrice: order.palletUnitPrice || 350,
      subtotal: (order.palletCount || 1) * (order.palletUnitPrice || 350),
    }
  ];

  items.forEach((item, idx) => {
    const isMixed = item.palletType === 'MIXED' || Boolean(item.mixedLots && item.mixedLots.length > 0);
    const rowH = isMixed ? 14.5 : 11;
    const isEven = idx % 2 === 0;

    doc.setFillColor(isEven ? 255 : 249, isEven ? 255 : 250, isEven ? 255 : 251);
    doc.rect(margin, y, contentWidth, rowH, 'F');
    doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
    doc.rect(margin, y, contentWidth, rowH, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(COLOR_TEXT_DARK[0], COLOR_TEXT_DARK[1], COLOR_TEXT_DARK[2]);
    doc.text(
      isMixed ? `Palette Européenne Mixte N° ${idx + 1} (100 paires)` : 'Palette Européenne (Lot Revente)',
      colX.desig + 3,
      y + 4.2
    );

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6);
    doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
    if (isMixed && item.mixedLots && item.mixedLots.length > 0) {
      const l1 = item.mixedLots[0] ? `L1: 25p ${item.mixedLots[0].brand} ${item.mixedLots[0].model}` : '';
      const l2 = item.mixedLots[1] ? ` | L2: 25p ${item.mixedLots[1].brand} ${item.mixedLots[1].model}` : '';
      const l3 = item.mixedLots[2] ? `L3: 25p ${item.mixedLots[2].brand} ${item.mixedLots[2].model}` : '';
      const l4 = item.mixedLots[3] ? ` | L4: 25p ${item.mixedLots[3].brand} ${item.mixedLots[3].model}` : '';
      doc.text(`${l1}${l2}`, colX.desig + 3, y + 8);
      doc.text(`${l3}${l4}`, colX.desig + 3, y + 11.5);
    } else {
      doc.text('Conditionnement filmé & cerclé sous scellés (100 p.)', colX.desig + 3, y + 8.5);
    }

    // Marque
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(COLOR_TEXT_DARK[0], COLOR_TEXT_DARK[1], COLOR_TEXT_DARK[2]);
    doc.text(isMixed ? 'Mixte' : (item.brand || 'Nike'), colX.marque, y + 6);

    // Modèle
    doc.setFont('helvetica', 'normal');
    doc.text(isMixed ? '4 lots × 25 p.' : (item.model || 'Air Max TN'), colX.modele, y + 6);

    // Palettes
    doc.setFont('helvetica', 'bold');
    doc.text(`${item.palletCount} pal.`, colX.palettes, y + 6, { align: 'center' });

    // Paires
    doc.setFont('helvetica', 'normal');
    doc.text(`${item.pairCount || item.palletCount * 100}`, colX.paires, y + 6, { align: 'center' });

    // Prix Unit
    doc.text(`${item.palletPrice.toFixed(2)} €`, colX.unitPrice, y + 6, { align: 'right' });

    // Total
    doc.setFont('helvetica', 'bold');
    doc.text(`${item.subtotal.toFixed(2)} €`, colX.total - 3, y + 6, { align: 'right' });

    y += rowH;
  });

  // =========================================================================
  // 4. FINANCIAL BREAKDOWN & PAYMENT SUMMARY
  // =========================================================================
  y += 4;

  // Exact calculations
  const totalPallets = order.palletCount || items.reduce((sum, it) => sum + it.palletCount, 0);
  const totalPairs = order.totalPairs || totalPallets * 100;
  const merchandiseSubtotal = order.merchandiseSubtotal || totalPallets * 350;
  const deliveryFee = order.deliveryFee !== null ? order.deliveryFee : 106.0;
  const baseDelivery = order.baseDeliveryFee || 106.0;
  const supplement = order.deliverySupplement || 0;
  const totalAmount = order.totalAmount || (merchandiseSubtotal + deliveryFee);

  // Left Box: Delivery Specifications & Conditions
  const leftW = 86;
  doc.setFillColor(COLOR_BG_SLATE[0], COLOR_BG_SLATE[1], COLOR_BG_SLATE[2]);
  doc.rect(margin, y, leftW, 46, 'F');
  doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
  doc.rect(margin, y, leftW, 46, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text('MODALITÉS DE LIVRAISON & CONDITIONS', margin + 3.5, y + 5.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
  let ly = y + 10;
  doc.text(`• Acheminement direct depuis notre entrepôt d'Aulnay-sous-Bois (93600).`, margin + 3.5, ly);
  ly += 4;
  doc.text(`• Transporteur spécialisé messagerie palettes (Geodis / Dachser).`, margin + 3.5, ly);
  ly += 4;
  doc.text(`• Délais moyens indicatifs : 48h à 72h ouvrées après validation.`, margin + 3.5, ly);
  ly += 4;
  doc.text(`• Total : ${totalPallets} palette(s) sécurisée(s) soit ${totalPairs} paires neuves.`, margin + 3.5, ly);
  ly += 4;
  doc.text(`• Emballage sous film étirable opaque noir avec scellés de sécurité.`, margin + 3.5, ly);
  ly += 4;
  doc.text(`• Prise de rendez-vous téléphonique préalable par le transporteur.`, margin + 3.5, ly);
  ly += 4;
  doc.text(`• Contrôle des scellés et émargement du bon de livraison à l'arrivée.`, margin + 3.5, ly);

  // Right Side: Standard Financial Summary Table
  const rightX = pageWidth - margin - 88;
  const rightW = 88;

  doc.setFillColor(255, 255, 255);
  doc.rect(rightX, y, rightW, 46, 'F');
  doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
  doc.rect(rightX, y, rightW, 46, 'S');

  let ry = y + 5.5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(COLOR_TEXT_DARK[0], COLOR_TEXT_DARK[1], COLOR_TEXT_DARK[2]);
  doc.text('Montant des marchandises :', rightX + 3.5, ry);
  doc.setFont('helvetica', 'bold');
  doc.text(`${merchandiseSubtotal.toFixed(2)} €`, pageWidth - margin - 3.5, ry, { align: 'right' });

  ry += 5;
  doc.setFont('helvetica', 'normal');
  doc.text('Frais de livraison (Base 106,00 €) :', rightX + 3.5, ry);
  doc.setFont('helvetica', 'bold');
  doc.text(`${baseDelivery.toFixed(2)} €`, pageWidth - margin - 3.5, ry, { align: 'right' });

  if (supplement > 0) {
    ry += 5;
    doc.setFont('helvetica', 'normal');
    doc.text('Supplément distance / zone spécifique :', rightX + 3.5, ry);
    doc.setFont('helvetica', 'bold');
    doc.text(`${supplement.toFixed(2)} €`, pageWidth - margin - 3.5, ry, { align: 'right' });
  }

  ry += 5;
  doc.setFont('helvetica', 'normal');
  doc.text('Régime fiscal B2B (TVA) :', rightX + 3.5, ry);
  doc.text('0.00 € (Auto-liquidation)', pageWidth - margin - 3.5, ry, { align: 'right' });

  // Divider
  ry += 3;
  doc.setDrawColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.setLineWidth(0.4);
  doc.line(rightX + 3.5, ry, pageWidth - margin - 3.5, ry);

  // TOTAL AMOUNT DUE / MONTANT TOTAL DÛ BAR
  ry += 6;
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(rightX + 2, ry - 4.5, rightW - 4, 8.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.text('MONTANT TOTAL DÛ :', rightX + 5, ry + 1.2);
  doc.setFontSize(10);
  doc.setTextColor(255, 255, 255);
  doc.text(`${totalAmount.toFixed(2)} €`, pageWidth - margin - 5, ry + 1.2, { align: 'right' });

  // =========================================================================
  // 5. OFFICIAL STAMP (CACHET), SIGNATURE & "MERCI POUR VOTRE CONFIANCE"
  // =========================================================================
  y += 54;

  // Stamp / Cachet Officiel H DESTOCKAGE (Circulaire)
  const stampCenterX = margin + 30;
  const stampCenterY = y + 18;
  const stampRadius = 16;

  doc.setDrawColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.setLineWidth(0.8);
  doc.circle(stampCenterX, stampCenterY, stampRadius, 'S');
  doc.setLineWidth(0.3);
  doc.circle(stampCenterX, stampCenterY, stampRadius - 2, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(COLOR_GOLD_DARK[0], COLOR_GOLD_DARK[1], COLOR_GOLD_DARK[2]);
  doc.text('★ H DESTOCKAGE ★', stampCenterX, stampCenterY - 7, { align: 'center' });

  doc.setFontSize(5.5);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text('SERVICE LOGISTIQUE', stampCenterX, stampCenterY - 2.5, { align: 'center' });
  doc.text('& EXPÉDITIONS', stampCenterX, stampCenterY + 1.5, { align: 'center' });
  doc.text('93600 AULNAY-SOUS-BOIS', stampCenterX, stampCenterY + 5.5, { align: 'center' });

  doc.setFontSize(4.5);
  doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
  doc.text('SIRET 794 442 331 00016', stampCenterX, stampCenterY + 9.5, { align: 'center' });

  // Signature Block
  const sigX = margin + 68;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text('SIGNATURE & VALIDATION OFFICIELLE :', sigX, y + 6);

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(6.5);
  doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
  doc.text('Direction Commerciale & Gestion des flux palettes', sigX, y + 11);

  // Stylized Electronic Seal
  doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
  doc.line(sigX, y + 25, sigX + 50, y + 25);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6);
  doc.setTextColor(COLOR_GOLD_DARK[0], COLOR_GOLD_DARK[1], COLOR_GOLD_DARK[2]);
  doc.text('Certifié conforme par H DESTOCKAGE', sigX, y + 29);

  // Mandatory Callout: "Merci pour votre confiance"
  const trustX = pageWidth - margin - 58;
  doc.setFillColor(COLOR_GOLD_LIGHT[0], COLOR_GOLD_LIGHT[1], COLOR_GOLD_LIGHT[2]);
  doc.rect(trustX, y + 8, 58, 18, 'F');
  doc.setDrawColor(COLOR_BORDER_GOLD[0], COLOR_BORDER_GOLD[1], COLOR_BORDER_GOLD[2]);
  doc.rect(trustX, y + 8, 58, 18, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text('Merci pour votre confiance', trustX + 29, y + 16, { align: 'center' });

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(COLOR_GOLD_DARK[0], COLOR_GOLD_DARK[1], COLOR_GOLD_DARK[2]);
  doc.text('Votre satisfaction est notre priorité', trustX + 29, y + 21, { align: 'center' });

  // =========================================================================
  // 7. FOOTER WITH BLACK & GOLD BANDS AND LEGAL NOTICES
  // =========================================================================
  const footerY = pageHeight - 16;

  // Gold Line
  doc.setFillColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.rect(0, footerY - 1.5, pageWidth, 1.2, 'F');

  // Black Bottom Bar
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(0, footerY - 0.3, pageWidth, 16.3, 'F');

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(255, 255, 255);
  doc.text(
    'H DESTOCKAGE • 26-36 rue Alfred Nobel, 93600 Aulnay-sous-Bois • SIRET : 794 442 331 00016 • E-mail : hdestockageentreprise.fr@gmail.com • Tél : +33 7 58 52 11 91',
    pageWidth / 2,
    footerY + 5.5,
    { align: 'center' }
  );

  doc.setFontSize(5.5);
  doc.setTextColor(148, 163, 184);
  doc.text(
    `Document pro forma officiel généré pour la commande N° ${order.id} • Page 1/1 • Pièce comptable à conserver`,
    pageWidth / 2,
    footerY + 10.5,
    { align: 'center' }
  );

  // Output filename
  const filename = isFinalInvoice
    ? `Facture_H_DESTOCKAGE_${order.id}.pdf`
    : `Facture_ProForma_H_DESTOCKAGE_${order.id}.pdf`;
  doc.save(filename);
}

// =========================================================================
// 8. RÉCAPITULATIF DE SÉLECTION B2B (ARCHIVAGE & PARTAGE INTERNE)
// =========================================================================
export interface SelectionPdfOptions {
  company?: string;
  contactName?: string;
  email?: string;
  phone?: string;
  notes?: string;
  inquiryRef?: string;
  documentTitle?: string;
}

export function generateSelectionSummaryPdf(
  items: SelectionItem[],
  options?: SelectionPdfOptions
): void {
  if (!items || items.length === 0) return;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm
  const margin = 14;
  const contentWidth = pageWidth - margin * 2; // 182mm

  // Luxury Gold & Black Palette
  const COLOR_BLACK = [15, 17, 21]; // #0F1115
  const COLOR_GOLD = [197, 160, 89]; // #C5A059
  const COLOR_GOLD_DARK = [166, 124, 52]; // #A67C34
  const COLOR_GOLD_LIGHT = [253, 250, 243]; // #FDFAF3
  const COLOR_BG_SLATE = [248, 250, 252]; // #F8FAFC
  const COLOR_BORDER = [226, 232, 240]; // #E2E8F0
  const COLOR_BORDER_GOLD = [218, 192, 140]; // #DAC08C
  const COLOR_TEXT_DARK = [20, 24, 33];
  const COLOR_TEXT_MUTED = [100, 116, 139];

  // Calculations
  const totalPallets = items.reduce((sum, it) => sum + Math.max(1, it.palletCount || 1), 0);
  const totalPairs = totalPallets * 100;
  const merchandiseSubtotal = totalPallets * 350;

  const now = new Date();
  const dateStr = now.toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
  const refCode = options?.inquiryRef
    ? options.inquiryRef
    : `COT-HD-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}-${Math.floor(1000 + Math.random() * 9000)}`;

  // Top Black Banner
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(0, 0, pageWidth, 28, 'F');

  // Gold Graphical Accent Line
  doc.setFillColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.rect(0, 28, pageWidth, 2.5, 'F');

  // Logo Brand Name
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('H DESTOCKAGE', margin, 13);

  // Subtitle / Specialization
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.text('GROSSISTE MULTIMARQUES & DESTOCKAGE DE SNEAKERS', margin, 19);

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(203, 213, 225);
  doc.text('PLATEFORME LOGISTIQUE NATIONALE • 26-36 RUE ALFRED NOBEL, 93600 AULNAY-SOUS-BOIS', margin, 24);

  // Top Right Header: FICHE RÉCAPITULATIVE & COTATION B2B
  const docHeaderTitle = options?.documentTitle || 'FICHE RÉCAPITULATIVE & COTATION B2B';
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.text(docHeaderTitle, pageWidth - margin, 12, { align: 'right' });

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text(`RÉF : ${refCode}`, pageWidth - margin, 18, { align: 'right' });

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(203, 213, 225);
  doc.text(`Émis le : ${dateStr} • Demande de cotation`, pageWidth - margin, 24, { align: 'right' });

  // 2. Émetteur & Destinataire B2B (Side-by-side)
  let y = 35;
  const colWidth = (contentWidth - 6) / 2; // 88mm

  // Supplier Box (Left)
  doc.setFillColor(COLOR_BG_SLATE[0], COLOR_BG_SLATE[1], COLOR_BG_SLATE[2]);
  doc.rect(margin, y, colWidth, 38, 'F');
  doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
  doc.setLineWidth(0.3);
  doc.rect(margin, y, colWidth, 38, 'S');

  // Supplier Header Strip
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(margin, y, colWidth, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(255, 255, 255);
  doc.text('FOURNISSEUR & PLATEFORME LOGISTIQUE B2B', margin + 3, y + 4.2);

  let sy = y + 9.5;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text('H DESTOCKAGE GROSSISTE', margin + 3.5, sy);

  sy += 3.8;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
  doc.text('Plateforme logistique : 26-36 rue Alfred Nobel, 93600 Aulnay-sous-Bois', margin + 3.5, sy);
  sy += 3.5;
  doc.text('SIRET : 794 442 331 00016 • RCS Bobigny', margin + 3.5, sy);
  sy += 3.5;
  doc.text('E-mail commercial : hdestockageentreprise.fr@gmail.com', margin + 3.5, sy);
  sy += 3.5;
  doc.text('WhatsApp Commercial : +33 7 58 52 11 91', margin + 3.5, sy);
  sy += 3.5;
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(COLOR_GOLD_DARK[0], COLOR_GOLD_DARK[1], COLOR_GOLD_DARK[2]);
  doc.text('Vente exclusive par palettes (100 paires = 350 € HT)', margin + 3.5, sy);

  // Client Box (Right)
  const custX = margin + colWidth + 6;
  doc.setFillColor(COLOR_BG_SLATE[0], COLOR_BG_SLATE[1], COLOR_BG_SLATE[2]);
  doc.rect(custX, y, colWidth, 38, 'F');
  doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
  doc.setLineWidth(0.3);
  doc.rect(custX, y, colWidth, 38, 'S');

  // Client Header Strip
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(custX, y, colWidth, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.text('CLIENT & DESTINATAIRE B2B (ARCHIVAGE / ÉTUDE)', custX + 3, y + 4.2);

  let cy = y + 9.5;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  const companyName = options?.company?.trim() || 'Service Achats / Revendeur B2B';
  doc.text(companyName, custX + 3.5, cy);

  cy += 3.8;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
  if (options?.contactName?.trim()) {
    doc.text(`Contact : ${options.contactName.trim()}`, custX + 3.5, cy);
    cy += 3.5;
  }
  if (options?.email?.trim()) {
    doc.text(`E-mail : ${options.email.trim()}`, custX + 3.5, cy);
    cy += 3.5;
  }
  if (options?.phone?.trim()) {
    doc.text(`Téléphone : ${options.phone.trim()}`, custX + 3.5, cy);
    cy += 3.5;
  }
  if (options?.notes?.trim()) {
    doc.text(`Objet / Note : ${options.notes.trim()}`, custX + 3.5, cy, { maxWidth: colWidth - 7 });
    cy += 3.5;
  }
  doc.text('Usage : Fiche récapitulative de sélection & cotation B2B', custX + 3.5, cy);
  cy += 3.5;
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(COLOR_GOLD_DARK[0], COLOR_GOLD_DARK[1], COLOR_GOLD_DARK[2]);
  doc.text('Document non contractuel • Réservation ferme sur commande', custX + 3.5, cy);

  // 3. KPI Metrics Bar
  y = 77;
  const kpiW = (contentWidth - 6) / 4;
  const kpis = [
    { label: 'MODÈLES CHOISIS', val: `${items.length} modèle${items.length > 1 ? 's' : ''}`, sub: 'Sneakers certifiées' },
    { label: 'PALETTES TOTALES', val: `${totalPallets} palette${totalPallets > 1 ? 's' : ''}`, sub: 'Conditionnement filmé' },
    { label: 'VOLUME TOTAL', val: `${totalPairs} paires`, sub: '100 paires / pal.' },
    { label: 'SOUS-TOTAL ESTIMÉ', val: `${merchandiseSubtotal.toLocaleString('fr-FR')} € HT`, sub: 'Prix fixe 350 € / pal.' },
  ];

  kpis.forEach((kpi, idx) => {
    const kx = margin + idx * (kpiW + 2);
    doc.setFillColor(COLOR_GOLD_LIGHT[0], COLOR_GOLD_LIGHT[1], COLOR_GOLD_LIGHT[2]);
    doc.rect(kx, y, kpiW, 14, 'F');
    doc.setDrawColor(COLOR_BORDER_GOLD[0], COLOR_BORDER_GOLD[1], COLOR_BORDER_GOLD[2]);
    doc.setLineWidth(0.3);
    doc.rect(kx, y, kpiW, 14, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(5.5);
    doc.setTextColor(COLOR_GOLD_DARK[0], COLOR_GOLD_DARK[1], COLOR_GOLD_DARK[2]);
    doc.text(kpi.label, kx + 2.5, y + 3.8);

    doc.setFontSize(8.5);
    doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
    doc.text(kpi.val, kx + 2.5, y + 8.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(5.5);
    doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
    doc.text(kpi.sub, kx + 2.5, y + 12);
  });

  // 4. Central Items Table
  y = 95;

  const colX = {
    num: margin + 2,
    marque: margin + 12,
    modele: margin + 42,
    pointures: margin + 104,
    palettes: margin + 144,
    paires: margin + 160,
    total: pageWidth - margin - 2,
  };

  // Table Header Background (Black)
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(margin, y, contentWidth, 7, 'F');
  doc.setFillColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.rect(margin, y + 7, contentWidth, 0.6, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.5);
  doc.setTextColor(255, 255, 255);
  doc.text('N°', colX.num, y + 4.8);
  doc.text('MARQUE', colX.marque, y + 4.8);
  doc.text('MODÈLE & DÉSIGNATION', colX.modele, y + 4.8);
  doc.text('POINTURES SOUHAITÉES', colX.pointures, y + 4.8);
  doc.text('PALETTES', colX.palettes, y + 4.8, { align: 'center' });
  doc.text('PAIRES', colX.paires, y + 4.8, { align: 'center' });
  doc.text('TOTAL HT', colX.total, y + 4.8, { align: 'right' });

  y += 7.6;

  // Render items rows
  items.forEach((item, idx) => {
    const palCount = Math.max(1, item.palletCount || 1);
    const pairs = palCount * 100;
    const lineTotal = palCount * 350;
    const sizesText = item.selectedSizes && item.selectedSizes.length > 0
      ? item.selectedSizes.sort((a, b) => a - b).join(', ')
      : 'Mix assorti standard (36 à 46)';

    const rowH = 9.5;
    const isEven = idx % 2 === 0;

    doc.setFillColor(isEven ? 255 : 249, isEven ? 255 : 250, isEven ? 255 : 251);
    doc.rect(margin, y, contentWidth, rowH, 'F');
    doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
    doc.rect(margin, y, contentWidth, rowH, 'S');

    // N°
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
    doc.text(`${(idx + 1).toString().padStart(2, '0')}`, colX.num, y + 6);

    // Marque
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(COLOR_TEXT_DARK[0], COLOR_TEXT_DARK[1], COLOR_TEXT_DARK[2]);
    doc.text(item.product.brand || 'Marque', colX.marque, y + 6);

    // Modèle
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    const modelText = doc.splitTextToSize(item.product.name, 58);
    doc.text(modelText[0] || item.product.name, colX.modele, y + 4.2);
    doc.setFontSize(5.5);
    doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
    doc.text('Conditionnement palette certifié neuf (boîtes intactes)', colX.modele, y + 7.8);

    // Pointures
    doc.setFontSize(6.5);
    doc.setTextColor(COLOR_TEXT_DARK[0], COLOR_TEXT_DARK[1], COLOR_TEXT_DARK[2]);
    const pointuresCut = doc.splitTextToSize(sizesText, 36);
    doc.text(pointuresCut[0] || sizesText, colX.pointures, y + 6);

    // Palettes
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.text(`${palCount} pal.`, colX.palettes, y + 6, { align: 'center' });

    // Paires
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.text(`${pairs}`, colX.paires, y + 6, { align: 'center' });

    // Total HT
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.text(`${lineTotal.toFixed(2)} €`, colX.total, y + 6, { align: 'right' });

    y += rowH;
  });

  // 5. Conditions Commerciales & Summary Blocks (Side-by-Side)
  y += 5;
  const bottomW = (contentWidth - 6) / 2;

  // Left Box: Conditions B2B & Expéditions
  doc.setFillColor(COLOR_BG_SLATE[0], COLOR_BG_SLATE[1], COLOR_BG_SLATE[2]);
  doc.rect(margin, y, bottomW, 40, 'F');
  doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
  doc.setLineWidth(0.3);
  doc.rect(margin, y, bottomW, 40, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text('CONDITIONS & RÈGLES COMMERCIALES B2B', margin + 3.5, y + 5.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.2);
  doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
  let bLy = y + 9.5;
  doc.text('• Conditionnement standard : 1 palette = 100 paires = 350 € HT.', margin + 3.5, bLy);
  bLy += 3.6;
  doc.text('• Produits 100% neufs avec boîtes d\'origine et codes EAN conformes.', margin + 3.5, bLy);
  bLy += 3.6;
  doc.text('• Expédition par transporteur professionnel messagerie avec hayon.', margin + 3.5, bLy);
  bLy += 3.6;
  doc.text('• Départ sous 24h-48h depuis notre entrepôt d\'Aulnay-sous-Bois (93600).', margin + 3.5, bLy);
  bLy += 4.5;
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(COLOR_GOLD_DARK[0], COLOR_GOLD_DARK[1], COLOR_GOLD_DARK[2]);
  doc.text('POUR COMMANDER OU RÉSERVER CE LOT :', margin + 3.5, bLy);
  bLy += 3.5;
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(COLOR_TEXT_DARK[0], COLOR_TEXT_DARK[1], COLOR_TEXT_DARK[2]);
  doc.text('1. Valider la commande en ligne sur la plateforme H DESTOCKAGE.', margin + 3.5, bLy);
  bLy += 3.2;
  doc.text('2. Ou transmettre ce PDF sur WhatsApp commercial (+33 7 58 52 11 91).', margin + 3.5, bLy);

  // Right Box: Totaux Financiers & Estimation
  const rightBX = margin + bottomW + 6;
  doc.setFillColor(255, 255, 255);
  doc.rect(rightBX, y, bottomW, 40, 'F');
  doc.setDrawColor(COLOR_BORDER[0], COLOR_BORDER[1], COLOR_BORDER[2]);
  doc.setLineWidth(0.3);
  doc.rect(rightBX, y, bottomW, 40, 'S');

  let bRy = y + 5.5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(COLOR_TEXT_DARK[0], COLOR_TEXT_DARK[1], COLOR_TEXT_DARK[2]);
  doc.text('Sous-total marchandises :', rightBX + 3.5, bRy);
  doc.setFont('helvetica', 'bold');
  doc.text(`${merchandiseSubtotal.toFixed(2)} € HT`, pageWidth - margin - 3.5, bRy, { align: 'right' });

  bRy += 4.5;
  doc.setFont('helvetica', 'normal');
  doc.text('Nombre total de palettes :', rightBX + 3.5, bRy);
  doc.setFont('helvetica', 'bold');
  doc.text(`${totalPallets} palette(s)`, pageWidth - margin - 3.5, bRy, { align: 'right' });

  bRy += 4.5;
  doc.setFont('helvetica', 'normal');
  doc.text('Frais de livraison estimés :', rightBX + 3.5, bRy);
  doc.setFont('helvetica', 'bold');
  doc.text('Calculés à l\'adresse (dès 106 € HT)', pageWidth - margin - 3.5, bRy, { align: 'right' });

  bRy += 4.5;
  doc.setFont('helvetica', 'normal');
  doc.text('Régime fiscal B2B (TVA) :', rightBX + 3.5, bRy);
  doc.text('0.00 € (Auto-liquidation art. 283 CGI)', pageWidth - margin - 3.5, bRy, { align: 'right' });

  // Divider line
  bRy += 3;
  doc.setDrawColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.setLineWidth(0.4);
  doc.line(rightBX + 3.5, bRy, pageWidth - margin - 3.5, bRy);

  // TOTAL BAR
  bRy += 5.2;
  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(rightBX + 2, bRy - 4, bottomW - 4, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.text('ESTIMATION TOTALE HT :', rightBX + 4.5, bRy + 1.2);
  doc.setFontSize(9.5);
  doc.setTextColor(255, 255, 255);
  doc.text(`${merchandiseSubtotal.toFixed(2)} € HT`, pageWidth - margin - 4.5, bRy + 1.2, { align: 'right' });

  // 6. Signature & Official Stamp Strip
  y += 44;

  // Stamp / Cachet
  const stampCenterX = margin + 25;
  const stampCenterY = y + 13;
  const stampRadius = 12;

  doc.setDrawColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.setLineWidth(0.7);
  doc.circle(stampCenterX, stampCenterY, stampRadius, 'S');
  doc.setLineWidth(0.25);
  doc.circle(stampCenterX, stampCenterY, stampRadius - 1.8, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6);
  doc.setTextColor(COLOR_GOLD_DARK[0], COLOR_GOLD_DARK[1], COLOR_GOLD_DARK[2]);
  doc.text('★ H DESTOCKAGE ★', stampCenterX, stampCenterY - 5, { align: 'center' });

  doc.setFontSize(4.8);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text('DÉPARTEMENT ACHATS', stampCenterX, stampCenterY - 1.5, { align: 'center' });
  doc.text('& FLUX PALETTES', stampCenterX, stampCenterY + 1.5, { align: 'center' });
  doc.text('93600 AULNAY-SOUS-BOIS', stampCenterX, stampCenterY + 4.5, { align: 'center' });

  doc.setFontSize(3.8);
  doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
  doc.text('SIRET 794 442 331 00016', stampCenterX, stampCenterY + 7.5, { align: 'center' });

  // Trust Callout Box
  const trustX = margin + 54;
  const trustW = contentWidth - 54;
  doc.setFillColor(COLOR_GOLD_LIGHT[0], COLOR_GOLD_LIGHT[1], COLOR_GOLD_LIGHT[2]);
  doc.rect(trustX, y + 2, trustW, 20, 'F');
  doc.setDrawColor(COLOR_BORDER_GOLD[0], COLOR_BORDER_GOLD[1], COLOR_BORDER_GOLD[2]);
  doc.setLineWidth(0.3);
  doc.rect(trustX, y + 2, trustW, 20, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.8);
  doc.setTextColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.text('RÉCAPITULATIF DESTINÉ À L\'ARCHIVAGE & AU PARTAGE INTERNE', trustX + 4, y + 7.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.2);
  doc.setTextColor(COLOR_TEXT_MUTED[0], COLOR_TEXT_MUTED[1], COLOR_TEXT_MUTED[2]);
  doc.text('Synthèse officielle émise pour validation budgétaire, concertation d\'équipe ou archivage comptable.', trustX + 4, y + 12.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(COLOR_GOLD_DARK[0], COLOR_GOLD_DARK[1], COLOR_GOLD_DARK[2]);
  doc.text('Contact Service Commercial : hdestockageentreprise.fr@gmail.com • WhatsApp : +33 7 58 52 11 91', trustX + 4, y + 17.5);

  // 7. Footer
  const footerY = pageHeight - 16;
  doc.setFillColor(COLOR_GOLD[0], COLOR_GOLD[1], COLOR_GOLD[2]);
  doc.rect(0, footerY - 1.5, pageWidth, 1.2, 'F');

  doc.setFillColor(COLOR_BLACK[0], COLOR_BLACK[1], COLOR_BLACK[2]);
  doc.rect(0, footerY - 0.3, pageWidth, 16.3, 'F');

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(255, 255, 255);
  doc.text(
    'H DESTOCKAGE • 26-36 rue Alfred Nobel, 93600 Aulnay-sous-Bois • SIRET : 794 442 331 00016 • E-mail : hdestockageentreprise.fr@gmail.com • Tél : +33 7 58 52 11 91',
    pageWidth / 2,
    footerY + 5.5,
    { align: 'center' }
  );

  doc.setFontSize(5.5);
  doc.setTextColor(148, 163, 184);
  doc.text(
    `Document récapitulatif de sélection B2B N° ${refCode} • Page 1/1 • Pièce informative et d'archivage client`,
    pageWidth / 2,
    footerY + 10.5,
    { align: 'center' }
  );

  // Save PDF
  const filename = `Fiche_Recapitulative_Cotation_H_DESTOCKAGE_${now.toISOString().slice(0, 10)}.pdf`;
  doc.save(filename);
}

