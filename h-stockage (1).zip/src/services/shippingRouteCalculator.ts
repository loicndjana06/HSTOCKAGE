import {
  ShippingConfig,
  DistanceTranche,
  ZoneDifficileAcces,
  CalculLivraisonResultat,
  PalletOrderCustomer,
} from '../types';

export const CONSTANTE_TARIF_MINIMUM_DEFAUT = 106.0;

export const DEFAULT_SHIPPING_CONFIG: ShippingConfig = {
  tarif_minimum: 106.0, // Minimum 106 € imposé pour la France métropolitaine
  distance_incluse_km: 50, // 50 km inclus dans le forfait minimum
  mode_calcul: 'tranches',
  tranches_distance: [
    {
      id: 't-0-50',
      distance_min_km: 0,
      distance_max_km: 50,
      supplement_euros: 0,
      devis_manuel_obligatoire: false,
    },
    {
      id: 't-50-150',
      distance_min_km: 50.01,
      distance_max_km: 150,
      supplement_euros: 25.0,
      devis_manuel_obligatoire: false,
    },
    {
      id: 't-150-300',
      distance_min_km: 150.01,
      distance_max_km: 300,
      supplement_euros: 45.0,
      devis_manuel_obligatoire: false,
    },
    {
      id: 't-300-600',
      distance_min_km: 300.01,
      distance_max_km: 600,
      supplement_euros: 75.0,
      devis_manuel_obligatoire: false,
    },
    {
      id: 't-600-900',
      distance_min_km: 600.01,
      distance_max_km: 900,
      supplement_euros: 115.0,
      devis_manuel_obligatoire: false,
    },
    {
      id: 't-900-1200',
      distance_min_km: 900.01,
      distance_max_km: 1200,
      supplement_euros: 150.0,
      devis_manuel_obligatoire: false,
    },
    {
      id: 't-1200-plus',
      distance_min_km: 1200.01,
      distance_max_km: null,
      supplement_euros: 0,
      devis_manuel_obligatoire: true,
    },
  ],
  tarif_par_km_supplementaire: 0.35,
  zones_difficiles_acces: [
    {
      id: 'z-corse',
      nom: 'Corse (Acheminement maritime + logistique insulaire)',
      prefixes: ['20'],
      supplement_euros: 85.0,
      devis_manuel_obligatoire: false,
    },
    {
      id: 'z-dom-tom',
      nom: 'Départements et Territoires d’Outre-Mer (DOM-TOM)',
      prefixes: ['97', '98'],
      supplement_euros: 0,
      devis_manuel_obligatoire: true,
    },
  ],
  distance_maximale_automatique: 1200,
  adresse_entrepot: '26-36 rue Alfred Nobel, 93600 Aulnay-sous-Bois, France',
  devise: 'EUR',
  regles_arrondi: '2_decimales',

  // Backward compatibility
  baseFee: 106.0,
  remoteFeeSupplement: 85.0,
  remotePostalPrefixes: ['20', '04', '05', '06', '09', '15', '48', '65', '73', '74'],
  remoteDistanceThresholdKm: 600,
  palletUnitPrice: 350,
  supportedCountries: ['France métropolitaine', 'Monaco'],
};

// Known coordinates for fast lookup / fallbacks (H DESTOCKAGE - Aulnay-sous-Bois Hub)
const WAREHOUSE_COORDS = { lat: 48.947555, lon: 2.477389 };
const GOOGLE_MAPS_API_KEY =
  (typeof process !== 'undefined' && process.env?.GOOGLE_MAPS_API_KEY) ||
  'AIzaSyBwW875o0Y0g6nVLKZNJeSnHOE6-Xpfndw';

// Approximate department centers in France for reliable calculation when external APIs are slow
const DEPT_COORDINATES: Record<string, { lat: number; lon: number }> = {
  '01': { lat: 46.2, lon: 5.2 },
  '02': { lat: 49.5, lon: 3.6 },
  '03': { lat: 46.5, lon: 3.3 },
  '04': { lat: 44.1, lon: 6.2 },
  '05': { lat: 44.6, lon: 6.1 },
  '06': { lat: 43.7, lon: 7.2 },
  '07': { lat: 44.7, lon: 4.6 },
  '08': { lat: 49.7, lon: 4.7 },
  '09': { lat: 42.9, lon: 1.6 },
  '10': { lat: 48.3, lon: 4.1 },
  '11': { lat: 43.2, lon: 2.3 },
  '12': { lat: 44.3, lon: 2.6 },
  '13': { lat: 43.3, lon: 5.4 },
  '14': { lat: 49.2, lon: -0.4 },
  '15': { lat: 45.0, lon: 2.7 },
  '16': { lat: 45.6, lon: 0.2 },
  '17': { lat: 45.7, lon: -0.6 },
  '18': { lat: 47.1, lon: 2.4 },
  '19': { lat: 45.3, lon: 1.9 },
  '20': { lat: 42.0, lon: 9.1 },
  '21': { lat: 47.3, lon: 5.0 },
  '22': { lat: 48.5, lon: -2.8 },
  '23': { lat: 46.2, lon: 2.0 },
  '24': { lat: 45.2, lon: 0.7 },
  '25': { lat: 47.2, lon: 6.0 },
  '26': { lat: 44.9, lon: 5.0 },
  '27': { lat: 49.0, lon: 1.1 },
  '28': { lat: 48.4, lon: 1.5 },
  '29': { lat: 48.2, lon: -4.1 },
  '30': { lat: 43.8, lon: 4.4 },
  '31': { lat: 43.6, lon: 1.4 },
  '32': { lat: 43.6, lon: 0.6 },
  '33': { lat: 44.8, lon: -0.6 },
  '34': { lat: 43.6, lon: 3.9 },
  '35': { lat: 48.1, lon: -1.7 },
  '36': { lat: 46.8, lon: 1.7 },
  '37': { lat: 47.4, lon: 0.7 },
  '38': { lat: 45.2, lon: 5.7 },
  '39': { lat: 46.7, lon: 5.6 },
  '40': { lat: 43.9, lon: -0.9 },
  '41': { lat: 47.6, lon: 1.3 },
  '42': { lat: 45.4, lon: 4.4 },
  '43': { lat: 45.0, lon: 3.9 },
  '44': { lat: 47.2, lon: -1.5 },
  '45': { lat: 47.9, lon: 1.9 },
  '46': { lat: 44.4, lon: 1.4 },
  '47': { lat: 44.2, lon: 0.6 },
  '48': { lat: 44.5, lon: 3.5 },
  '49': { lat: 47.5, lon: -0.5 },
  '50': { lat: 49.1, lon: -1.3 },
  '51': { lat: 49.0, lon: 4.0 },
  '52': { lat: 48.1, lon: 5.1 },
  '53': { lat: 48.1, lon: -0.8 },
  '54': { lat: 48.7, lon: 6.2 },
  '55': { lat: 49.1, lon: 5.4 },
  '56': { lat: 47.7, lon: -2.8 },
  '57': { lat: 49.1, lon: 6.2 },
  '58': { lat: 47.0, lon: 3.1 },
  '59': { lat: 50.6, lon: 3.1 },
  '60': { lat: 49.4, lon: 2.1 },
  '61': { lat: 48.4, lon: 0.1 },
  '62': { lat: 50.5, lon: 2.6 },
  '63': { lat: 45.8, lon: 3.1 },
  '64': { lat: 43.3, lon: -0.4 },
  '65': { lat: 43.2, lon: 0.1 },
  '66': { lat: 42.7, lon: 2.9 },
  '67': { lat: 48.6, lon: 7.7 },
  '68': { lat: 47.7, lon: 7.3 },
  '69': { lat: 45.7, lon: 4.8 },
  '70': { lat: 47.6, lon: 6.1 },
  '71': { lat: 46.8, lon: 4.8 },
  '72': { lat: 48.0, lon: 0.2 },
  '73': { lat: 45.6, lon: 5.9 },
  '74': { lat: 46.0, lon: 6.2 },
  '75': { lat: 48.85, lon: 2.35 },
  '76': { lat: 49.4, lon: 1.1 },
  '77': { lat: 48.5, lon: 2.6 },
  '78': { lat: 48.8, lon: 2.1 },
  '79': { lat: 46.3, lon: -0.5 },
  '80': { lat: 49.9, lon: 2.3 },
  '81': { lat: 43.9, lon: 2.1 },
  '82': { lat: 44.0, lon: 1.3 },
  '83': { lat: 43.1, lon: 5.9 },
  '84': { lat: 43.9, lon: 4.8 },
  '85': { lat: 46.7, lon: -1.4 },
  '86': { lat: 46.6, lon: 0.3 },
  '87': { lat: 45.8, lon: 1.2 },
  '88': { lat: 48.2, lon: 6.5 },
  '89': { lat: 47.8, lon: 3.6 },
  '90': { lat: 47.6, lon: 6.8 },
  '91': { lat: 48.6, lon: 2.4 },
  '92': { lat: 48.9, lon: 2.2 },
  '93': { lat: 48.9, lon: 2.4 },
  '94': { lat: 48.8, lon: 2.5 },
  '95': { lat: 49.0, lon: 2.1 },
};

/**
 * Calcul de la distance géodésique Haversine (km)
 */
function haversineDistance(
  coords1: { lat: number; lon: number },
  coords2: { lat: number; lon: number }
): number {
  const R = 6371; // Rayon de la Terre en km
  const dLat = ((coords2.lat - coords1.lat) * Math.PI) / 180;
  const dLon = ((coords2.lon - coords1.lon) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((coords1.lat * Math.PI) / 180) *
      Math.cos((coords2.lat * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Recherche de tranche ordonnée selon le pseudo-code exact
 */
export function trouver_la_tranche(
  distance_km: number,
  tranches: DistanceTranche[]
): DistanceTranche | null {
  // Tri par distance minimale croissante
  const tranches_triees = [...tranches].sort(
    (a, b) => a.distance_min_km - b.distance_min_km
  );

  for (const tranche of tranches_triees) {
    const distance_min = tranche.distance_min_km;
    const distance_max = tranche.distance_max_km;

    if (
      distance_km >= distance_min &&
      (distance_max === null || distance_km <= distance_max)
    ) {
      return tranche;
    }
  }

  return null;
}

/**
 * Fonction standard de résultat devis manuel
 */
export function resultat_devis_manuel(
  motif: string,
  distance_km: number | null = null,
  adresse_depart: string = DEFAULT_SHIPPING_CONFIG.adresse_entrepot,
  adresse_destination: string = ''
): CalculLivraisonResultat {
  return {
    statut: 'devis_manuel_requis',
    motif: motif,
    distance_routiere_km: distance_km ? Math.round(distance_km * 100) / 100 : null,
    frais_livraison: null,
    tarif_verrouille: false,
    adresse_depart,
    adresse_destination,
    devise: 'EUR',
    message_client:
      'Votre destination nécessite une estimation personnalisée. H DESTOCKAGE vous communiquera les frais de livraison définitifs.',
  };
}

/**
 * Géocodage et calcul de distance routière réelle
 * Utilise Google Routes API v2 prioritairement, avec repli OpenStreetMap Nominatim + OSRM
 */
export async function geocoderEtCalculerDistanceRoutiere(
  depart: string,
  destination: {
    deliveryAddress: string;
    postalCode: string;
    city: string;
    country: string;
    latitude?: number;
    longitude?: number;
  }
): Promise<{
  distance_routiere_km: number | null;
  destination_reconnue?: string;
  isGeocoded: boolean;
}> {
  const cleanCode = (destination.postalCode || '').trim();
  const cleanCity = (destination.city || '').trim();
  const cleanAddress = (destination.deliveryAddress || '').trim();
  const cleanCountry = (destination.country || 'France').trim();

  // Depart coords (H DESTOCKAGE - Aulnay-sous-Bois warehouse)
  const startCoords = WAREHOUSE_COORDS;
  const startAddress = '26-36 rue Alfred Nobel, 93600 Aulnay-sous-Bois, France';

  let recognizedName = `${cleanAddress ? cleanAddress + ', ' : ''}${cleanCode} ${cleanCity}, ${cleanCountry}`.trim();

  // 1. Priorité absolue : Google Routes API v2 si clé disponible
  if (GOOGLE_MAPS_API_KEY) {
    try {
      const destinationPayload =
        typeof destination.latitude === 'number' && typeof destination.longitude === 'number'
          ? {
              location: {
                latLng: {
                  latitude: destination.latitude,
                  longitude: destination.longitude,
                },
              },
            }
          : {
              address: recognizedName,
            };

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4500);

      const gRes = await fetch('https://routes.googleapis.com/directions/v2:computeRoutes', {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': GOOGLE_MAPS_API_KEY,
          'X-Goog-FieldMask': 'routes.duration,routes.distanceMeters',
          'X-Goog-Maps-Solution-ID': 'gmp_git_agentskills_v1',
        },
        body: JSON.stringify({
          origin: { address: startAddress },
          destination: destinationPayload,
          travelMode: 'DRIVE',
        }),
      });
      clearTimeout(timeoutId);

      if (gRes.ok) {
        const gData = await gRes.json();
        if (gData.routes && gData.routes.length > 0 && typeof gData.routes[0].distanceMeters === 'number') {
          const roadKm = Math.round((gData.routes[0].distanceMeters / 1000) * 100) / 100;
          return {
            distance_routiere_km: roadKm,
            destination_reconnue: recognizedName,
            isGeocoded: true,
          };
        }
      }
    } catch {
      // Poursuite vers le repli OSRM / Haversine
    }
  }

  let endCoords: { lat: number; lon: number } | null = null;
  if (typeof destination.latitude === 'number' && typeof destination.longitude === 'number') {
    endCoords = { lat: destination.latitude, lon: destination.longitude };
  }

  // 1. Tenter l'API Nominatim
  try {
    const query = encodeURIComponent(
      `${cleanAddress} ${cleanCode} ${cleanCity} ${cleanCountry}`.trim()
    );
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const res = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${query}&countrycodes=fr,mc&limit=1`,
      {
        signal: controller.signal,
        headers: {
          'Accept-Language': 'fr-FR,fr',
          'User-Agent': 'HDestockage-Logistics/1.0',
        },
      }
    );
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0 && data[0].lat && data[0].lon) {
        endCoords = {
          lat: parseFloat(data[0].lat),
          lon: parseFloat(data[0].lon),
        };
        recognizedName = data[0].display_name;
      }
    }
  } catch {
    // Ignoré - repli ci-dessous
  }

  // 2. Si non trouvé ou timeout, repli par code postal / département
  if (!endCoords && cleanCode.length >= 2) {
    const deptPrefix = cleanCode.substring(0, 2);
    if (DEPT_COORDINATES[deptPrefix]) {
      endCoords = DEPT_COORDINATES[deptPrefix];
      recognizedName = `${cleanCode} ${cleanCity}, France`;
    }
  }

  if (!endCoords) {
    return {
      distance_routiere_km: null,
      destination_reconnue: recognizedName,
      isGeocoded: false,
    };
  }

  // 3. Calcul de distance routière réelle via OSRM
  let roadDistanceKm: number | null = null;
  try {
    const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${startCoords.lon},${startCoords.lat};${endCoords.lon},${endCoords.lat}?overview=false`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    const osrmRes = await fetch(osrmUrl, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (osrmRes.ok) {
      const osrmData = await osrmRes.json();
      if (osrmData.routes && osrmData.routes.length > 0 && osrmData.routes[0].distance) {
        // Distance en mètres convertie en kilomètres
        roadDistanceKm = Math.round((osrmData.routes[0].distance / 1000) * 100) / 100;
      }
    }
  } catch {
    // Ignoré - repli avec coefficient de tortuosité
  }

  // 4. Si OSRM n'a pas répondu à temps, appliquer la formule avec tortuosité routière autoroutière (1.28)
  if (roadDistanceKm === null) {
    const birdDistance = haversineDistance(startCoords, endCoords);
    // Coefficient moyen routier en France métropolitaine : 1.28
    const estimatedRoad = birdDistance * 1.28;
    roadDistanceKm = Math.round(estimatedRoad * 100) / 100;
  }

  return {
    distance_routiere_km: roadDistanceKm,
    destination_reconnue: recognizedName,
    isGeocoded: true,
  };
}

/**
 * Calcul des suppléments de zone selon le pseudo-code exact
 */
export function calculer_supplements_zones(
  postalCode: string,
  configuration: ShippingConfig
): { supplement: number; requiresManualQuote: boolean; zoneName?: string } {
  const cleanCode = (postalCode || '').trim();
  const zones = configuration.zones_difficiles_acces || [];

  for (const zone of zones) {
    const matches = zone.prefixes.some((prefix) => cleanCode.startsWith(prefix.trim()));
    if (matches) {
      return {
        supplement: zone.supplement_euros || 0,
        requiresManualQuote: Boolean(zone.devis_manuel_obligatoire),
        zoneName: zone.nom,
      };
    }
  }

  return { supplement: 0, requiresManualQuote: false };
}

/**
 * IMPLÉMENTATION STRICTE DU PSEUDO-CODE
 * fonction calculer_frais_livraison(adresse_client, configuration)
 */
export function calculer_frais_livraison_synchrone(
  adresse_client: {
    deliveryAddress?: string;
    postalCode?: string;
    city?: string;
    country?: string;
  },
  configuration: ShippingConfig,
  distance_routiere_km_fournie: number | null,
  destination_reconnue_fournie?: string,
  geocodingFailed: boolean = false
): CalculLivraisonResultat {
  let tarif_minimum = configuration.tarif_minimum;
  if (!tarif_minimum || isNaN(tarif_minimum)) {
    tarif_minimum = CONSTANTE_TARIF_MINIMUM_DEFAUT;
  }
  if (tarif_minimum < 106.0) {
    tarif_minimum = 106.0;
  }

  const clientAddressStr = `${adresse_client.deliveryAddress || ''} ${adresse_client.postalCode || ''} ${adresse_client.city || ''} ${adresse_client.country || ''}`.trim();
  const adresse_entrepot = configuration.adresse_entrepot || DEFAULT_SHIPPING_CONFIG.adresse_entrepot;

  // Si adresse client incomplète
  if (
    !adresse_client.deliveryAddress ||
    !adresse_client.postalCode ||
    !adresse_client.city
  ) {
    return resultat_devis_manuel(
      'Adresse client incomplète',
      null,
      adresse_entrepot,
      clientAddressStr
    );
  }

  // Si adresse entrepôt absente
  if (!adresse_entrepot || !adresse_entrepot.trim()) {
    return resultat_devis_manuel(
      'Adresse de départ non configurée',
      null,
      adresse_entrepot,
      clientAddressStr
    );
  }

  // Si géocodage a échoué
  if (geocodingFailed || distance_routiere_km_fournie === null) {
    return resultat_devis_manuel(
      'Adresse non reconnue',
      null,
      adresse_entrepot,
      clientAddressStr
    );
  }

  let distance_routiere_km = Math.round(distance_routiere_km_fournie * 100) / 100;

  // Si distance maximale automatique dépassée
  if (
    configuration.distance_maximale_automatique &&
    distance_routiere_km > configuration.distance_maximale_automatique
  ) {
    return resultat_devis_manuel(
      'Destination au-delà de la distance automatique',
      distance_routiere_km,
      adresse_entrepot,
      clientAddressStr
    );
  }

  const distance_incluse_km = configuration.distance_incluse_km;
  if (distance_incluse_km === undefined || distance_incluse_km < 0) {
    return resultat_devis_manuel(
      'Distance incluse mal configurée',
      distance_routiere_km,
      adresse_entrepot,
      clientAddressStr
    );
  }

  let supplement_distance = 0.0;
  const mode_calcul = configuration.mode_calcul;

  if (distance_routiere_km <= distance_incluse_km) {
    supplement_distance = 0.0;
  } else if (mode_calcul === 'tranches') {
    const tranches = configuration.tranches_distance;
    if (!tranches || tranches.length === 0) {
      return resultat_devis_manuel(
        'Aucune tranche de distance configurée',
        distance_routiere_km,
        adresse_entrepot,
        clientAddressStr
      );
    }

    const tranche_trouvee = trouver_la_tranche(distance_routiere_km, tranches);
    if (!tranche_trouvee) {
      return resultat_devis_manuel(
        'Aucune tranche applicable',
        distance_routiere_km,
        adresse_entrepot,
        clientAddressStr
      );
    }

    if (tranche_trouvee.devis_manuel_obligatoire) {
      return resultat_devis_manuel(
        'Devis manuel requis pour cette tranche',
        distance_routiere_km,
        adresse_entrepot,
        clientAddressStr
      );
    }

    supplement_distance = tranche_trouvee.supplement_euros;
  } else if (mode_calcul === 'kilometres_supplementaires') {
    const tarif_par_km = configuration.tarif_par_km_supplementaire;
    if (tarif_par_km === undefined || tarif_par_km < 0) {
      return resultat_devis_manuel(
        'Tarif par kilomètre mal configuré',
        distance_routiere_km,
        adresse_entrepot,
        clientAddressStr
      );
    }

    const kilometres_supplementaires = distance_routiere_km - distance_incluse_km;
    supplement_distance = kilometres_supplementaires * tarif_par_km;
  } else {
    return resultat_devis_manuel(
      'Mode de calcul inconnu',
      distance_routiere_km,
      adresse_entrepot,
      clientAddressStr
    );
  }

  const zoneResult = calculer_supplements_zones(
    adresse_client.postalCode || '',
    configuration
  );

  if (zoneResult.requiresManualQuote) {
    return resultat_devis_manuel(
      'Zone difficile d’accès',
      distance_routiere_km,
      adresse_entrepot,
      clientAddressStr
    );
  }

  const supplement_zones = zoneResult.supplement;

  let frais_livraison = tarif_minimum + supplement_distance + supplement_zones;

  // Aucune livraison automatique ne doit être facturée à moins de 106 €
  if (frais_livraison < 106.0) {
    frais_livraison = 106.0;
  }

  frais_livraison = Math.round(frais_livraison * 100) / 100;

  return {
    statut: 'tarif_automatique',
    adresse_depart: adresse_entrepot,
    adresse_destination: clientAddressStr,
    destination_reconnue: destination_reconnue_fournie || clientAddressStr,
    distance_routiere_km: distance_routiere_km,
    distance_incluse_km: distance_incluse_km,
    tarif_minimum: tarif_minimum,
    supplement_distance: Math.round(supplement_distance * 100) / 100,
    supplement_zones: Math.round(supplement_zones * 100) / 100,
    frais_livraison: frais_livraison,
    tarif_verrouille: true,
    devise: 'EUR',
  };
}

/**
 * Calcul complet asynchrone (géocodage + calcul routier + pseudo-code)
 */
export async function calculer_frais_livraison(
  adresse_client: {
    deliveryAddress: string;
    postalCode: string;
    city: string;
    country: string;
    latitude?: number;
    longitude?: number;
  },
  configuration: ShippingConfig
): Promise<CalculLivraisonResultat> {
  const adresse_entrepot = configuration.adresse_entrepot || DEFAULT_SHIPPING_CONFIG.adresse_entrepot;

  if (
    !adresse_client.deliveryAddress ||
    !adresse_client.postalCode ||
    !adresse_client.city
  ) {
    return resultat_devis_manuel(
      'Adresse client incomplète',
      null,
      adresse_entrepot,
      `${adresse_client.deliveryAddress || ''} ${adresse_client.postalCode || ''} ${adresse_client.city || ''}`.trim()
    );
  }

  // 1. Appel du serveur si disponible ou géocodage direct
  try {
    const routeRes = await geocoderEtCalculerDistanceRoutiere(
      adresse_entrepot,
      adresse_client
    );

    return calculer_frais_livraison_synchrone(
      adresse_client,
      configuration,
      routeRes.distance_routiere_km,
      routeRes.destination_reconnue,
      !routeRes.isGeocoded
    );
  } catch {
    return resultat_devis_manuel(
      'Distance routière indisponible',
      null,
      adresse_entrepot,
      `${adresse_client.deliveryAddress} ${adresse_client.postalCode} ${adresse_client.city}`
    );
  }
}

export const calculerFraisLivraisonClient = calculer_frais_livraison;
