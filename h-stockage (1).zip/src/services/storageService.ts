import {
  SneakerModel,
  Brand,
  SelectionItem,
  InquiryRequest,
  ClientProfile,
  WatermarkSettings,
  ClientSession,
} from '../types';
import {
  INITIAL_BRANDS,
  INITIAL_PRODUCTS,
  INITIAL_CLIENTS,
  INITIAL_REQUESTS,
} from '../data/catalogData';
import { db } from './firebase';
import { doc, setDoc, getDocs, collection } from 'firebase/firestore';

const KEYS = {
  PRODUCTS: 'hdestockage_products_v2',
  BRANDS: 'hdestockage_brands_v2',
  SELECTION: 'hdestockage_selection_v2',
  REQUESTS: 'hdestockage_requests_v2',
  CLIENTS: 'hdestockage_clients_v2',
  WATERMARK: 'hdestockage_watermark_v2',
  SESSION: 'hdestockage_session_v2',
};

// --- PRODUCTS ---
export function getStoredProducts(): SneakerModel[] {
  try {
    const data = localStorage.getItem(KEYS.PRODUCTS);
    let list: SneakerModel[] = data ? JSON.parse(data) : INITIAL_PRODUCTS;
    
    // If the stored data was empty array but we now have initial products, initialize with initial products
    if (list.length === 0 && INITIAL_PRODUCTS.length > 0) {
      list = INITIAL_PRODUCTS;
      localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(list));
    }

    // Sanitize list: filter out Nike Shox TL / Shox models permanently
    const initialMap = new Map(INITIAL_PRODUCTS.map((ip) => [ip.id, ip]));
    let hasPriceUpdate = false;

    const filtered = list
      .filter(
        (p) =>
          p.id !== 'prod-shox-tl' &&
          !p.name.toLowerCase().includes('shox') &&
          p.brand.toLowerCase() !== 'shox'
      )
      .map((p) => {
        const init = initialMap.get(p.id);
        if (init && p.price === undefined && init.price !== undefined) {
          hasPriceUpdate = true;
          return { ...p, price: init.price, dateAdded: p.dateAdded === '2026-08-13' ? init.dateAdded : p.dateAdded };
        }
        return p;
      });

    if (filtered.length !== list.length || hasPriceUpdate) {
      localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(filtered));
    }

    return filtered;
  } catch {
    return INITIAL_PRODUCTS.filter(
      (p) =>
        p.id !== 'prod-shox-tl' &&
        !p.name.toLowerCase().includes('shox') &&
        p.brand.toLowerCase() !== 'shox'
    );
  }
}

export function saveProducts(products: SneakerModel[]): void {
  localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
  // Persist to real Firestore collection
  try {
    products.forEach((p) => {
      setDoc(doc(db, 'products', p.id), p).catch(() => {});
    });
  } catch {}
}

export async function fetchProductsFromFirestore(): Promise<SneakerModel[] | null> {
  try {
    const snap = await getDocs(collection(db, 'products'));
    if (!snap.empty) {
      const list: SneakerModel[] = [];
      snap.forEach((d) => {
        list.push(d.data() as SneakerModel);
      });
      if (list.length > 0) {
        localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(list));
        return list;
      }
    }
    return null;
  } catch {
    return null;
  }
}

export function normalizeBrandKey(nameOrId: string): string {
  const clean = nameOrId.toLowerCase().trim().replace(/[^a-z0-9]/g, '');
  if (clean === 'asics') return 'asics';
  if (clean === 'on' || clean === 'onrunning') return 'on';
  if (clean === 'hoka' || clean === 'hokaoneone') return 'hoka';
  if (clean === 'newbalance' || clean === 'nb') return 'new-balance';
  return clean;
}

// --- BRANDS ---
export function getStoredBrands(): Brand[] {
  try {
    const data = localStorage.getItem(KEYS.BRANDS);
    let rawBrands: Brand[] = data ? JSON.parse(data) : INITIAL_BRANDS;

    // Deduplication & normalization map
    const brandsMap = new Map<string, Brand>();

    // Seed with INITIAL_BRANDS first
    INITIAL_BRANDS.forEach((initB) => {
      const key = normalizeBrandKey(initB.id || initB.name);
      brandsMap.set(key, { ...initB });
    });

    // Merge stored brands without creating duplicates
    if (Array.isArray(rawBrands)) {
      rawBrands.forEach((b) => {
        if (!b || !b.name) return;
        const key = normalizeBrandKey(b.id || b.name);
        if (key === 'shox') return; // exclude shox permanently
        if (brandsMap.has(key)) {
          // Merge preserving real images or updates
          const existing = brandsMap.get(key)!;
          brandsMap.set(key, {
            ...existing,
            ...b,
            id: existing.id,
            name: existing.name,
            slug: existing.slug || key,
            models: existing.models.length > 0 ? existing.models : (b.models || []),
          });
        } else {
          brandsMap.set(key, {
            id: b.id || key,
            name: b.name,
            slug: b.slug || key,
            image: b.image,
            coverImage: b.coverImage,
            description: b.description || '',
            status: b.status || 'Active',
            order: b.order || (brandsMap.size + 1),
            models: b.models || [],
          });
        }
      });
    }

    const merged = Array.from(brandsMap.values())
      .filter((b) => b.id !== 'shox' && b.name.toLowerCase() !== 'shox')
      .sort((a, b) => a.order - b.order);

    localStorage.setItem(KEYS.BRANDS, JSON.stringify(merged));
    return merged;
  } catch {
    return INITIAL_BRANDS.filter((b) => b.id !== 'shox' && b.name.toLowerCase() !== 'shox');
  }
}

export function saveBrands(brands: Brand[]): void {
  const filtered = brands.filter((b) => b.id !== 'shox' && b.name.toLowerCase() !== 'shox');
  localStorage.setItem(KEYS.BRANDS, JSON.stringify(filtered));
  try {
    filtered.forEach((b) => {
      setDoc(doc(db, 'brands', b.id), b).catch(() => {});
    });
  } catch {}
}

export async function fetchBrandsFromFirestore(): Promise<Brand[] | null> {
  try {
    const snap = await getDocs(collection(db, 'brands'));
    if (!snap.empty) {
      const list: Brand[] = [];
      snap.forEach((d) => {
        list.push(d.data() as Brand);
      });
      if (list.length > 0) {
        localStorage.setItem(KEYS.BRANDS, JSON.stringify(list));
        return list;
      }
    }
    return null;
  } catch {
    return null;
  }
}

// --- SELECTION (MA SELECTION) ---
export function getStoredSelection(): SelectionItem[] {
  try {
    const data = localStorage.getItem(KEYS.SELECTION);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveSelection(selection: SelectionItem[]): void {
  localStorage.setItem(KEYS.SELECTION, JSON.stringify(selection));
}

// --- INQUIRY REQUESTS ---
export function getStoredRequests(): InquiryRequest[] {
  try {
    const data = localStorage.getItem(KEYS.REQUESTS);
    return data ? JSON.parse(data) : INITIAL_REQUESTS;
  } catch {
    return INITIAL_REQUESTS;
  }
}

export function saveRequests(requests: InquiryRequest[]): void {
  localStorage.setItem(KEYS.REQUESTS, JSON.stringify(requests));
  try {
    requests.forEach((r) => {
      setDoc(doc(db, 'inquiries', r.id), r).catch(() => {});
    });
  } catch {}
}

export function addInquiryRequest(reqData: Omit<InquiryRequest, 'id' | 'date' | 'status'>): InquiryRequest {
  const requests = getStoredRequests();
  const newReq: InquiryRequest = {
    ...reqData,
    id: `req-${Date.now().toString().slice(-6)}`,
    date: new Date().toLocaleString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }),
    status: 'Nouvelle',
  };
  const updated = [newReq, ...requests];
  saveRequests(updated);

  // Firestore sync
  try {
    setDoc(doc(db, 'inquiries', newReq.id), newReq).catch(() => {});
  } catch {}

  // Update client last activity if client exists
  const clients = getStoredClients();
  const existingClient = clients.find(c => c.email.toLowerCase() === reqData.email.toLowerCase());
  if (existingClient) {
    existingClient.lastRequestDate = newReq.date;
    existingClient.lastActivity = newReq.date;
    existingClient.status = existingClient.status === 'Prospect' ? 'Demande reçue' : existingClient.status;
    saveClients(clients);
  } else {
    // Auto-create prospect client
    const newClient: ClientProfile = {
      id: `cli-${Date.now().toString().slice(-4)}`,
      name: reqData.clientName,
      email: reqData.email,
      phone: reqData.phone,
      company: reqData.company || '',
      accessCode: `DESTOCK-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      status: 'Demande reçue',
      createdAt: newReq.date,
      lastActivity: newReq.date,
      selectionCount: reqData.items.length,
      lastRequestDate: newReq.date,
    };
    saveClients([newClient, ...clients]);
  }

  return newReq;
}

// --- CLIENT PROFILES ---
export function getStoredClients(): ClientProfile[] {
  try {
    const data = localStorage.getItem(KEYS.CLIENTS);
    return data ? JSON.parse(data) : INITIAL_CLIENTS;
  } catch {
    return INITIAL_CLIENTS;
  }
}

export function saveClients(clients: ClientProfile[]): void {
  localStorage.setItem(KEYS.CLIENTS, JSON.stringify(clients));
}

// --- WATERMARK SETTINGS ---
export function getStoredWatermark(): WatermarkSettings {
  try {
    const data = localStorage.getItem(KEYS.WATERMARK);
    return data
      ? JSON.parse(data)
      : {
          text: 'H DESTOCKAGE',
          opacity: 0.25,
          enabled: true,
          clientWatermarkText: '',
        };
  } catch {
    return {
      text: 'H DESTOCKAGE',
      opacity: 0.25,
      enabled: true,
    };
  }
}

export function saveWatermark(settings: WatermarkSettings): void {
  localStorage.setItem(KEYS.WATERMARK, JSON.stringify(settings));
}

// --- SESSION ---
export function getStoredSession(): ClientSession | null {
  try {
    const data = localStorage.getItem(KEYS.SESSION);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function saveSession(session: ClientSession | null): void {
  if (!session) {
    localStorage.removeItem(KEYS.SESSION);
  } else {
    localStorage.setItem(KEYS.SESSION, JSON.stringify(session));
  }
}

// Reset to initial defaults
export function resetAllDataToDefaults(): void {
  localStorage.removeItem(KEYS.PRODUCTS);
  localStorage.removeItem(KEYS.BRANDS);
  localStorage.removeItem(KEYS.SELECTION);
  localStorage.removeItem(KEYS.REQUESTS);
  localStorage.removeItem(KEYS.CLIENTS);
  localStorage.removeItem(KEYS.WATERMARK);
  localStorage.removeItem(KEYS.SESSION);
}
