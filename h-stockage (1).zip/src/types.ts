export type AvailabilityStatus = 'Disponible' | 'Épuisé' | 'MASQUÉ' | 'Nouveau' | 'Indisponible';

export interface SneakerModel {
  id: string;
  brand: string;
  name: string;
  images: string[];
  availableSizes: number[];
  status: AvailabilityStatus;
  description: string;
  batchInfo?: string;
  dateAdded: string;
  lastModifiedDate?: string;
  featured?: boolean;
  price?: number; // Prix indicatif grossiste HT
}

export type ProductSortOption =
  | 'newest'
  | 'price-asc'
  | 'price-desc'
  | 'brand-asc'
  | 'brand-desc'
  | 'name-asc';

export interface Brand {
  id: string;
  name: string;
  slug: string;
  image?: string;
  coverImage?: string;
  description: string;
  status: 'Active' | 'Inactive';
  order: number;
  models: string[];
}

export interface SelectionItem {
  productId: string;
  product: SneakerModel;
  selectedSizes: number[];
  palletCount?: number; // Minimum 1 palette (100 paires = 350 €)
  notes?: string;
}

export interface InquiryRequest {
  id: string;
  clientName: string;
  email: string;
  phone: string;
  company?: string;
  items: {
    productId: string;
    name: string;
    brand: string;
    sizes: number[];
  }[];
  message?: string;
  status: 'Nouvelle' | 'En cours' | 'Traitée' | 'Archivée';
  date: string;
  clientId?: string;
}

export type ClientStatus = 'Prospect' | 'Demande reçue' | 'Client' | 'Accès suspendu';

export interface ClientProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  accessCode: string;
  status: ClientStatus;
  createdAt: string;
  lastActivity: string;
  selectionCount: number;
  lastRequestDate?: string;
  visitsCount?: number;
  viewsCount?: number;
  whatsappClicksCount?: number;
  viewedProducts?: string[];
}

export interface WatermarkSettings {
  text: string;
  opacity: number;
  enabled: boolean;
  clientWatermarkText?: string;
}

export interface ClientSession {
  accessCode?: string;
  clientName?: string;
  email?: string;
  company?: string;
  phone?: string;
  isAuthenticated: boolean;
  loginTime: string;
}

export interface FilterState {
  searchQuery: string;
  selectedBrand: string;
  selectedSize: number | null;
  statusFilter: AvailabilityStatus | 'Tous';
}

export type ActiveTab = 'home' | 'collection' | 'brands' | 'selection' | 'tracking' | 'admin' | 'access';

export type OrderStatus =
  | 'En attente de paiement'
  | 'Paiement envoyé par le client'
  | 'Paiement en cours de vérification'
  | 'Paiement confirmé'
  | 'Commande en préparation'
  | 'Commande expédiée'
  | 'Commande livrée'
  | 'Commande annulée'
  | 'Livraison en attente de devis'
  | 'Commande créée'
  | 'Justificatif reçu'
  | 'Expédiée'
  | 'Livrée'
  | 'Paiement refusé ou justificatif invalide';

export interface MixedPalletLot {
  lotIndex: 1 | 2 | 3 | 4;
  brand: string;
  model: string;
  pairCount: 25;
  productId?: string;
  photo?: string;
}

export interface ConfiguredPallet {
  id: string;
  mode: 'SINGLE_MODEL' | 'MIXED';
  singleProduct: SneakerModel;
  selectedSizes: number[];
  lots: [
    SneakerModel | null,
    SneakerModel | null,
    SneakerModel | null,
    SneakerModel | null
  ];
}

export interface PalletCartItem {
  id: string;
  brand: string;
  model: string;
  productId?: string;
  photo: string;
  palletCount: number;
  pairCount: number; // palletCount * 100
  palletPrice: number; // 350
  subtotal: number; // palletCount * 350
  palletType?: 'SINGLE_MODEL' | 'MIXED';
  mixedLots?: MixedPalletLot[];
}

export interface PalletOrderCustomer {
  firstName: string;
  lastName: string;
  phone: string;
  whatsapp: string;
  email: string;
  deliveryAddress: string;
  postalCode: string;
  city: string;
  country: string;
  company?: string;
  deliveryInstructions?: string;
  dataProcessingConsent: boolean;
  // Google Maps Location attributes
  confirmedAddress?: string;
  latitude?: number;
  longitude?: number;
  placeId?: string;
  geocodedCity?: string;
  geocodedPostalCode?: string;
  roadDistanceKm?: number;
}

export interface DistanceTranche {
  id: string;
  distance_min_km: number;
  distance_max_km: number | null;
  supplement_euros: number;
  devis_manuel_obligatoire: boolean;
}

export interface ZoneDifficileAcces {
  id: string;
  nom: string;
  prefixes: string[]; // e.g. ['20'] for Corse
  supplement_euros: number;
  devis_manuel_obligatoire: boolean;
}

export interface ShippingConfig {
  // Base configuration
  tarif_minimum: number; // 106.00 € minimum for France métropolitaine
  distance_incluse_km: number; // distance included in base rate (e.g. 50 km)
  mode_calcul: 'tranches' | 'kilometres_supplementaires';
  tranches_distance: DistanceTranche[];
  tarif_par_km_supplementaire: number; // if mode is kilometres_supplementaires (e.g. 0.35 €/km)
  zones_difficiles_acces: ZoneDifficileAcces[];
  distance_maximale_automatique: number; // e.g. 1000 km, above which quote is manual
  adresse_entrepot: string; // real warehouse departure address
  devise: string; // 'EUR'
  regles_arrondi: string; // '2_decimales'

  // Backward compatibility fields
  baseFee: number; // mapped to tarif_minimum
  remoteFeeSupplement: number;
  remotePostalPrefixes: string[];
  remoteDistanceThresholdKm: number;
  palletUnitPrice: number; // default: 350 €
  supportedCountries: string[];
}

export interface CalculLivraisonResultat {
  statut: 'tarif_automatique' | 'devis_manuel_requis';
  motif?: string;
  adresse_depart: string;
  adresse_destination: string;
  destination_reconnue?: string;
  distance_routiere_km: number | null;
  distance_incluse_km?: number;
  tarif_minimum?: number;
  supplement_distance?: number;
  supplement_zones?: number;
  frais_livraison: number | null;
  tarif_verrouille: boolean;
  message_client?: string;
  devise: string;
}

export interface PaymentProof {
  uploadedAt: string;
  paymentMethod: 'Virement bancaire SEPA' | 'Dépôt en agence bancaire' | 'Autre';
  senderName: string;
  transactionReference: string;
  paymentDate: string;
  paidAmount: number;
  fileName: string;
  fileData: string; // Base64 data URL or storage URL
  fileType: string;
}

export interface OrderStatusHistoryEntry {
  timestamp: string;
  status: OrderStatus;
  note?: string;
}

export interface PalletComposition {
  palletNumber: number;
  type: 'SINGLE_MODEL' | 'MIXED';
  brand?: string;
  model?: string;
  productId?: string;
  photo?: string;
  totalPairs: number; // 100
  price: number; // 350
  mixedLots?: MixedPalletLot[];
}

export interface PalletOrder {
  id: string; // e.g. CMD-HD-2026-XXXX
  createdAt: string;
  formattedDate: string;
  palletCount: number;
  totalPairs?: number;
  pairCount?: number;
  items?: PalletCartItem[];
  palletsComposition?: PalletComposition[];
  brands?: string[];
  models?: string[];
  brand?: string;
  model?: string;
  palletUnitPrice: number;
  merchandiseSubtotal: number;
  deliveryFee: number | null; // null if quote required
  baseDeliveryFee?: number;
  deliverySupplement: number;
  deliveryIsQuoteRequired: boolean;
  deliveryZoneType: 'STANDARD' | 'REMOTE' | 'QUOTE';
  remoteReason?: string;
  totalAmount: number;
  depositToStartDelivery?: number;
  balanceDueOnDelivery?: number;
  customer: PalletOrderCustomer;
  status: OrderStatus;
  paymentProof?: PaymentProof;
  rejectionReason?: string;
  trackingNumber?: string;
  carrierName?: string;
  history: OrderStatusHistoryEntry[];

  // Intelligent delivery fields specified in pseudo-code
  tarifLivraisonVerrouille: boolean;
  distanceRoutiereKm?: number | null;
  distanceIncluseKm?: number;
  tarifMinimum?: number;
  supplementDistance?: number;
  supplementZones?: number;
  destinationReconnue?: string;
  motifDevis?: string;
  dateCalculLivraison?: string;
  dateValidationLivraison?: string;
  validePar?: string;
  configurationLivraisonUtilisee?: Partial<ShippingConfig>;
  emailSent?: boolean;
  emailSentAt?: string;
  emailSentToCustomer?: boolean;
  emailSentToAdmin?: boolean;
  invoicePdfGenerated?: boolean;
}

export interface BankPaymentDetails {
  bankName: string;
  accountHolder: string;
  iban: string;
  bic: string;
  branchAddress?: string;
  paymentNotice: string;
}

export interface OrderNotificationLog {
  id: string;
  orderId: string;
  recipientEmail: string;
  subject: string;
  type: 'CREATION' | 'PRO_FORMA' | 'PROOF_RECEIVED' | 'PAYMENT_CONFIRMED' | 'PAYMENT_REJECTED' | 'PREPARATION' | 'SHIPPED' | 'DELIVERED';
  sentAt: string;
  content: string;
}

export type ActivityEventType =
  | 'VISIT'
  | 'PRODUCT_VIEW'
  | 'PRODUCT_SELECTED'
  | 'SIZE_SELECTED'
  | 'SELECTION_UPDATED'
  | 'REQUEST_SENT'
  | 'WHATSAPP_CLICK'
  | 'CLIENT_IDENTIFIED'
  | 'ORDER_CREATED'
  | 'SELECTION_PDF_DOWNLOADED'
  | 'LOGIN'
  | 'LOGOUT';

export interface ActivityEvent {
  id: string;
  timestamp: string; // ISO string or formatted date
  eventType: ActivityEventType;
  clientId?: string;
  clientEmail?: string;
  clientName?: string;
  productId?: string;
  productName?: string;
  details: string;
}

export interface AdminSettings {
  companyName: string;
  logoUrl: string;
  whatsappNumber: string;
  contactEmail: string;
  presentationText: string;
  isProductionMode: boolean; // if true, demo seed data hidden
}

export interface AdminNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'REQUEST' | 'CLIENT' | 'WHATSAPP' | 'SELECTION';
  read: boolean;
  linkTab?: string;
}

